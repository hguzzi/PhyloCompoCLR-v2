#!/usr/bin/env python3
"""
Multi-View Stacking with ElasticNet Meta-Learner for PhyloCompoCLR v2
=====================================================================
Following Imangaliyev et al. 2022:
- 3 feature views: raw ILR, V2 embedding, V2 intermediate layers
- Base learners per view
- ElasticNet-regularized LogisticRegression meta-learner
- Inner CV for meta-learner hyperparameter selection

Usage:
  python multiview_stacking.py --disease ibd --level genus
"""
import sys, os, json, time
import numpy as np, pandas as pd
import torch, torch.nn as nn, torch.optim as optim
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier

sys.path.insert(0, "/mnt/shared-workspace")
from phylocompoclr_v2_train import PhyloCompoCLREncoder

DATA_DIR = "/mnt/shared-workspace/cmd3_data"
MODEL_DIR = "/mnt/shared-workspace/models"
RS = 42

XGB_PARAMS = dict(n_estimators=300, max_depth=6, learning_rate=0.1,
                  use_label_encoder=False, eval_metric='logloss', verbosity=0,
                  random_state=RS)
RF_PARAMS = dict(n_estimators=500, random_state=RS, n_jobs=-1)
LASSO_PARAMS = dict(penalty='l1', C=1.0, solver='saga', max_iter=2000)
FT_PARAMS = dict(lr=1e-4, weight_decay=1e-4, epochs=50)

# ============ MODEL LOADING ============
def load_model(level, variant):
    fname = f"{MODEL_DIR}/{level}_v2_{variant}_best.pt"
    ckpt = torch.load(fname, map_location='cpu', weights_only=False)
    cfg = ckpt['config']
    return ckpt, cfg

def extract_all_features(ilr_t, ckpt, cfg):
    enc = PhyloCompoCLREncoder(cfg['input_dim'], cfg['hidden_dims'], cfg['embed_dim'])
    enc.load_state_dict(ckpt['encoder_state_dict'])
    enc.eval()
    X_t = torch.tensor(ilr_t, dtype=torch.float32)
    extractor = {}
    hooks = []
    for name, module in enc.named_modules():
        if isinstance(module, nn.Linear):
            def make_hook(n):
                def hook(mod, inp, out):
                    extractor[n] = out.detach().numpy()
                return hook
            h = module.register_forward_hook(make_hook(name))
            hooks.append(h)
    with torch.no_grad():
        _ = enc(X_t)
    for h in hooks:
        h.remove()
    layer_keys = sorted(extractor.keys())
    emb = extractor[layer_keys[-1]]
    all_layers = np.hstack([extractor[k] for k in layer_keys])
    return emb, all_layers, layer_keys

# ============ CLASSIFIERS ============
class FineTuneModel(nn.Module):
    def __init__(self, encoder, embed_dim, n_classes=2):
        super().__init__()
        self.encoder = encoder
        self.classifier = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(embed_dim // 2, n_classes)
        )
    def forward(self, x):
        return self.classifier(self.encoder(x))

def run_ft_single_fold(ilr_train, y_train, ilr_test, ckpt, cfg):
    """Fine-tune for a single fold."""
    enc = PhyloCompoCLREncoder(cfg['input_dim'], cfg['hidden_dims'], cfg['embed_dim'])
    enc.load_state_dict(ckpt['encoder_state_dict'])
    model = FineTuneModel(enc, cfg['embed_dim'])
    opt = optim.Adam(model.parameters(), lr=FT_PARAMS['lr'], weight_decay=FT_PARAMS['weight_decay'])
    X_tr = torch.tensor(ilr_train, dtype=torch.float32)
    y_tr = torch.tensor(y_train, dtype=torch.long)
    X_te = torch.tensor(ilr_test, dtype=torch.float32)
    model.train()
    for ep in range(FT_PARAMS['epochs']):
        opt.zero_grad()
        nn.CrossEntropyLoss()(model(X_tr), y_tr).backward()
        opt.step()
    model.eval()
    with torch.no_grad():
        prob = torch.softmax(model(X_te), dim=1)[:, 1].numpy()
    return prob

# ============ MULTI-VIEW STACKING ============
def multiview_stacking_eval(disease, level):
    """
    Multi-view stacking with ElasticNet meta-learner.
    
    Views:
    - View 1 (Raw ILR): XGB_raw, RF_raw, LASSO_ILR
    - View 2 (V2 Embedding): V2_FT_256, V2_LP_256
    - View 3 (V2 Intermediate): XGB_allV2_256
    
    Meta-learner: ElasticNet LogisticRegression
    - Grid search: l1_ratio in [0.1, 0.5, 0.9], C in [0.01, 0.1, 1.0]
    - Inner 3-fold CV for hyperparameter selection
    """
    # Load data
    ilr = pd.read_csv(f"{DATA_DIR}/{level}_philr_transform.csv", index_col=0)
    meta = pd.read_csv(f"{DATA_DIR}/sample_metadata.csv", index_col=0, low_memory=False)
    common = ilr.index.intersection(meta.index)
    ilr_v = ilr.loc[common].values
    meta_l = meta.loc[common]
    del ilr; import gc; gc.collect()
    
    col = f'{disease}_binary'
    mask = meta_l[col].notna()
    labels = meta_l.loc[mask, col].values.astype(int)
    ilr_t = ilr_v[mask.values]
    nfolds = 5
    
    key = f"{level}_{disease}"
    print(f"\n{'='*70}")
    print(f"MULTI-VIEW STACKING: {key} (n={len(labels)}, pos={labels.sum()}, {nfolds}-fold)")
    print(f"{'='*70}")
    
    # Load models and extract features
    ckpt_256, cfg_256 = load_model(level, 'wide256')
    ckpt_128, cfg_128 = load_model(level, 'full')
    
    print("Extracting features...")
    emb_256, all_layers_256, _ = extract_all_features(ilr_t, ckpt_256, cfg_256)
    emb_128, all_layers_128, _ = extract_all_features(ilr_t, ckpt_128, cfg_128)
    
    X_v2enh_256 = np.hstack([emb_256, ilr_t])
    X_allv2_256 = np.hstack([all_layers_256, ilr_t])
    
    # Outer CV
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    
    # Store per-fold predictions for each base learner
    base_preds = {}  # method_name -> list of per-fold test predictions
    base_methods = [
        # View 1: Raw ILR
        ('XGB_raw', 'view1'),
        ('RF_raw', 'view1'),
        ('LASSO_ILR', 'view1'),
        # View 2: V2 Embedding
        ('V2_FT_256', 'view2'),
        ('V2_LP_256', 'view2'),
        # View 3: V2 Intermediate
        ('XGB_allV2_256', 'view3'),
    ]
    
    for mname, _ in base_methods:
        base_preds[mname] = []
    
    y_trues = []
    
    # Also store old stacking for comparison
    old_stack_preds = []
    mv_stack_preds = []
    mv2_stack_preds = []
    
    for fold_idx, (tri, tei) in enumerate(skf.split(ilr_t, labels)):
        print(f"\n  Fold {fold_idx+1}/{nfolds}")
        y_trues.append(labels[tei])
        
        X_tr_ilr = ilr_t[tri]
        X_te_ilr = ilr_t[tei]
        y_tr = labels[tri]
        y_te = labels[tei]
        
        # ---- View 1: Raw ILR base learners ----
        # XGB_raw
        clf = XGBClassifier(**XGB_PARAMS)
        clf.fit(X_tr_ilr, y_tr)
        base_preds['XGB_raw'].append(clf.predict_proba(X_te_ilr)[:, 1])
        
        # RF_raw
        clf = RandomForestClassifier(**RF_PARAMS)
        clf.fit(X_tr_ilr, y_tr)
        base_preds['RF_raw'].append(clf.predict_proba(X_te_ilr)[:, 1])
        
        # LASSO_ILR
        scaler = StandardScaler()
        clf = LogisticRegression(**LASSO_PARAMS)
        clf.fit(scaler.fit_transform(X_tr_ilr), y_tr)
        base_preds['LASSO_ILR'].append(clf.predict_proba(scaler.transform(X_te_ilr))[:, 1])
        
        # ---- View 2: V2 Embedding base learners ----
        # V2_FT_256
        prob_ft = run_ft_single_fold(ilr_t[tri], y_tr, ilr_t[tei], ckpt_256, cfg_256)
        base_preds['V2_FT_256'].append(prob_ft)
        
        # V2_LP_256
        clf = LogisticRegression(max_iter=2000, C=1.0)
        clf.fit(emb_256[tri], y_tr)
        base_preds['V2_LP_256'].append(clf.predict_proba(emb_256[tei])[:, 1])
        
        # ---- View 3: V2 Intermediate ----
        # XGB_allV2_256
        clf = XGBClassifier(**XGB_PARAMS)
        clf.fit(X_allv2_256[tri], y_tr)
        base_preds['XGB_allV2_256'].append(clf.predict_proba(X_allv2_256[tei])[:, 1])
        
        print(f"    Base learners done for fold {fold_idx+1}")
    
    # ---- Now do stacking with inner CV for meta-learner ----
    print("\n  Training meta-learners...")
    
    # ElasticNet grid
    en_grid = []
    for l1_ratio in [0.1, 0.5, 0.9]:
        for C in [0.01, 0.1, 1.0]:
            en_grid.append({'l1_ratio': l1_ratio, 'C': C})
    
    # For each outer fold, train meta-learner on inner folds
    for tf in range(nfolds):
        # Get inner training predictions (all folds except tf)
        inner_methods = [m for m, _ in base_methods]
        
        # --- Old stacking: XGB_raw + XGB_allV2_256 + RF_raw ---
        old_combo = ['XGB_raw', 'XGB_allV2_256', 'RF_raw']
        tm_old = np.column_stack([np.concatenate([base_preds[m][i] for i in range(nfolds) if i != tf]) for m in old_combo])
        ty = np.concatenate([y_trues[i] for i in range(nfolds) if i != tf])
        tem_old = np.column_stack([base_preds[m][tf] for m in old_combo])
        mc_old = LogisticRegression(max_iter=1000)
        mc_old.fit(tm_old, ty)
        old_stack_preds.append(mc_old.predict_proba(tem_old)[:, 1])
        
        # --- Multi-view stacking: all 3 views ---
        mv_combo = inner_methods  # All 6 base learners
        tm_mv = np.column_stack([np.concatenate([base_preds[m][i] for i in range(nfolds) if i != tf]) for m in mv_combo])
        tem_mv = np.column_stack([base_preds[m][tf] for m in mv_combo])
        
        # Inner CV for ElasticNet hyperparameter selection
        best_auc = -1
        best_params = None
        inner_skf = StratifiedKFold(n_splits=3, shuffle=True, random_state=RS)
        
        # Split inner training into further train/val
        inner_indices = np.arange(len(ty))
        
        for params in en_grid:
            inner_aucs = []
            for itri, itei in inner_skf.split(tm_mv, ty):
                mc_inner = LogisticRegression(
                    penalty='elasticnet', solver='saga',
                    l1_ratio=params['l1_ratio'], C=params['C'],
                    max_iter=2000, random_state=RS
                )
                mc_inner.fit(tm_mv[itri], ty[itri])
                prob_inner = mc_inner.predict_proba(tm_mv[itei])[:, 1]
                inner_aucs.append(roc_auc_score(ty[itei], prob_inner))
            
            mean_auc = np.mean(inner_aucs)
            if mean_auc > best_auc:
                best_auc = mean_auc
                best_params = params
        
        # Train final meta-learner with best params on all inner training data
        mc_mv = LogisticRegression(
            penalty='elasticnet', solver='saga',
            l1_ratio=best_params['l1_ratio'], C=best_params['C'],
            max_iter=2000, random_state=RS
        )
        mc_mv.fit(tm_mv, ty)
        mv_stack_preds.append(mc_mv.predict_proba(tem_mv)[:, 1])
        
        # --- 2-view stacking: View 1 + View 3 (ILR + V2-enhanced) ---
        mv2_combo = ['XGB_raw', 'RF_raw', 'LASSO_ILR', 'XGB_allV2_256']
        tm_mv2 = np.column_stack([np.concatenate([base_preds[m][i] for i in range(nfolds) if i != tf]) for m in mv2_combo])
        tem_mv2 = np.column_stack([base_preds[m][tf] for m in mv2_combo])
        
        # Use same ElasticNet inner CV
        best_auc2 = -1
        best_params2 = None
        for params in en_grid:
            inner_aucs2 = []
            for itri, itei in inner_skf.split(tm_mv2, ty):
                mc_inner2 = LogisticRegression(
                    penalty='elasticnet', solver='saga',
                    l1_ratio=params['l1_ratio'], C=params['C'],
                    max_iter=2000, random_state=RS
                )
                mc_inner2.fit(tm_mv2[itri], ty[itri])
                prob_inner2 = mc_inner2.predict_proba(tm_mv2[itei])[:, 1]
                inner_aucs2.append(roc_auc_score(ty[itei], prob_inner2))
            mean_auc2 = np.mean(inner_aucs2)
            if mean_auc2 > best_auc2:
                best_auc2 = mean_auc2
                best_params2 = params
        
        mc_mv2 = LogisticRegression(
            penalty='elasticnet', solver='saga',
            l1_ratio=best_params2['l1_ratio'], C=best_params2['C'],
            max_iter=2000, random_state=RS
        )
        mc_mv2.fit(tm_mv2, ty)
        mv2_stack_preds.append(mc_mv2.predict_proba(tem_mv2)[:, 1])
        
        print(f"    Fold {tf+1}: Old Stack AUC={roc_auc_score(y_trues[tf], old_stack_preds[-1]):.4f}, "
              f"MV Stack AUC={roc_auc_score(y_trues[tf], mv_stack_preds[-1]):.4f}, "
              f"MV2 Stack AUC={roc_auc_score(y_trues[tf], mv2_stack_preds[-1]):.4f}, "
              f"Best EN params: l1={best_params['l1_ratio']}, C={best_params['C']}")
    
    # Compute final AUCs
    results = {}
    
    # Base learner AUCs
    for mname, view in base_methods:
        aucs = [roc_auc_score(y_trues[i], base_preds[mname][i]) for i in range(nfolds)]
        results[mname] = {'auc_mean': np.mean(aucs), 'auc_std': np.std(aucs), 'view': view}
        print(f"  {mname} ({view}): {np.mean(aucs):.4f} +/- {np.std(aucs):.4f}")
    
    # Stacking AUCs
    old_aucs = [roc_auc_score(y_trues[i], old_stack_preds[i]) for i in range(nfolds)]
    results['Stack_XGB_V2enh_RF'] = {'auc_mean': np.mean(old_aucs), 'auc_std': np.std(old_aucs)}
    print(f"  Stack_XGB_V2enh_RF (old): {np.mean(old_aucs):.4f} +/- {np.std(old_aucs):.4f}")
    
    mv_aucs = [roc_auc_score(y_trues[i], mv_stack_preds[i]) for i in range(nfolds)]
    results['MV_Stack_3view'] = {'auc_mean': np.mean(mv_aucs), 'auc_std': np.std(mv_aucs)}
    print(f"  MV_Stack_3view (ElasticNet): {np.mean(mv_aucs):.4f} +/- {np.std(mv_aucs):.4f}")
    
    mv2_aucs = [roc_auc_score(y_trues[i], mv2_stack_preds[i]) for i in range(nfolds)]
    results['MV_Stack_2view_ILR_V2'] = {'auc_mean': np.mean(mv2_aucs), 'auc_std': np.std(mv2_aucs)}
    print(f"  MV_Stack_2view_ILR_V2 (ElasticNet): {np.mean(mv2_aucs):.4f} +/- {np.std(mv2_aucs):.4f}")
    
    # Save
    save_data = {
        'key': key, 'disease': disease, 'level': level,
        'n': len(labels), 'n_pos': int(labels.sum()),
        'nfolds': nfolds,
        'results': results,
    }
    
    save_path = f"/mnt/results/mvstack_{key}_results.json"
    with open(save_path, 'w') as f:
        json.dump(save_data, f, indent=2, default=str)
    print(f"Saved {save_path}")
    
    # Also save predictions for DeLong tests
    pred_data = {
        'Stack_XGB_V2enh_RF': [{'y_true': y_trues[i].tolist(), 'y_prob': old_stack_preds[i].tolist()} for i in range(nfolds)],
        'MV_Stack_3view': [{'y_true': y_trues[i].tolist(), 'y_prob': mv_stack_preds[i].tolist()} for i in range(nfolds)],
        'MV_Stack_2view_ILR_V2': [{'y_true': y_trues[i].tolist(), 'y_prob': mv2_stack_preds[i].tolist()} for i in range(nfolds)],
    }
    for mname, _ in base_methods:
        pred_data[mname] = [{'y_true': y_trues[i].tolist(), 'y_prob': base_preds[mname][i].tolist()} for i in range(nfolds)]
    
    pred_path = f"/mnt/shared-workspace/predictions_mvstack_{key}.json"
    with open(pred_path, 'w') as f:
        json.dump(pred_data, f)
    print(f"Saved predictions to {pred_path}")
    
    return save_data


# ============ RUN ============
if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--disease', choices=['ibd', 'cd', 'uc', 'crc', 't2d', 't1d'], required=True)
    parser.add_argument('--level', choices=['genus', 'species'], required=True)
    args = parser.parse_args()
    
    result = multiview_stacking_eval(args.disease, args.level)
