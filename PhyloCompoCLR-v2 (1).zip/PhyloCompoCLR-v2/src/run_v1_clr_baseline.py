#!/usr/bin/env python3
"""V1-style CLR baseline for comparison with V2 ILR approach."""

import sys
sys.path.insert(0, "/mnt/shared-workspace")

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import json
import time
import os
import importlib.util

# Load V2 training module (reuse encoder, VICReg)
spec = importlib.util.spec_from_file_location("phylocompoclr_v2_train", "/mnt/shared-workspace/phylocompoclr_v2_train.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

from phylocompoclr_v2_train import (
    PhyloCompoCLREncoder, Projector, VICRegLoss, ILRDataset
)

LEVEL = os.environ.get("V1_LEVEL", "genus")
EPOCHS = int(os.environ.get("V1_EPOCHS", "200"))

# Load CLR data
if LEVEL == "genus":
    clr_path = "/mnt/shared-workspace/cmd3_data/genus_clr_transform.csv"
    input_dim = 477
    hidden_dims = [512, 256, 128]
else:
    clr_path = "/mnt/shared-workspace/cmd3_data/species_clr_transform.csv"
    input_dim = 1661
    hidden_dims = [1024, 512, 256, 128]

print(f"Loading {LEVEL} CLR data...")
clr_data = pd.read_csv(clr_path, index_col=0)
clr_matrix = clr_data.values.astype(np.float32)
print(f"Shape: {clr_matrix.shape}")
del clr_data
import gc; gc.collect()

# V1 augmentations: CLR-space noise + feature dropout + cutmix
class V1Augmentation:
    """V1-style augmentations operating in CLR space."""
    def __init__(self, noise_alpha=0.3, dropout_rate=0.25, cutmix_alpha=0.4):
        self.noise_alpha = noise_alpha
        self.dropout_rate = dropout_rate
        self.cutmix_alpha = cutmix_alpha

    def __call__(self, x, mix_pool=None):
        batch_size, dim = x.shape

        # View 1: Gaussian noise + feature dropout
        z1 = x.clone()
        noise = torch.randn_like(z1) * self.noise_alpha
        z1 = z1 + noise
        mask = torch.rand_like(z1) > self.dropout_rate
        z1 = z1 * mask.float()

        # View 2: Gaussian noise + CutMix
        z2 = x.clone()
        noise2 = torch.randn_like(z2) * self.noise_alpha
        z2 = z2 + noise2
        if mix_pool is not None:
            lam = torch.rand(batch_size, 1, device=x.device)
            lam = torch.clamp(lam, 0, self.cutmix_alpha)
            idx = torch.randperm(batch_size, device=x.device)
            z2 = (1 - lam) * z2 + lam * mix_pool[idx]

        return z1, z2

# Training loop (adapted from V2)
aug = V1Augmentation()
dataset = ILRDataset(clr_matrix)  # Reuse dataset class (just stores matrix)
dataloader = DataLoader(dataset, batch_size=256, shuffle=True, drop_last=True, num_workers=0)

device = torch.device('cpu')
encoder = PhyloCompoCLREncoder(input_dim, hidden_dims, 128).to(device)
projector = Projector(128, [64, 32], 32).to(device)
vicreg = VICRegLoss()
optimizer = optim.AdamW(
    list(encoder.parameters()) + list(projector.parameters()),
    lr=1e-3, weight_decay=1e-5
)
scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS)

history = {'train_loss': [], 'sim_loss': [], 'var_loss': [], 'cov_loss': []}
best_loss = float('inf')

for epoch in range(EPOCHS):
    encoder.train()
    projector.train()
    epoch_losses = []

    for batch_x, _ in dataloader:
        batch_x = batch_x.to(device)

        with torch.no_grad():
            z1, z2 = aug(batch_x, mix_pool=batch_x)

        h1 = encoder(z1)
        h2 = encoder(z2)
        p1 = projector(h1)
        p2 = projector(h2)

        loss, loss_dict = vicreg(p1, p2)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        epoch_losses.append(loss_dict['total_loss'])

    scheduler.step()
    avg_loss = np.mean(epoch_losses)
    history['train_loss'].append(avg_loss)

    if avg_loss < best_loss:
        best_loss = avg_loss
        torch.save({
            'encoder_state_dict': encoder.state_dict(),
            'projector_state_dict': projector.state_dict(),
            'epoch': epoch,
            'loss': avg_loss,
            'config': {
                'input_dim': input_dim,
                'hidden_dims': hidden_dims,
                'embed_dim': 128,
                'proj_hidden': [64, 32],
                'proj_dim': 32,
                'aug_config': {'type': 'V1_CLR', 'noise_alpha': 0.3, 'dropout_rate': 0.25, 'cutmix_alpha': 0.4},
            }
        }, f'/mnt/shared-workspace/models/{LEVEL}_v1_clr_best.pt')

    if epoch % 20 == 0 or epoch == EPOCHS - 1:
        print(f"Epoch {epoch:3d}/{EPOCHS} | Loss: {avg_loss:.4f}")

# Save final
torch.save({
    'encoder_state_dict': encoder.state_dict(),
    'projector_state_dict': projector.state_dict(),
    'epoch': EPOCHS,
    'loss': avg_loss,
    'config': {
        'input_dim': input_dim,
        'hidden_dims': hidden_dims,
        'embed_dim': 128,
        'proj_hidden': [64, 32],
        'proj_dim': 32,
        'aug_config': {'type': 'V1_CLR'},
    }
}, f'/mnt/shared-workspace/models/{LEVEL}_v1_clr_final.pt')

with open(f'/mnt/shared-workspace/models/{LEVEL}_v1_clr_history.json', 'w') as f:
    json.dump(history, f, indent=2)

print(f"\nV1 CLR baseline complete! Best loss: {best_loss:.4f}")
