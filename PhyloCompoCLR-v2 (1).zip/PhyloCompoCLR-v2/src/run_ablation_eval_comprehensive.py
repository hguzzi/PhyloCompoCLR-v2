#!/usr/bin/env python3
"""Comprehensive evaluation of all genus ablation models."""

import sys
sys.path.insert(0, "/mnt/shared-workspace")

import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import StratifiedKFold, StratifiedShuffleSplit
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
import json

# Load data
genus_philr = pd.read_csv("/mnt/shared-workspace/cmd3_data/genus_philr_transform.csv", index_col=0)
genus_ilr = genus_philr.values.astype(np.float32)
sample_ids = genus_philr.index.tolist()
del genus_philr
import gc; gc.collect()

metadata = pd.read_csv("/mnt/shared-workspace/cmd3_data/sample_metadata.csv", index_col=0, low_memory=False)
metadata_aligned = metadata.loc[sample_ids]

from phylocompoclr_v2_train import PhyloCompoCLREncoder

def get_embeddings(model_path, input_data):
    checkpoint = torch.load(model_path, map_location="cpu", weights_only=False)
    config = checkpoint["config"]
    encoder = PhyloCompoCLREncoder(config["input_dim"], config["hidden_dims"], config["embed_dim"])
    encoder.load_state_dict(checkpoint["encoder_state_dict"])
    encoder.eval()
    X = torch.tensor(input_data, dtype=torch.float32)
    embeddings = []
    with torch.no_grad():
        for i in range(0, len(X), 512):
            batch = X[i:i+512]
            emb = encoder(batch)
            embeddings.append(emb.numpy())
    return np.vstack(embeddings)

def linear_probe(X, y, n_splits=5):
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
    aucs = []
    for train_idx, test_idx in skf.split(X, y):
        clf = LogisticRegression(max_iter=1000, C=1.0, random_state=42)
        clf.fit(X[train_idx], y[train_idx])
        y_prob = clf.predict_proba(X[test_idx])[:, 1]
        aucs.append(roc_auc_score(y[test_idx], y_prob))
    return float(np.mean(aucs)), float(np.std(aucs)), [float(a) for a in aucs]

# Labels
t2d_mask = metadata_aligned["t2d_binary"].notna()
t2d_labels = metadata_aligned.loc[t2d_mask, "t2d_binary"].values.astype(int)
t1d_mask = metadata_aligned["t1d_binary"].notna()
t1d_labels = metadata_aligned.loc[t1d_mask, "t1d_binary"].values.astype(int)

# Models to evaluate
ablation_names = ["full", "pert_only", "power_only", "mixup_only", "phylo_only", "no_aug"]
all_results = {}

for ablation in ablation_names:
    model_path = f"/mnt/shared-workspace/models/genus_v2_{ablation}_best.pt"
    try:
        checkpoint = torch.load(model_path, map_location="cpu", weights_only=False)
    except Exception as e:
        print(f"  {ablation}: model not found ({e})")
        continue

    print(f"\n=== Evaluating: {ablation} ===")
    config = checkpoint["config"]
    print(f"  Aug config: {config.get('aug_config', 'N/A')}")

    emb = get_embeddings(model_path, genus_ilr)
    print(f"  Embeddings: {emb.shape}")

    # T2D
    t2d_mean, t2d_std, t2d_folds = linear_probe(emb[t2d_mask.values], t2d_labels)
    print(f"  T2D LP: {t2d_mean:.3f} +/- {t2d_std:.3f}")

    # T1D
    t1d_mean, t1d_std, t1d_folds = linear_probe(emb[t1d_mask.values], t1d_labels, n_splits=3)
    print(f"  T1D LP: {t1d_mean:.3f} +/- {t1d_std:.3f}")

    # Data-limited T2D
    dl_results = {}
    for n in [10, 20, 50, 100, 200, 500]:
        aucs = []
        for repeat in range(5):
            sss = StratifiedShuffleSplit(n_splits=1, train_size=n, random_state=42+repeat)
            for train_idx, test_idx in sss.split(emb[t2d_mask.values], t2d_labels):
                clf = LogisticRegression(max_iter=1000, C=1.0)
                clf.fit(emb[t2d_mask.values][train_idx], t2d_labels[train_idx])
                y_prob = clf.predict_proba(emb[t2d_mask.values][test_idx])[:, 1]
                aucs.append(roc_auc_score(t2d_labels[test_idx], y_prob))
        dl_results[str(n)] = {"auc_mean": float(np.mean(aucs)), "auc_std": float(np.std(aucs))}
        print(f"  DL n={n}: {np.mean(aucs):.3f} +/- {np.std(aucs):.3f}")

    # Load training history
    hist_path = f"/mnt/shared-workspace/models/genus_v2_{ablation}_history.json"
    try:
        with open(hist_path) as f:
            h = json.load(f)
        train_loss_final = h["train_loss"][-1]
        train_loss_best = min(h["train_loss"])
    except:
        train_loss_final = None
        train_loss_best = None

    all_results[ablation] = {
        "t2d": {"auc_mean": t2d_mean, "auc_std": t2d_std, "per_fold": t2d_folds},
        "t1d": {"auc_mean": t1d_mean, "auc_std": t1d_std, "per_fold": t1d_folds},
        "data_limited": dl_results,
        "training_loss_final": train_loss_final,
        "training_loss_best": train_loss_best,
    }

# Save
with open("/mnt/results/evaluation_genus_ablations.json", "w") as f:
    json.dump(all_results, f, indent=2, default=float)
print(f"\nAll ablation results saved to /mnt/results/evaluation_genus_ablations.json")

# Print summary table
print(f"\n{'Method':<15} {'T2D AUC':<15} {'T1D AUC':<15} {'Loss (final)':<15} {'Loss (best)':<15}")
print("-" * 75)
for name, res in all_results.items():
    t2d = f"{res['t2d']['auc_mean']:.3f}±{res['t2d']['auc_std']:.3f}"
    t1d = f"{res['t1d']['auc_mean']:.3f}±{res['t1d']['auc_std']:.3f}"
    lf = f"{res['training_loss_final']:.2f}" if res['training_loss_final'] else "N/A"
    lb = f"{res['training_loss_best']:.2f}" if res['training_loss_best'] else "N/A"
    print(f"{name:<15} {t2d:<15} {t1d:<15} {lf:<15} {lb:<15}")
