#!/usr/bin/env python3
"""Ablation study for PhyloCompoCLR V2 augmentation strategies."""

import sys
sys.path.insert(0, "/mnt/shared-workspace")

import numpy as np
import pandas as pd
import importlib.util
import json

# Load training module
spec = importlib.util.spec_from_file_location("phylocompoclr_v2_train", "/mnt/shared-workspace/phylocompoclr_v2_train.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
pretrain_phylocompoclr_v2 = module.pretrain_phylocompoclr_v2

import os

# Configuration
LEVEL = os.environ.get("ABLATION_LEVEL", "genus")  # genus or species
ABLATION_NAME = os.environ.get("ABLATION_NAME", "full")
EPOCHS = int(os.environ.get("ABLATION_EPOCHS", "200"))

# Load data
if LEVEL == "genus":
    data_path = "/mnt/shared-workspace/cmd3_data/genus_philr_transform.csv"
    input_dim = 476
    hidden_dims = [512, 256, 128]
    std_path = "/mnt/shared-workspace/cmd3_data/genus_balance_std.npy"
    depths_path = "/mnt/shared-workspace/cmd3_data/genus_balance_depths.npy"
    b2s_path = None
else:
    data_path = "/mnt/shared-workspace/cmd3_data/species_philr_transform.csv"
    input_dim = 1660
    hidden_dims = [1024, 512, 256, 128]
    std_path = "/mnt/shared-workspace/cmd3_data/species_balance_std.npy"
    depths_path = "/mnt/shared-workspace/cmd3_data/species_balance_depths.npy"
    b2s_path = "/mnt/shared-workspace/cmd3_data/species_balance_to_species.npy"

print(f"Loading {LEVEL} PhILR data...")
philr_data = pd.read_csv(data_path, index_col=0)
ilr_matrix = philr_data.values.astype(np.float32)
print(f"Shape: {ilr_matrix.shape}")
del philr_data
import gc; gc.collect()

empirical_std = np.load(std_path)
tree_depths = np.load(depths_path)
balance_to_species = np.load(b2s_path) if b2s_path else None

# Ablation configurations
ablations = {
    "full": {
        "perturbation_alpha": 0.3, "powering_alpha": 0.3, "mixup_alpha": 0.4,
        "phylo_alpha": 0.5, "dropout_rate": 0.25,
        "aug_weights": [1, 1, 1, 1, 1],
    },
    "pert_only": {
        "perturbation_alpha": 0.3, "powering_alpha": 0.0, "mixup_alpha": 0.0,
        "phylo_alpha": 0.0, "dropout_rate": 0.0,
        "aug_weights": [1, 0, 0, 0, 0],
    },
    "power_only": {
        "perturbation_alpha": 0.0, "powering_alpha": 0.3, "mixup_alpha": 0.0,
        "phylo_alpha": 0.0, "dropout_rate": 0.0,
        "aug_weights": [0, 1, 0, 0, 0],
    },
    "mixup_only": {
        "perturbation_alpha": 0.0, "powering_alpha": 0.0, "mixup_alpha": 0.4,
        "phylo_alpha": 0.0, "dropout_rate": 0.0,
        "aug_weights": [0, 0, 1, 0, 0],
    },
    "phylo_only": {
        "perturbation_alpha": 0.0, "powering_alpha": 0.0, "mixup_alpha": 0.0,
        "phylo_alpha": 0.5, "dropout_rate": 0.0,
        "aug_weights": [0, 0, 0, 1, 0],
    },
    "no_aug": {
        "perturbation_alpha": 0.0, "powering_alpha": 0.0, "mixup_alpha": 0.0,
        "phylo_alpha": 0.0, "dropout_rate": 0.0,
        "aug_weights": [0, 0, 0, 0, 0],
    },
}

if ABLATION_NAME not in ablations:
    print(f"Unknown ablation: {ABLATION_NAME}. Available: {list(ablations.keys())}")
    sys.exit(1)

config = ablations[ABLATION_NAME]
print(f"Running ablation: {ABLATION_NAME}")
print(f"Config: {config}")

result = pretrain_phylocompoclr_v2(
    ilr_matrix=ilr_matrix,
    input_dim=input_dim,
    hidden_dims=hidden_dims,
    embed_dim=128,
    proj_hidden=[64, 32],
    proj_dim=32,
    perturbation_alpha=config["perturbation_alpha"],
    powering_alpha=config["powering_alpha"],
    mixup_alpha=config["mixup_alpha"],
    phylo_alpha=config["phylo_alpha"],
    phylo_mode='single',
    dropout_rate=config["dropout_rate"],
    empirical_std=empirical_std,
    tree_depths=tree_depths,
    balance_to_species=balance_to_species,
    aug_weights=config["aug_weights"],
    batch_size=256,
    lr=1e-3,
    weight_decay=1e-5,
    epochs=EPOCHS,
    sim_weight=25.0,
    var_weight=25.0,
    cov_weight=1.0,
    device='cpu',
    save_dir='/mnt/shared-workspace/models',
    run_name=f'{LEVEL}_v2_{ABLATION_NAME}',
    save_every=100,
    verbose=True,
)

print(f"\nAblation {ABLATION_NAME} complete! Best loss: {result['best_loss']:.4f}")
