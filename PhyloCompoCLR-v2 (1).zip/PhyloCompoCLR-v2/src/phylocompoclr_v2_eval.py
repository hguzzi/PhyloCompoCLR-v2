
"""
PhyloCompoCLR V2 - Downstream Evaluation Pipeline
"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import StratifiedKFold, StratifiedShuffleSplit
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, f1_score, accuracy_score
from typing import Optional, Dict, List, Tuple
import json
import os
import sys

sys.path.insert(0, "/mnt/shared-workspace")


def extract_features(encoder_path, ilr_matrix, device='cpu'):
    """Extract embeddings from a pretrained encoder."""
    checkpoint = torch.load(encoder_path, map_location=device)
    config = checkpoint.get('config', {})
    input_dim = config.get('input_dim', ilr_matrix.shape[1])
    hidden_dims = config.get('hidden_dims', [512, 256, 128])
    embed_dim = config.get('embed_dim', 128)
    
    from phylocompoclr_v2_train import PhyloCompoCLREncoder
    encoder = PhyloCompoCLREncoder(input_dim, hidden_dims, embed_dim)
    encoder.load_state_dict(checkpoint['encoder_state_dict'])
    encoder.to(device)
    encoder.eval()
    
    X = torch.tensor(ilr_matrix, dtype=torch.float32)
    batch_size = 512
    embeddings = []
    with torch.no_grad():
        for i in range(0, len(X), batch_size):
            batch = X[i:i+batch_size].to(device)
            emb = encoder(batch)
            embeddings.append(emb.cpu().numpy())
    return np.vstack(embeddings)


def linear_probe(embeddings, labels, n_folds=5, random_state=42):
    """Linear probing with logistic regression."""
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=random_state)
    fold_results = []
    for fold_idx, (train_idx, test_idx) in enumerate(skf.split(embeddings, labels)):
        X_train, X_test = embeddings[train_idx], embeddings[test_idx]
        y_train, y_test = labels[train_idx], labels[test_idx]
        clf = LogisticRegression(max_iter=1000, C=1.0, random_state=random_state)
        clf.fit(X_train, y_train)
        y_pred = clf.predict(X_test)
        y_prob = clf.predict_proba(X_test)
        n_classes = len(np.unique(labels))
        if n_classes == 2:
            auc = roc_auc_score(y_test, y_prob[:, 1])
        else:
            auc = roc_auc_score(y_test, y_prob, multi_class='ovr')
        f1 = f1_score(y_test, y_pred, average='weighted')
        acc = accuracy_score(y_test, y_pred)
        fold_results.append({'fold': fold_idx, 'auc': auc, 'f1': f1, 'acc': acc})
    aucs = [r['auc'] for r in fold_results]
    f1s = [r['f1'] for r in fold_results]
    return {
        'fold_results': fold_results,
        'auc_mean': np.mean(aucs), 'auc_std': np.std(aucs),
        'f1_mean': np.mean(f1s), 'f1_std': np.std(f1s),
    }


def fine_tune(ilr_matrix, labels, encoder_path, n_folds=5,
              ft_epochs=50, ft_lr=1e-3, device='cpu', random_state=42):
    """Fine-tune pretrained encoder with classification head."""
    from phylocompoclr_v2_train import PhyloCompoCLREncoder
    checkpoint = torch.load(encoder_path, map_location=device)
    config = checkpoint.get('config', {})
    input_dim = config.get('input_dim', ilr_matrix.shape[1])
    hidden_dims = config.get('hidden_dims', [512, 256, 128])
    embed_dim = config.get('embed_dim', 128)
    n_classes = len(np.unique(labels))
    
    class FineTuneModel(nn.Module):
        def __init__(self, enc, ed, nc):
            super().__init__()
            self.encoder = enc
            self.classifier = nn.Sequential(nn.Linear(ed, 64), nn.ReLU(), nn.Linear(64, nc))
        def forward(self, x):
            h = self.encoder(x)
            return self.classifier(h)
    
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=random_state)
    fold_results = []
    for fold_idx, (train_idx, test_idx) in enumerate(skf.split(ilr_matrix, labels)):
        encoder = PhyloCompoCLREncoder(input_dim, hidden_dims, embed_dim)
        encoder.load_state_dict(checkpoint['encoder_state_dict'])
        model = FineTuneModel(encoder, embed_dim, n_classes).to(device)
        X_train = torch.tensor(ilr_matrix[train_idx], dtype=torch.float32).to(device)
        y_train = torch.tensor(labels[train_idx], dtype=torch.long).to(device)
        X_test = torch.tensor(ilr_matrix[test_idx], dtype=torch.float32).to(device)
        y_test_np = labels[test_idx]
        optimizer = torch.optim.Adam(model.parameters(), lr=ft_lr)
        criterion = nn.CrossEntropyLoss()
        model.train()
        for epoch in range(ft_epochs):
            optimizer.zero_grad()
            logits = model(X_train)
            loss = criterion(logits, y_train)
            loss.backward()
            optimizer.step()
        model.eval()
        with torch.no_grad():
            logits = model(X_test)
            y_prob = torch.softmax(logits, dim=1).cpu().numpy()
            y_pred = logits.argmax(dim=1).cpu().numpy()
        if n_classes == 2:
            auc = roc_auc_score(y_test_np, y_prob[:, 1])
        else:
            auc = roc_auc_score(y_test_np, y_prob, multi_class='ovr')
        f1 = f1_score(y_test_np, y_pred, average='weighted')
        fold_results.append({'fold': fold_idx, 'auc': auc, 'f1': f1})
        print(f"  Fold {fold_idx}: AUC={auc:.3f}, F1={f1:.3f}")
    aucs = [r['auc'] for r in fold_results]
    return {'fold_results': fold_results, 'auc_mean': np.mean(aucs), 'auc_std': np.std(aucs)}


def rf_baseline(features, labels, n_folds=5, random_state=42):
    """Random Forest baseline."""
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=random_state)
    aucs = []
    for train_idx, test_idx in skf.split(features, labels):
        clf = RandomForestClassifier(n_estimators=500, random_state=random_state, n_jobs=-1)
        clf.fit(features[train_idx], labels[train_idx])
        y_prob = clf.predict_proba(features[test_idx])
        n_classes = len(np.unique(labels))
        if n_classes == 2:
            auc = roc_auc_score(labels[test_idx], y_prob[:, 1])
        else:
            auc = roc_auc_score(labels[test_idx], y_prob, multi_class='ovr')
        aucs.append(auc)
    return {'auc_mean': np.mean(aucs), 'auc_std': np.std(aucs), 'method': 'RandomForest'}


def data_limited_curve(embeddings, labels, sample_sizes=None, n_repeats=5, random_state=42):
    """Data-limited learning curves."""
    if sample_sizes is None:
        sample_sizes = [10, 20, 50, 100, 200, 500]
    np.random.seed(random_state)
    results = {}
    for n in sample_sizes:
        if n > len(labels) // 2:
            continue
        aucs = []
        for repeat in range(n_repeats):
            sss = StratifiedShuffleSplit(n_splits=1, train_size=n, random_state=random_state + repeat)
            for train_idx, test_idx in sss.split(embeddings, labels):
                clf = LogisticRegression(max_iter=1000, C=1.0)
                clf.fit(embeddings[train_idx], labels[train_idx])
                y_prob = clf.predict_proba(embeddings[test_idx])
                n_classes = len(np.unique(labels))
                if n_classes == 2:
                    auc = roc_auc_score(labels[test_idx], y_prob[:, 1])
                else:
                    auc = roc_auc_score(labels[test_idx], y_prob, multi_class='ovr')
                aucs.append(auc)
        results[n] = {'auc_mean': np.mean(aucs), 'auc_std': np.std(aucs), 'n_repeats': n_repeats}
        print(f"  n={n:4d}: AUC={np.mean(aucs):.3f} +/- {np.std(aucs):.3f}")
    return results


def run_full_evaluation(ilr_matrix, metadata, encoder_path, level='genus',
                        device='cpu', save_dir='/mnt/results', random_state=42):
    """Run the complete V2 evaluation suite."""
    os.makedirs(save_dir, exist_ok=True)
    all_results = {}
    
    print(f"Extracting {level}-level features...")
    embeddings = extract_features(encoder_path, ilr_matrix, device)
    print(f"Embeddings shape: {embeddings.shape}")
    
    # Task 1: T2D Classification
    print("\n=== Task 1: T2D Classification (5-fold CV) ===")
    t2d_mask = metadata['t2d_binary'].notna()
    t2d_emb = embeddings[t2d_mask.values]
    t2d_labels = metadata.loc[t2d_mask, 't2d_binary'].values.astype(int)
    print(f"T2D samples: {len(t2d_labels)} (cases={t2d_labels.sum()}, ctrl={len(t2d_labels)-t2d_labels.sum()})")
    
    t2d_lp = linear_probe(t2d_emb, t2d_labels, n_folds=5, random_state=random_state)
    print(f"  Linear Probe: AUC={t2d_lp['auc_mean']:.3f} +/- {t2d_lp['auc_std']:.3f}")
    
    t2d_ft = fine_tune(ilr_matrix[t2d_mask.values], t2d_labels, encoder_path,
                       n_folds=5, ft_epochs=50, device=device, random_state=random_state)
    print(f"  Fine-tune: AUC={t2d_ft['auc_mean']:.3f} +/- {t2d_ft['auc_std']:.3f}")
    
    t2d_ilr = ilr_matrix[t2d_mask.values]
    t2d_rf = rf_baseline(t2d_ilr, t2d_labels, n_folds=5, random_state=random_state)
    print(f"  RF (ILR): AUC={t2d_rf['auc_mean']:.3f} +/- {t2d_rf['auc_std']:.3f}")
    
    all_results['t2d'] = {'linear_probe': t2d_lp, 'fine_tune': t2d_ft, 'rf_ilr': t2d_rf}
    
    # Task 2: T1D Classification
    print("\n=== Task 2: T1D Classification ===")
    t1d_mask = metadata['t1d_binary'].notna()
    t1d_emb = embeddings[t1d_mask.values]
    t1d_labels = metadata.loc[t1d_mask, 't1d_binary'].values.astype(int)
    print(f"T1D samples: {len(t1d_labels)} (cases={t1d_labels.sum()}, ctrl={len(t1d_labels)-t1d_labels.sum()})")
    if len(t1d_labels) >= 30:
        t1d_lp = linear_probe(t1d_emb, t1d_labels, n_folds=min(5, max(2, len(t1d_labels)//10)), random_state=random_state)
        print(f"  Linear Probe: AUC={t1d_lp['auc_mean']:.3f} +/- {t1d_lp['auc_std']:.3f}")
        all_results['t1d'] = {'linear_probe': t1d_lp}
    else:
        print("  Too few T1D samples for reliable CV")
        all_results['t1d'] = {'note': 'Insufficient samples'}
    
    # Task 3: T2D Subgroup
    print("\n=== Task 3: T2D Subgroup (3-class: healthy/IGT/T2D) ===")
    glucose_mask = metadata['glucose_status'].isin(['healthy', 'prediabetic', 'T2D'])
    glucose_emb = embeddings[glucose_mask.values]
    glucose_labels = metadata.loc[glucose_mask, 'glucose_status'].map(
        {'healthy': 0, 'prediabetic': 1, 'T2D': 2}).values.astype(int)
    print(f"Glucose samples: {len(glucose_labels)} (H={sum(glucose_labels==0)}, IGT={sum(glucose_labels==1)}, T2D={sum(glucose_labels==2)})")
    if len(glucose_labels) >= 50:
        glucose_lp = linear_probe(glucose_emb, glucose_labels, n_folds=5, random_state=random_state)
        print(f"  Linear Probe (3-class): AUC={glucose_lp['auc_mean']:.3f} +/- {glucose_lp['auc_std']:.3f}")
        all_results['glucose_subgroup'] = {'linear_probe': glucose_lp}
    
    # Task 4: Data-Limited Learning Curves
    print("\n=== Task 4: Data-Limited Learning Curves ===")
    dl_results = data_limited_curve(t2d_emb, t2d_labels, n_repeats=5, random_state=random_state)
    all_results['data_limited'] = dl_results
    
    # Save results
    def convert_numpy(obj):
        if isinstance(obj, np.integer): return int(obj)
        elif isinstance(obj, np.floating): return float(obj)
        elif isinstance(obj, np.ndarray): return obj.tolist()
        elif isinstance(obj, dict): return {k: convert_numpy(v) for k, v in obj.items()}
        elif isinstance(obj, list): return [convert_numpy(v) for v in obj]
        return obj
    
    all_results_serializable = convert_numpy(all_results)
    with open(os.path.join(save_dir, f'evaluation_{level}_v2.json'), 'w') as f:
        json.dump(all_results_serializable, f, indent=2)
    print(f"Results saved to {save_dir}/evaluation_{level}_v2.json")
    return all_results
