#!/usr/bin/env python3
"""Self-contained species-level pretraining script for PhyloCompoCLR V2."""

import sys
sys.path.insert(0, "/mnt/shared-workspace")

import numpy as np
import pandas as pd
import importlib.util

# Load training module
spec = importlib.util.spec_from_file_location("phylocompoclr_v2_train", "/mnt/shared-workspace/phylocompoclr_v2_train.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
pretrain_phylocompoclr_v2 = module.pretrain_phylocompoclr_v2

# Load data
print("Loading full species PhILR transform...")
species_philr = pd.read_csv("/mnt/shared-workspace/cmd3_data/species_philr_transform.csv", index_col=0)
species_ilr = species_philr.values.astype(np.float32)
print(f"Shape: {species_ilr.shape}, Range: [{species_ilr.min():.3f}, {species_ilr.max():.3f}]")

del species_philr
import gc; gc.collect()

# Load augmentation parameters
empirical_std = np.load("/mnt/shared-workspace/cmd3_data/species_balance_std.npy")
tree_depths = np.load("/mnt/shared-workspace/cmd3_data/species_balance_depths.npy")
balance_to_species = np.load("/mnt/shared-workspace/cmd3_data/species_balance_to_species.npy")

# Run pretraining - species uses wider architecture
result = pretrain_phylocompoclr_v2(
    ilr_matrix=species_ilr,
    input_dim=1660,
    hidden_dims=[1024, 512, 256, 128],
    embed_dim=128,
    proj_hidden=[64, 32],
    proj_dim=32,
    perturbation_alpha=0.3,
    powering_alpha=0.3,
    mixup_alpha=0.4,
    phylo_alpha=0.5,
    phylo_mode='single',
    dropout_rate=0.25,
    empirical_std=empirical_std,
    tree_depths=tree_depths,
    balance_to_species=balance_to_species,
    batch_size=256,
    lr=1e-3,
    weight_decay=1e-5,
    epochs=300,
    sim_weight=25.0,
    var_weight=25.0,
    cov_weight=1.0,
    device='cpu',
    save_dir='/mnt/shared-workspace/models',
    run_name='species_v2_full',
    save_every=50,
    verbose=True,
)

print(f"\nSpecies pretraining complete! Best loss: {result['best_loss']:.4f}")
