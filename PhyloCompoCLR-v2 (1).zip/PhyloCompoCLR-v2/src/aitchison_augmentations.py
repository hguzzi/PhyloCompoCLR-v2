
"""
PhyloCompoCLR V2 — Aitchison-Geometry-Compliant Augmentation Suite

All augmentations operate in ILR (isometric log-ratio) coordinates,
which are orthonormal in Aitchison geometry. This ensures:
- Perturbation (⊕) maps to vector addition in ILR space
- Powering (⊗) maps to scalar multiplication in ILR space
- Mixup is a convex combination in ILR space (= Aitchison interpolation)

The PhILR basis uses a phylogenetic sequential binary partition (SBP),
making each ILR balance interpretable as a log-ratio between sister clades.
"""

import numpy as np
import torch
from typing import Optional, Tuple, List


class AitchisonPerturbation:
    """
    Aitchison perturbation augmentation: z_aug = z + ε * t

    In simplex space: x ⊕ t = C(x₁·t₁, ..., x_D·t_D)
    In ILR space: ilr(x ⊕ t) = ilr(x) + ilr(t)

    The perturbation vector t is sampled from the empirical distribution
    of ILR coordinates (mean=0, std from data), making the augmentation
    shift compositions along directions observed in real data.
    """
    def __init__(self, alpha: float = 0.3, empirical_std: Optional[np.ndarray] = None):
        self.alpha = alpha
        self.empirical_std = empirical_std  # per-balance std from training data

    def __call__(self, z: torch.Tensor) -> torch.Tensor:
        """Apply perturbation augmentation.

        Args:
            z: ILR coordinates, shape (batch_size, D-1) or (D-1,)
        Returns:
            Augmented ILR coordinates, same shape
        """
        if z.dim() == 1:
            z = z.unsqueeze(0)
            squeeze = True
        else:
            squeeze = False

        batch_size, n_balances = z.shape

        # Sample perturbation direction
        if self.empirical_std is not None:
            std = torch.tensor(self.empirical_std, device=z.device, dtype=z.dtype)
            t = torch.randn(batch_size, n_balances, device=z.device, dtype=z.dtype) * std
        else:
            t = torch.randn(batch_size, n_balances, device=z.device, dtype=z.dtype)

        # Scale by epsilon ~ U(0, alpha)
        eps = torch.rand(batch_size, 1, device=z.device, dtype=z.dtype) * self.alpha

        z_aug = z + eps * t

        return z_aug.squeeze(0) if squeeze else z_aug


class AitchisonPowering:
    """
    Aitchison powering augmentation: z_aug = β * z

    In simplex space: α ⊗ x = C(x₁^α, ..., x_D^α)
    In ILR space: ilr(α ⊗ x) = α · ilr(x)

    This scales the distance from the center of the simplex.
    β > 1 moves the composition away from center; β < 1 moves toward center.
    """
    def __init__(self, alpha: float = 0.3):
        self.alpha = alpha

    def __call__(self, z: torch.Tensor) -> torch.Tensor:
        """Apply powering augmentation.

        Args:
            z: ILR coordinates, shape (batch_size, D-1) or (D-1,)
        Returns:
            Augmented ILR coordinates, same shape
        """
        if z.dim() == 1:
            z = z.unsqueeze(0)
            squeeze = True
        else:
            squeeze = False

        batch_size = z.shape[0]

        # Sample β ~ U(1-alpha, 1+alpha)
        beta = torch.rand(batch_size, 1, device=z.device, dtype=z.dtype) * (2 * self.alpha) + (1 - self.alpha)

        z_aug = beta * z

        return z_aug.squeeze(0) if squeeze else z_aug


class AitchisonMixup:
    """
    Aitchison mixup augmentation for contrastive pair generation.

    In simplex space: s = (λ ⊗ s₁) ⊕ ((1-λ) ⊗ s₂)
    In ILR space: z_mix = λ·z₁ + (1-λ)·z₂

    This is the scikit-bio aitchison_mixup formulation.
    λ ~ Beta(α, α) ensures symmetric mixing.

    Key difference from V1: V1 did CLR-space interpolation which is 
    mathematically equivalent but CLR has singular covariance;
    ILR is orthonormal, so distances are preserved.
    """
    def __init__(self, alpha: float = 0.4):
        self.alpha = alpha
        if alpha > 0:
            self.beta_dist = torch.distributions.Beta(alpha, alpha)
        else:
            self.beta_dist = None  # Mixup disabled

    def __call__(self, z1: torch.Tensor, z2: torch.Tensor) -> torch.Tensor:
        """Apply Aitchison mixup between two samples.

        Args:
            z1: ILR coordinates of sample 1, shape (batch_size, D-1)
            z2: ILR coordinates of sample 2, shape (batch_size, D-1)
        Returns:
            Mixed ILR coordinates, shape (batch_size, D-1)
        """
        batch_size = z1.shape[0]

        # Sample λ ~ Beta(alpha, alpha)
        lam = self.beta_dist.sample((batch_size, 1)).to(device=z1.device, dtype=z1.dtype)

        z_mix = lam * z1 + (1 - lam) * z2

        return z_mix


class PhyloStructuredPerturbation:
    """
    Phylo-structured perturbation augmentation (novel contribution).

    Uses the PhILR basis where each ILR balance corresponds to a 
    log-ratio between sister clades in the phylogenetic tree.

    Instead of perturbing all balances equally (as in AitchisonPerturbation),
    this selectively perturbs balances corresponding to specific clades,
    creating phylogenetically meaningful augmentations.

    Two modes:
    1. 'single': Perturb a single randomly selected balance (clade)
    2. 'clade': Perturb all balances within a subtree depth range
    """
    def __init__(self, alpha: float = 0.5, mode: str = 'single',
                 tree_depths: Optional[np.ndarray] = None):
        """
        Args:
            alpha: Perturbation magnitude
            mode: 'single' or 'clade'
            tree_depths: Array of tree depths for each balance (for clade mode)
                         Depth indicates how deep in the tree the balance's node is.
                         Lower depth = higher (closer to root) = broader clade effect.
        """
        self.alpha = alpha
        self.mode = mode
        self.tree_depths = tree_depths

    def __call__(self, z: torch.Tensor) -> torch.Tensor:
        """Apply phylo-structured perturbation.

        Args:
            z: ILR coordinates, shape (batch_size, D-1) or (D-1,)
        Returns:
            Augmented ILR coordinates, same shape
        """
        if z.dim() == 1:
            z = z.unsqueeze(0)
            squeeze = True
        else:
            squeeze = False

        batch_size, n_balances = z.shape

        if self.mode == 'single':
            # Perturb a single randomly selected balance
            # This corresponds to perturbing the log-ratio of one sister clade pair
            balance_idx = torch.randint(0, n_balances, (batch_size,), device=z.device)
            perturbation = torch.zeros_like(z)
            eps = (torch.rand(batch_size, device=z.device, dtype=z.dtype) * 2 - 1) * self.alpha
            perturbation.scatter_(1, balance_idx.unsqueeze(1), eps.unsqueeze(1))

        elif self.mode == 'clade':
            # Perturb balances within a depth range (subtree)
            if self.tree_depths is not None:
                depths = torch.tensor(self.tree_depths, device=z.device, dtype=z.dtype)
                # Sample a target depth
                target_depth = torch.randint(0, int(depths.max().item()) + 1, (batch_size,), device=z.device)
                # Select balances within ±1 depth of target
                mask = (depths.unsqueeze(0) - target_depth.unsqueeze(1).float()).abs() <= 1
                perturbation = torch.randn_like(z) * self.alpha * mask.float()
            else:
                # Fallback: perturb a random contiguous block of balances
                block_size = max(1, n_balances // 20)  # ~5% of balances
                start_idx = torch.randint(0, n_balances - block_size + 1, (batch_size,), device=z.device)
                perturbation = torch.zeros_like(z)
                for i in range(batch_size):
                    s = start_idx[i]
                    perturbation[i, s:s+block_size] = torch.randn(block_size, device=z.device, dtype=z.dtype) * self.alpha
        else:
            raise ValueError(f"Unknown mode: {self.mode}")

        z_aug = z + perturbation

        return z_aug.squeeze(0) if squeeze else z_aug


class SubcompositionDropout:
    """
    Subcomposition dropout augmentation (from AugCoDa).

    Select a random subset of parts (species), apply closure, 
    then recompute ILR on the subcomposition.

    In Aitchison geometry, subcompositions are well-defined:
    a subcomposition is the projection onto a lower-dimensional simplex.

    Implementation note: Rather than recomputing the full ILR basis
    for each subcomposition (expensive), we:
    1. Zero out the ILR balances that involve dropped species
    2. This is an approximation but preserves the key property
       that the remaining balances are unchanged

    For exact subcomposition ILR, we would need to rebuild the SBP
    on the subtree, but this is too expensive for online augmentation.
    """
    def __init__(self, dropout_rate: float = 0.25, 
                 balance_to_species: Optional[np.ndarray] = None):
        """
        Args:
            dropout_rate: Fraction of species to drop (0.25 = drop 25%)
            balance_to_species: Boolean matrix (n_balances, n_species) indicating
                                which species each balance involves.
                                If None, uses random balance dropout.
        """
        self.dropout_rate = dropout_rate
        self.balance_to_species = balance_to_species

    def __call__(self, z: torch.Tensor) -> torch.Tensor:
        """Apply subcomposition dropout.

        Args:
            z: ILR coordinates, shape (batch_size, D-1) or (D-1,)
        Returns:
            Augmented ILR coordinates with some balances zeroed, same shape
        """
        if z.dim() == 1:
            z = z.unsqueeze(0)
            squeeze = True
        else:
            squeeze = False

        batch_size, n_balances = z.shape

        if self.balance_to_species is not None:
            # Drop species, then zero out balances involving dropped species
            n_species = self.balance_to_species.shape[1]
            n_drop = max(1, int(n_species * self.dropout_rate))

            # Sample which species to drop (per sample in batch)
            mask = torch.ones_like(z)  # 1 = keep, 0 = zero out

            b2s = torch.tensor(self.balance_to_species, device=z.device, dtype=torch.bool)

            for i in range(batch_size):
                drop_idx = torch.randperm(n_species, device=z.device)[:n_drop]
                # Find balances that involve any dropped species
                affected = b2s[:, drop_idx].any(dim=1)  # (n_balances,)
                mask[i, affected] = 0.0

            z_aug = z * mask
        else:
            # Random balance dropout (simpler approximation)
            mask = torch.rand_like(z) > self.dropout_rate
            z_aug = z * mask.float()

        return z_aug.squeeze(0) if squeeze else z_aug


class AitchisonAugmentationSuite:
    """
    Complete augmentation suite for PhyloCompoCLR V2.

    Combines all five Aitchison-geometry-compliant augmentations
    with random composition for each view in contrastive learning.

    Usage:
        suite = AitchisonAugmentationSuite(empirical_std=std_array)
        z1, z2 = suite(z)  # Generate two augmented views
    """
    def __init__(self,
                 perturbation_alpha: float = 0.3,
                 powering_alpha: float = 0.3,
                 mixup_alpha: float = 0.4,
                 phylo_alpha: float = 0.5,
                 phylo_mode: str = 'single',
                 dropout_rate: float = 0.25,
                 empirical_std: Optional[np.ndarray] = None,
                 tree_depths: Optional[np.ndarray] = None,
                 balance_to_species: Optional[np.ndarray] = None,
                 # Weights for random augmentation selection
                 aug_weights: Optional[List[float]] = None):
        """
        Args:
            perturbation_alpha: Magnitude for Aitchison perturbation
            powering_alpha: Range for Aitchison powering (β ~ U(1-α, 1+α))
            mixup_alpha: Beta distribution parameter for Aitchison mixup
            phylo_alpha: Magnitude for phylo-structured perturbation
            phylo_mode: 'single' or 'clade' for phylo perturbation
            dropout_rate: Fraction of species/balances to drop
            empirical_std: Per-balance standard deviations from training data
            tree_depths: Tree depth for each balance (for phylo clade mode)
            balance_to_species: Boolean matrix mapping balances to species
            aug_weights: Weights for selecting augmentations [pert, pow, mix, phylo, drop]
                        Default: equal weight [1, 1, 1, 1, 1]
        """
        self.perturbation = AitchisonPerturbation(perturbation_alpha, empirical_std)
        self.powering = AitchisonPowering(powering_alpha)
        self.mixup = AitchisonMixup(mixup_alpha)
        self.phylo_perturbation = PhyloStructuredPerturbation(phylo_alpha, phylo_mode, tree_depths)
        self.dropout = SubcompositionDropout(dropout_rate, balance_to_species)

        self.aug_weights = aug_weights or [1.0, 1.0, 1.0, 1.0, 1.0]
        self.aug_names = ['perturbation', 'powering', 'mixup', 'phylo_perturbation', 'dropout']
        self.n_augs = len(self.aug_names)

        # Normalize weights
        total = sum(self.aug_weights)
        self.aug_probs = [w / total for w in self.aug_weights] if total > 0 else [0.0] * len(self.aug_weights)

    def _apply_random_augmentation(self, z: torch.Tensor, 
                                     mixup_pool: Optional[torch.Tensor] = None) -> torch.Tensor:
        """Apply a randomly selected augmentation.

        Args:
            z: ILR coordinates (batch_size, D-1)
            mixup_pool: Other samples for mixup (batch_size, D-1). If None, mixup is skipped.
        """
        # Select augmentation
        aug_idx = np.random.choice(self.n_augs, p=self.aug_probs)
        aug_name = self.aug_names[aug_idx]

        if aug_name == 'perturbation':
            return self.perturbation(z)
        elif aug_name == 'powering':
            return self.powering(z)
        elif aug_name == 'mixup':
            if mixup_pool is not None:
                # Randomly pair with another sample
                idx = torch.randperm(z.shape[0], device=z.device)
                return self.mixup(z, mixup_pool[idx])
            else:
                # Fallback to perturbation if no mixup pool
                return self.perturbation(z)
        elif aug_name == 'phylo_perturbation':
            return self.phylo_perturbation(z)
        elif aug_name == 'dropout':
            return self.dropout(z)
        else:
            return z

    def __call__(self, z: torch.Tensor, 
                 mixup_pool: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        """Generate two augmented views for contrastive learning.

        Each view is created by applying 1-3 random augmentations sequentially.

        Args:
            z: ILR coordinates, shape (batch_size, D-1)
            mixup_pool: Other samples in batch for mixup augmentation

        Returns:
            z1, z2: Two augmented views, each (batch_size, D-1)
        """
        # No augmentation case: return identical views
        if sum(self.aug_weights) == 0:
            return z.clone(), z.clone()

        # View 1: Apply 1-3 augmentations
        n_augs_v1 = np.random.randint(1, 4)  # 1, 2, or 3 augmentations
        z1 = z.clone()
        for _ in range(n_augs_v1):
            z1 = self._apply_random_augmentation(z1, mixup_pool)

        # View 2: Apply 1-3 augmentations (independent)
        n_augs_v2 = np.random.randint(1, 4)
        z2 = z.clone()
        for _ in range(n_augs_v2):
            z2 = self._apply_random_augmentation(z2, mixup_pool)

        return z1, z2

    def get_config(self) -> dict:
        """Return configuration dictionary."""
        return {
            'perturbation_alpha': self.perturbation.alpha,
            'powering_alpha': self.powering.alpha,
            'mixup_alpha': self.mixup.alpha,
            'phylo_alpha': self.phylo_perturbation.alpha,
            'phylo_mode': self.phylo_perturbation.mode,
            'dropout_rate': self.dropout.dropout_rate,
            'aug_weights': self.aug_weights,
            'aug_probs': self.aug_probs,
        }


# ============ Unit Tests ============

def test_isometry_properties():
    """Verify that Aitchison operations in ILR space preserve isometry."""
    torch.manual_seed(42)
    D = 10  # 10 parts -> 9 ILR balances
    batch = 4

    # Random ILR coordinates
    z = torch.randn(batch, D-1)

    # Test 1: Perturbation = vector addition
    t = torch.randn(batch, D-1)
    z_pert = z + 0.5 * t  # Aitchison perturbation in ILR space
    assert z_pert.shape == z.shape, "Perturbation shape mismatch"

    # Test 2: Powering = scalar multiplication
    alpha = 1.5
    z_pow = alpha * z  # Aitchison powering in ILR space
    assert z_pow.shape == z.shape, "Powering shape mismatch"
    assert torch.allclose(z_pow, alpha * z), "Powering not scalar mult"

    # Test 3: Mixup = convex combination
    z1 = torch.randn(batch, D-1)
    z2 = torch.randn(batch, D-1)
    lam = 0.7
    z_mix = lam * z1 + (1 - lam) * z2
    assert z_mix.shape == z1.shape, "Mixup shape mismatch"

    # Test 4: Perturbation is commutative (Aitchison property)
    z_a = z + 0.5 * t
    z_b = 0.5 * t + z
    assert torch.allclose(z_a, z_b), "Perturbation not commutative"

    # Test 5: Powering distributes over perturbation
    # α ⊗ (x ⊕ y) = (α ⊗ x) ⊕ (α ⊗ y)
    alpha = 2.0
    lhs = alpha * (z + t)  # α ⊗ (x ⊕ y) in ILR
    rhs = alpha * z + alpha * t  # (α ⊗ x) ⊕ (α ⊗ y) in ILR
    assert torch.allclose(lhs, rhs), "Powering doesn't distribute over perturbation"

    print("All isometry property tests passed!")


def test_augmentation_suite():
    """Test the full augmentation suite."""
    torch.manual_seed(42)
    np.random.seed(42)
    D = 50  # 50 parts -> 49 ILR balances
    batch = 8

    z = torch.randn(batch, D-1)

    # Create suite with empirical std
    empirical_std = np.ones(D-1) * 2.0

    suite = AitchisonAugmentationSuite(
        perturbation_alpha=0.3,
        powering_alpha=0.3,
        mixup_alpha=0.4,
        phylo_alpha=0.5,
        dropout_rate=0.25,
        empirical_std=empirical_std,
    )

    # Test single augmentations
    z_pert = suite.perturbation(z)
    assert z_pert.shape == z.shape, "Perturbation shape mismatch"
    assert not torch.allclose(z_pert, z), "Perturbation is identity"

    z_pow = suite.powering(z)
    assert z_pow.shape == z.shape, "Powering shape mismatch"
    assert not torch.allclose(z_pow, z), "Powering is identity"

    z_mix = suite.mixup(z, z[torch.randperm(batch)])
    assert z_mix.shape == z.shape, "Mixup shape mismatch"

    z_phylo = suite.phylo_perturbation(z)
    assert z_phylo.shape == z.shape, "Phylo perturbation shape mismatch"
    assert not torch.allclose(z_phylo, z), "Phylo perturbation is identity"

    z_drop = suite.dropout(z)
    assert z_drop.shape == z.shape, "Dropout shape mismatch"
    # Some balances should be zeroed
    n_zero = (z_drop == 0).sum().item()
    n_total = z_drop.numel()
    print(f"Dropout: {n_zero}/{n_total} values zeroed ({100*n_zero/n_total:.1f}%)")

    # Test full suite (two views)
    z1, z2 = suite(z, mixup_pool=z)
    assert z1.shape == z.shape, "View 1 shape mismatch"
    assert z2.shape == z.shape, "View 2 shape mismatch"
    assert not torch.allclose(z1, z2), "Views are identical"

    # Test config
    config = suite.get_config()
    print(f"Suite config: {config}")

    print("All augmentation suite tests passed!")


if __name__ == "__main__":
    test_isometry_properties()
    test_augmentation_suite()
