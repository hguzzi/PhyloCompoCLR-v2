#!/usr/bin/env python3
"""
Run unified evaluation for new disease tasks (IBD, CD, UC, CRC)
at genus and species levels.

Usage:
  python run_new_diseases.py --disease ibd --level genus
  python run_new_diseases.py --disease cd --level species
  etc.
"""
import sys, os, json, time
import numpy as np, pandas as pd
import torch, torch.nn as nn, torch.optim as optim
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier
from itertools import combinations

sys.path.insert(0, "/mnt/shared-workspace")
from phylocompoclr_v2_train import PhyloCompoCLREncoder

DATA_DIR = "/mnt/shared-workspace/cmd3_data"
MODEL_DIR = "/mnt/shared-workspace/models"
RS = 42

# ============ UNIFIED HYPERPARAMETERS ============
XGB_PARAMS = dict(n_estimators=300, max_depth=6, learning_rate=0.1,
                  use_label_encoder=False, eval_metric='logloss', verbosity=0,
                  random_state=RS)
RF_PARAMS = dict(n_estimators=500, random_state=RS, n_jobs=-1)
LASSO_PARAMS = dict(penalty='l1', C=1.0, solver='saga', max_iter=2000)
FT_PARAMS = dict(lr=1e-4, weight_decay=1e-4, epochs=50)
MLP_PARAMS = dict(lr=1e-3, weight_decay=1e-4, epochs=100)

# ============ MODEL LOADING ============
def load_model(level, variant):
    if variant == 'full':
        fname = f"{MODEL_DIR}/{level}_v2_full_best.pt"
    elif variant == 'wide256':
        fname = f"{MODEL_DIR}/{level}_v2_wide256_best.pt"
    else:
        raise ValueError(f"Unknown variant: {variant}")
    ckpt = torch.load(fname, map_location='cpu', weights_only=False)
    cfg = ckpt['config']
    return ckpt, cfg

def extract_all_features(ilr_t, ckpt, cfg):
    enc = PhyloCompoCLREncoder(cfg['input_dim'], cfg['hidden_dims'], cfg['embed_dim'])
    enc.load_state_dict(ckpt['encoder_state_dict'])
    enc.eval()
    X_t = torch.tensor(ilr_t, dtype=torch.float32)
    
    extractor = {}
    hooks = []
    for name, module in enc.named_modules():
        if isinstance(module, nn.Linear):
            def make_hook(n):
                def hook(mod, inp, out):
                    extractor[n] = out.detach().numpy()
                return hook
            h = module.register_forward_hook(make_hook(name))
            hooks.append(h)
    with torch.no_grad():
        _ = enc(X_t)
    for h in hooks:
        h.remove()
    
    layer_keys = sorted(extractor.keys())
    emb = extractor[layer_keys[-1]]
    all_layers = np.hstack([extractor[k] for k in layer_keys])
    return emb, all_layers, layer_keys

# ============ CLASSIFIERS ============
class FineTuneModel(nn.Module):
    def __init__(self, encoder, embed_dim, n_classes=2):
        super().__init__()
        self.encoder = encoder
        self.classifier = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(embed_dim // 2, n_classes)
        )
    def forward(self, x):
        return self.classifier(self.encoder(x))

class MLPFromScratch(nn.Module):
    def __init__(self, input_dim, hidden_dims, embed_dim, n_classes=2):
        super().__init__()
        layers = []
        prev_dim = input_dim
        for h_dim in hidden_dims:
            layers.extend([nn.Linear(prev_dim, h_dim), nn.BatchNorm1d(h_dim), nn.ReLU()])
            prev_dim = h_dim
        layers.append(nn.Linear(prev_dim, embed_dim))
        self.encoder = nn.Sequential(*layers)
        self.classifier = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(embed_dim // 2, n_classes)
        )
    def forward(self, x):
        return self.classifier(self.encoder(x))

# ============ EVALUATION FUNCTIONS ============
def run_ft(ilr_t, labels, ckpt, cfg, nfolds):
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tri, tei in skf.split(ilr_t, labels):
        enc = PhyloCompoCLREncoder(cfg['input_dim'], cfg['hidden_dims'], cfg['embed_dim'])
        enc.load_state_dict(ckpt['encoder_state_dict'])
        model = FineTuneModel(enc, cfg['embed_dim'])
        opt = optim.Adam(model.parameters(), lr=FT_PARAMS['lr'], weight_decay=FT_PARAMS['weight_decay'])
        X_tr = torch.tensor(ilr_t[tri], dtype=torch.float32)
        y_tr = torch.tensor(labels[tri], dtype=torch.long)
        X_te = torch.tensor(ilr_t[tei], dtype=torch.float32)
        model.train()
        for ep in range(FT_PARAMS['epochs']):
            opt.zero_grad()
            nn.CrossEntropyLoss()(model(X_tr), y_tr).backward()
            opt.step()
        model.eval()
        with torch.no_grad():
            prob = torch.softmax(model(X_te), dim=1)[:, 1].numpy()
        preds.append(prob)
        aucs.append(roc_auc_score(labels[tei], prob))
    return preds, aucs

def run_mlp(ilr_t, labels, cfg, nfolds):
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tri, tei in skf.split(ilr_t, labels):
        model = MLPFromScratch(cfg['input_dim'], cfg['hidden_dims'], cfg['embed_dim'])
        opt = optim.Adam(model.parameters(), lr=MLP_PARAMS['lr'], weight_decay=MLP_PARAMS['weight_decay'])
        X_tr = torch.tensor(ilr_t[tri], dtype=torch.float32)
        y_tr = torch.tensor(labels[tri], dtype=torch.long)
        X_te = torch.tensor(ilr_t[tei], dtype=torch.float32)
        model.train()
        for ep in range(MLP_PARAMS['epochs']):
            opt.zero_grad()
            nn.CrossEntropyLoss()(model(X_tr), y_tr).backward()
            opt.step()
        model.eval()
        with torch.no_grad():
            prob = torch.softmax(model(X_te), dim=1)[:, 1].numpy()
        preds.append(prob)
        aucs.append(roc_auc_score(labels[tei], prob))
    return preds, aucs

def run_xgb(X, labels, nfolds):
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tri, tei in skf.split(X, labels):
        clf = XGBClassifier(**XGB_PARAMS)
        clf.fit(X[tri], labels[tri])
        prob = clf.predict_proba(X[tei])[:, 1]
        preds.append(prob)
        aucs.append(roc_auc_score(labels[tei], prob))
    return preds, aucs

def run_rf(X, labels, nfolds):
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tri, tei in skf.split(X, labels):
        clf = RandomForestClassifier(**RF_PARAMS)
        clf.fit(X[tri], labels[tri])
        prob = clf.predict_proba(X[tei])[:, 1]
        preds.append(prob)
        aucs.append(roc_auc_score(labels[tei], prob))
    return preds, aucs

def run_lasso(X, labels, nfolds):
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tri, tei in skf.split(X, labels):
        scaler = StandardScaler()
        clf = LogisticRegression(**LASSO_PARAMS)
        clf.fit(scaler.fit_transform(X[tri]), labels[tri])
        prob = clf.predict_proba(scaler.transform(X[tei]))[:, 1]
        preds.append(prob)
        aucs.append(roc_auc_score(labels[tei], prob))
    return preds, aucs

def run_lp(emb, labels, nfolds):
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tri, tei in skf.split(emb, labels):
        clf = LogisticRegression(max_iter=2000, C=1.0)
        clf.fit(emb[tri], labels[tri])
        prob = clf.predict_proba(emb[tei])[:, 1]
        preds.append(prob)
        aucs.append(roc_auc_score(labels[tei], prob))
    return preds, aucs

def run_stacking(all_preds, y_trues, nfolds, combo_methods):
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tf in range(nfolds):
        tm = np.column_stack([np.concatenate([all_preds[m][i] for i in range(nfolds) if i != tf]) for m in combo_methods])
        ty = np.concatenate([y_trues[i] for i in range(nfolds) if i != tf])
        tem = np.column_stack([all_preds[m][tf] for m in combo_methods])
        mc = LogisticRegression(max_iter=1000)
        mc.fit(tm, ty)
        mp = mc.predict_proba(tem)[:, 1]
        preds.append(mp)
        aucs.append(roc_auc_score(y_trues[tf], mp))
    return preds, aucs

# ============ DELONG TEST ============
def delong_roc_test(y_true, y_pred1, y_pred2):
    from scipy import stats
    n = len(y_true)
    n1 = np.sum(y_true == 1)
    n2 = np.sum(y_true == 0)
    auc1 = roc_auc_score(y_true, y_pred1)
    auc2 = roc_auc_score(y_true, y_pred2)
    
    def compute_placement(pred, labels):
        pos_pred = pred[labels == 1]
        neg_pred = pred[labels == 0]
        placements_pos = np.array([np.sum(neg_pred < p) + 0.5 * np.sum(neg_pred == p) for p in pos_pred]) / n2
        placements_neg = np.array([np.sum(pos_pred > p) + 0.5 * np.sum(pos_pred == p) for p in neg_pred]) / n1
        return placements_pos, placements_neg
    
    p1_pos, p1_neg = compute_placement(y_pred1, y_true)
    p2_pos, p2_neg = compute_placement(y_pred2, y_true)
    
    S1_pos, S1_neg = np.var(p1_pos, ddof=1), np.var(p1_neg, ddof=1)
    S2_pos, S2_neg = np.var(p2_pos, ddof=1), np.var(p2_neg, ddof=1)
    cov_pos = np.cov(p1_pos, p2_pos)[0, 1]
    cov_neg = np.cov(p1_neg, p2_neg)[0, 1]
    
    var_diff = (1/n1) * (S1_pos + S2_pos - 2*cov_pos) + (1/n2) * (S1_neg + S2_neg - 2*cov_neg)
    if var_diff <= 0:
        return 1.0, auc1, auc2
    z = (auc1 - auc2) / np.sqrt(var_diff)
    p_value = 2 * (1 - stats.norm.cdf(abs(z)))
    return p_value, auc1, auc2

# ============ MAIN EVALUATION ============
def evaluate_level_task(level, disease, ilr_all, meta):
    col = f'{disease}_binary'
    mask = meta[col].notna()
    labels = meta.loc[mask, col].values.astype(int)
    ilr_t = ilr_all[mask.values]
    nfolds = 5  # All new diseases have enough samples for 5-fold
    
    key = f"{level}_{disease}"
    print(f"\n{'='*70}")
    print(f"UNIFIED EVALUATION: {key} (n={len(labels)}, pos={labels.sum()}, neg={len(labels)-labels.sum()}, {nfolds}-fold)")
    print(f"{'='*70}")
    
    # Load models
    ckpt_128, cfg_128 = load_model(level, 'full')
    ckpt_256, cfg_256 = load_model(level, 'wide256')
    
    # Extract features
    print("Extracting features...")
    emb_128, all_layers_128, lk_128 = extract_all_features(ilr_t, ckpt_128, cfg_128)
    emb_256, all_layers_256, lk_256 = extract_all_features(ilr_t, ckpt_256, cfg_256)
    
    # Feature matrices
    X_v2enh_128 = np.hstack([emb_128, ilr_t])
    X_v2enh_256 = np.hstack([emb_256, ilr_t])
    X_allv2_128 = np.hstack([all_layers_128, ilr_t])
    X_allv2_256 = np.hstack([all_layers_256, ilr_t])
    
    # Run all methods
    results = {}
    all_preds = {}
    y_trues = []
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    for tri, tei in skf.split(ilr_t, labels):
        y_trues.append(labels[tei])
    
    # 1. Linear Probes
    for name, emb, cfg in [('V2_LP_128', emb_128, cfg_128), ('V2_LP_256', emb_256, cfg_256)]:
        p, a = run_lp(emb, labels, nfolds)
        all_preds[name] = p
        results[name] = {'auc_mean': np.mean(a), 'auc_std': np.std(a)}
        print(f"  {name}: {np.mean(a):.4f} +/- {np.std(a):.4f}")
    
    # 2. Fine-tuning
    for name, ckpt, cfg in [('V2_FT_128', ckpt_128, cfg_128), ('V2_FT_256', ckpt_256, cfg_256)]:
        p, a = run_ft(ilr_t, labels, ckpt, cfg, nfolds)
        all_preds[name] = p
        results[name] = {'auc_mean': np.mean(a), 'auc_std': np.std(a)}
        print(f"  {name}: {np.mean(a):.4f} +/- {np.std(a):.4f}")
    
    # 3. MLP from scratch
    p, a = run_mlp(ilr_t, labels, cfg_256, nfolds)
    all_preds['MLP_scratch'] = p
    results['MLP_scratch'] = {'auc_mean': np.mean(a), 'auc_std': np.std(a)}
    print(f"  MLP_scratch: {np.mean(a):.4f} +/- {np.std(a):.4f}")
    
    # 4. LASSO on ILR
    p, a = run_lasso(ilr_t, labels, nfolds)
    all_preds['LASSO_ILR'] = p
    results['LASSO_ILR'] = {'auc_mean': np.mean(a), 'auc_std': np.std(a)}
    print(f"  LASSO_ILR: {np.mean(a):.4f} +/- {np.std(a):.4f}")
    
    # 5. RF on raw ILR
    p, a = run_rf(ilr_t, labels, nfolds)
    all_preds['RF_raw'] = p
    results['RF_raw'] = {'auc_mean': np.mean(a), 'auc_std': np.std(a)}
    print(f"  RF_raw: {np.mean(a):.4f} +/- {np.std(a):.4f}")
    
    # 6. XGBoost variants
    for name, X in [('XGB_raw', ilr_t), 
                     ('XGB_V2enh_128', X_v2enh_128),
                     ('XGB_V2enh_256', X_v2enh_256),
                     ('XGB_allV2_128', X_allv2_128),
                     ('XGB_allV2_256', X_allv2_256)]:
        p, a = run_xgb(X, labels, nfolds)
        all_preds[name] = p
        results[name] = {'auc_mean': np.mean(a), 'auc_std': np.std(a)}
        print(f"  {name}: {np.mean(a):.4f} +/- {np.std(a):.4f}")
    
    # 7. Stacking ensembles
    stack_combos = {
        'Stack_XGB_RF': ['XGB_raw', 'RF_raw'],
        'Stack_XGB_V2enh_RF': ['XGB_raw', 'XGB_allV2_256', 'RF_raw'],
        'Stack_FT_XGB_RF': ['V2_FT_256', 'XGB_raw', 'RF_raw'],
        'Stack_all5': ['V2_FT_256', 'XGB_raw', 'XGB_allV2_256', 'RF_raw', 'LASSO_ILR'],
    }
    
    for sname, combo in stack_combos.items():
        p, a = run_stacking(all_preds, y_trues, nfolds, combo)
        all_preds[sname] = p
        results[sname] = {'auc_mean': np.mean(a), 'auc_std': np.std(a), 'combo': combo}
        print(f"  {sname}: {np.mean(a):.4f} +/- {np.std(a):.4f}")
    
    # 8. DeLong tests on key comparisons
    print(f"\n--- DeLong Tests ({key}) ---")
    y_all = np.concatenate(y_trues)
    
    delong_comparisons = [
        ('XGB_allV2_256 vs XGB_raw', 'XGB_allV2_256', 'XGB_raw'),
        ('Stack_XGB_V2enh_RF vs XGB_raw', 'Stack_XGB_V2enh_RF', 'XGB_raw'),
        ('Stack_all5 vs XGB_raw', 'Stack_all5', 'XGB_raw'),
        ('XGB_allV2_256 vs RF_raw', 'XGB_allV2_256', 'RF_raw'),
        ('V2_FT_256 vs V2_FT_128', 'V2_FT_256', 'V2_FT_128'),
        ('V2_FT_128 vs XGB_raw', 'V2_FT_128', 'XGB_raw'),
    ]
    
    delong_results = []
    for comp_name, m1, m2 in delong_comparisons:
        pred1 = np.concatenate(all_preds[m1])
        pred2 = np.concatenate(all_preds[m2])
        p, auc1, auc2 = delong_roc_test(y_all, pred1, pred2)
        delta = auc1 - auc2
        delong_results.append({
            'comparison': comp_name, 'method1': m1, 'method2': m2,
            'auc1': auc1, 'auc2': auc2, 'delta_auc': delta, 'p_value': p
        })
        sig = '***' if p < 0.001 else '**' if p < 0.01 else '*' if p < 0.05 else 'ns'
        print(f"  {comp_name}: dAUC={delta:+.4f}, p={p:.4f} {sig}")
    
    # BH correction
    from statsmodels.stats.multitest import multipletests
    pvals = [d['p_value'] for d in delong_results]
    reject, pvals_corr, _, _ = multipletests(pvals, method='fdr_bh')
    for i, d in enumerate(delong_results):
        d['p_BH'] = pvals_corr[i]
        d['sig_BH'] = '***' if pvals_corr[i] < 0.001 else '**' if pvals_corr[i] < 0.01 else '*' if pvals_corr[i] < 0.05 else 'ns'
    
    print(f"\n  BH-corrected:")
    for d in delong_results:
        print(f"    {d['comparison']}: dAUC={d['delta_auc']:+.4f}, p_BH={d['p_BH']:.4f} {d['sig_BH']}")
    
    # Save results
    save_data = {
        'key': key,
        'disease': disease,
        'level': level,
        'n': len(labels),
        'n_pos': int(labels.sum()),
        'n_neg': int(len(labels) - labels.sum()),
        'nfolds': nfolds,
        'results': results,
        'delong': delong_results,
    }
    
    save_path = f"/mnt/results/unified_{key}_results.json"
    with open(save_path, 'w') as f:
        json.dump(save_data, f, indent=2, default=str)
    print(f"Saved {save_path}")
    
    # Save predictions separately (for later DeLong across all tasks)
    pred_path = f"/mnt/shared-workspace/predictions_{key}.json"
    pred_data = {m: [{'y_true': y_trues[i].tolist(), 'y_prob': all_preds[m][i].tolist()} for i in range(nfolds)] for m in all_preds}
    with open(pred_path, 'w') as f:
        json.dump(pred_data, f)
    print(f"Saved predictions to {pred_path}")
    
    return save_data

# ============ RUN ============
if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--disease', choices=['ibd', 'cd', 'uc', 'crc'], required=True)
    parser.add_argument('--level', choices=['genus', 'species'], required=True)
    args = parser.parse_args()
    
    print(f"Loading {args.level} PhILR data...")
    ilr = pd.read_csv(f"{DATA_DIR}/{args.level}_philr_transform.csv", index_col=0)
    meta = pd.read_csv(f"{DATA_DIR}/sample_metadata.csv", index_col=0, low_memory=False)
    common = ilr.index.intersection(meta.index)
    ilr_v = ilr.loc[common].values
    meta_l = meta.loc[common]
    del ilr; import gc; gc.collect()
    
    result = evaluate_level_task(args.level, args.disease, ilr_v, meta_l)
    print(f"\nDone! Best method: {max(result['results'], key=lambda k: result['results'][k]['auc_mean'])}")
    print(f"Best AUC: {max(v['auc_mean'] for v in result['results'].values()):.4f}")
