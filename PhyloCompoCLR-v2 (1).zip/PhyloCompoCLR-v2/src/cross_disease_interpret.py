#!/usr/bin/env python3
"""
Cross-Disease Interpretability for PhyloCompoCLR v2
====================================================
1. Balance probing for IBD and CRC (extend existing analysis)
2. Compare discriminative balances across all 6 diseases
3. Identify disease-specific vs shared phylogenetic signatures

Usage:
  python cross_disease_interpret.py --level genus
  python cross_disease_interpret.py --level species
"""
import sys, os, json
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler
from scipy import stats

DATA_DIR = "/mnt/shared-workspace/cmd3_data"
RS = 42

def load_balance_stats(level):
    """Load balance statistics for interpretability."""
    balance_mean = np.load(f"{DATA_DIR}/{level}_balance_mean.npy")
    balance_std = np.load(f"{DATA_DIR}/{level}_balance_std.npy")
    balance_depths = np.load(f"{DATA_DIR}/{level}_balance_depths.npy")
    
    # Load balance names
    names_path = f"{DATA_DIR}/philr_balance_names.txt"
    if os.path.exists(names_path):
        with open(names_path, 'r') as f:
            balance_names = [line.strip() for line in f.readlines()]
    else:
        balance_names = [f"balance_{i}" for i in range(len(balance_mean))]
    
    return {
        'mean': balance_mean,
        'std': balance_std,
        'depths': balance_depths,
        'names': balance_names,
    }


def balance_probing(ilr_t, labels, balance_names, nfolds=5, top_k=20):
    """
    Probe individual ILR balances for disease association.
    For each balance, compute AUC of a univariate logistic regression.
    """
    n_balances = ilr_t.shape[1]
    results = []
    
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    
    for j in range(n_balances):
        balance_vals = ilr_t[:, j:j+1]
        aucs = []
        
        for tri, tei in skf.split(balance_vals, labels):
            scaler = StandardScaler()
            clf = LogisticRegression(max_iter=500, C=1.0)
            clf.fit(scaler.fit_transform(balance_vals[tri]), labels[tri])
            prob = clf.predict_proba(scaler.transform(balance_vals[tei]))[:, 1]
            aucs.append(roc_auc_score(labels[tei], prob))
        
        mean_auc = np.mean(aucs)
        # Direction: positive coefficient means higher balance = disease
        scaler = StandardScaler()
        clf = LogisticRegression(max_iter=500, C=1.0)
        clf.fit(scaler.fit_transform(balance_vals), labels)
        direction = clf.coef_[0][0]
        
        name = balance_names[j] if j < len(balance_names) else f"balance_{j}"
        results.append({
            'balance_idx': j,
            'name': name,
            'auc': mean_auc,
            'direction': float(direction),
            'abs_auc': max(mean_auc, 1 - mean_auc),
        })
    
    # Sort by discriminative power
    results.sort(key=lambda x: -x['abs_auc'])
    
    return results[:top_k]


def cross_disease_comparison(level, diseases=['t2d', 'ibd', 'cd', 'uc', 'crc']):
    """
    Compare discriminative balances across diseases.
    Identify shared vs disease-specific signatures.
    """
    ilr = pd.read_csv(f"{DATA_DIR}/{level}_philr_transform.csv", index_col=0)
    meta = pd.read_csv(f"{DATA_DIR}/sample_metadata.csv", index_col=0, low_memory=False)
    common = ilr.index.intersection(meta.index)
    ilr_v = ilr.loc[common].values
    meta_l = meta.loc[common]
    del ilr; import gc; gc.collect()
    
    balance_stats = load_balance_stats(level)
    balance_names = balance_stats['names']
    
    print(f"\n{'='*70}")
    print(f"CROSS-DISEASE INTERPRETABILITY: {level}")
    print(f"{'='*70}")
    
    # For each disease, get top discriminative balances
    disease_top_balances = {}
    all_balance_aucs = {}  # balance_idx -> {disease: auc}
    
    for disease in diseases:
        col = f'{disease}_binary'
        if col not in meta_l.columns:
            print(f"  Skipping {disease}: no binary column")
            continue
        
        mask = meta_l[col].notna()
        labels = meta_l.loc[mask, col].values.astype(int)
        ilr_t = ilr_v[mask.values]
        
        print(f"\n  Probing balances for {disease} (n={len(labels)}, pos={labels.sum()})...")
        top_balances = balance_probing(ilr_t, labels, balance_names, top_k=30)
        disease_top_balances[disease] = top_balances
        
        # Store all balance AUCs for cross-disease comparison
        for b in top_balances:
            idx = b['balance_idx']
            if idx not in all_balance_aucs:
                all_balance_aucs[idx] = {}
            all_balance_aucs[idx][disease] = b['abs_auc']
        
        print(f"    Top 5 balances for {disease}:")
        for b in top_balances[:5]:
            print(f"      {b['name']}: AUC={b['abs_auc']:.4f} (dir={'+' if b['direction'] > 0 else '-'})")
    
    # Identify shared vs disease-specific balances
    print(f"\n  --- Shared vs Disease-Specific Signatures ---")
    
    # A balance is "shared" if it's in top-20 for >=2 diseases
    # A balance is "disease-specific" if it's in top-20 for only 1 disease
    shared_balances = []
    disease_specific = {d: [] for d in diseases}
    
    for idx, disease_aucs in all_balance_aucs.items():
        n_diseases = len(disease_aucs)
        name = balance_names[idx] if idx < len(balance_names) else f"balance_{idx}"
        
        if n_diseases >= 2:
            shared_balances.append({
                'idx': idx, 'name': name,
                'n_diseases': n_diseases,
                'disease_aucs': disease_aucs,
                'max_auc': max(disease_aucs.values()),
            })
        elif n_diseases == 1:
            d = list(disease_aucs.keys())[0]
            disease_specific[d].append({
                'idx': idx, 'name': name,
                'auc': list(disease_aucs.values())[0],
            })
    
    # Sort shared by number of diseases and max AUC
    shared_balances.sort(key=lambda x: (-x['n_diseases'], -x['max_auc']))
    
    print(f"\n  Shared discriminative balances (top 10):")
    for b in shared_balances[:10]:
        diseases_str = ", ".join([f"{d}={a:.3f}" for d, a in sorted(b['disease_aucs'].items(), key=lambda x: -x[1])])
        print(f"    {b['name']}: shared across {b['n_diseases']} diseases — {diseases_str}")
    
    print(f"\n  Disease-specific balances (top 5 per disease):")
    for d in diseases:
        if d in disease_specific and disease_specific[d]:
            disease_specific[d].sort(key=lambda x: -x['auc'])
            print(f"    {d}:")
            for b in disease_specific[d][:5]:
                print(f"      {b['name']}: AUC={b['auc']:.4f}")
    
    # Save results
    save_data = {
        'level': level,
        'diseases': diseases,
        'disease_top_balances': {d: v for d, v in disease_top_balances.items()},
        'shared_balances': shared_balances[:30],
        'disease_specific': {d: v[:10] for d, v in disease_specific.items() if v},
    }
    
    save_path = f"/mnt/results/interpret_{level}_cross_disease.json"
    with open(save_path, 'w') as f:
        json.dump(save_data, f, indent=2, default=str)
    print(f"\n  Saved {save_path}")
    
    return save_data


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--level', choices=['genus', 'species', 'both'], default='both')
    args = parser.parse_args()
    
    levels = ['genus', 'species'] if args.level == 'both' else [args.level]
    for l in levels:
        cross_disease_comparison(l)
