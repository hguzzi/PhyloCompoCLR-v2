#!/usr/bin/env python3
"""
Clinical Metrics for PhyloCompoCLR v2
======================================
Compute sensitivity at fixed specificity, PPV/NPV, Youden's J, and 
compare to clinical standards (FIT for CRC, calprotectin for IBD).

Usage:
  python clinical_metrics.py --disease ibd --level genus
  python clinical_metrics.py --disease all --level both
"""
import sys, os, json
import numpy as np
from sklearn.metrics import roc_curve, auc, confusion_matrix

def compute_clinical_metrics(y_true, y_prob, prevalence=None):
    """
    Compute clinical performance metrics from predictions.
    
    Returns dict with:
    - auc: ROC AUC
    - sensitivity_at_spec_80: sensitivity when specificity = 0.80
    - sensitivity_at_spec_90: sensitivity when specificity = 0.90
    - youden_j: max (sensitivity + specificity - 1)
    - youden_threshold: threshold at Youden's J
    - youden_sensitivity: sensitivity at Youden's J
    - youden_specificity: specificity at Youden's J
    - ppv_at_youden: PPV at Youden's J (at given prevalence)
    - npv_at_youden: NPV at Youden's J (at given prevalence)
    """
    fpr, tpr, thresholds = roc_curve(y_true, y_prob)
    roc_auc = auc(fpr, tpr)
    
    # Sensitivity at fixed specificity
    def sens_at_spec(target_spec):
        # specificity = 1 - fpr, so target fpr = 1 - target_spec
        target_fpr = 1 - target_spec
        idx = np.searchsorted(fpr, target_fpr, side='right')
        if idx >= len(tpr):
            idx = len(tpr) - 1
        return float(tpr[idx])
    
    sens_80 = sens_at_spec(0.80)
    sens_90 = sens_at_spec(0.90)
    
    # Youden's J = max(sensitivity + specificity - 1)
    youden_j_values = tpr + (1 - fpr) - 1
    best_idx = np.argmax(youden_j_values)
    youden_j = float(youden_j_values[best_idx])
    youden_threshold = float(thresholds[best_idx])
    youden_sens = float(tpr[best_idx])
    youden_spec = float(1 - fpr[best_idx])
    
    # PPV/NPV at Youden's threshold (using prevalence)
    if prevalence is None:
        prevalence = np.mean(y_true)
    
    # At the Youden threshold:
    # TP = sensitivity * prevalence * N
    # FP = (1 - specificity) * (1 - prevalence) * N
    # FN = (1 - sensitivity) * prevalence * N
    # TN = specificity * (1 - prevalence) * N
    tp = youden_sens * prevalence
    fp = (1 - youden_spec) * (1 - prevalence)
    fn = (1 - youden_sens) * prevalence
    tn = youden_spec * (1 - prevalence)
    
    ppv = tp / (tp + fp) if (tp + fp) > 0 else 0
    npv = tn / (tn + fn) if (tn + fn) > 0 else 0
    
    return {
        'auc': float(roc_auc),
        'sensitivity_at_spec_80': float(sens_80),
        'sensitivity_at_spec_90': float(sens_90),
        'youden_j': float(youden_j),
        'youden_threshold': float(youden_threshold),
        'youden_sensitivity': float(youden_sens),
        'youden_specificity': float(youden_spec),
        'ppv_at_youden': float(ppv),
        'npv_at_youden': float(npv),
        'prevalence_used': float(prevalence),
    }


# Clinical reference values from literature
CLINICAL_REFERENCES = {
    'crc': {
        'fit_sensitivity_at_spec_90': 0.73,  # FIT at 90% specificity
        'fit_sensitivity_at_spec_80': 0.82,  # FIT at 80% specificity
        'prevalence_screening': 0.004,  # CRC prevalence in screening population (~0.4%)
        'prevalence_high_risk': 0.03,   # Higher risk population (~3%)
        'source': 'FIT sensitivity ~73% at 90% specificity (Lee et al. 2023, systematic review)',
    },
    'ibd': {
        'calprotectin_sensitivity_at_spec_90': 0.80,  # Fecal calprotectin
        'calprotectin_sensitivity_at_spec_80': 0.88,
        'prevalence_symptomatic': 0.10,  # IBD prevalence in symptomatic referral (~10%)
        'prevalence_population': 0.007,  # General population (~0.7%)
        'source': 'Fecal calprotectin sensitivity ~80% at 90% specificity (Moshkelgosha et al. 2023)',
    },
    'cd': {
        'calprotectin_sensitivity_at_spec_90': 0.85,  # Higher for CD than UC
        'prevalence_symptomatic': 0.06,
        'source': 'Fecal calprotectin for CD (Moshkelgosha et al. 2023)',
    },
    'uc': {
        'calprotectin_sensitivity_at_spec_90': 0.75,
        'prevalence_symptomatic': 0.04,
        'source': 'Fecal calprotectin for UC (Moshkelgosha et al. 2023)',
    },
    't2d': {
        'hba1c_sensitivity_at_spec_90': 0.70,  # HbA1c ≥6.5% for T2D diagnosis
        'prevalence_screening': 0.10,  # Pre-diabetic/diabetic in screening
        'source': 'HbA1c sensitivity for T2D screening (American Diabetes Association guidelines)',
    },
    't1d': {
        'prevalence_population': 0.005,
        'source': 'T1D is rare; autoantibody screening is standard',
    },
}


def compute_all_clinical_metrics(disease, level):
    """Load predictions and compute clinical metrics for all methods."""
    # Try loading from unified evaluation predictions
    key = f"{level}_{disease}"
    
    # Load predictions
    pred_path = f"/mnt/shared-workspace/predictions_{key}.json"
    if not os.path.exists(pred_path):
        print(f"Predictions not found at {pred_path}")
        return None
    
    with open(pred_path, 'r') as f:
        predictions = json.load(f)
    
    # Get reference values
    ref = CLINICAL_REFERENCES.get(disease, {})
    prevalence = ref.get('prevalence_symptomatic', ref.get('prevalence_screening', np.nan))
    
    results = {}
    
    for method_name, folds in predictions.items():
        # Concatenate all folds
        y_true_all = np.concatenate([f['y_true'] for f in folds])
        y_prob_all = np.concatenate([f['y_prob'] for f in folds])
        
        metrics = compute_clinical_metrics(y_true_all, y_prob_all, prevalence=prevalence)
        results[method_name] = metrics
    
    # Print summary
    print(f"\n{'='*70}")
    print(f"CLINICAL METRICS: {key}")
    print(f"{'='*70}")
    
    # Sort by AUC
    sorted_methods = sorted(results.items(), key=lambda x: -x[1]['auc'])
    
    print(f"\n{'Method':25s} {'AUC':>6s} {'Sens@80':>8s} {'Sens@90':>8s} {'YoudenJ':>7s} {'PPV':>6s} {'NPV':>6s}")
    print("-" * 75)
    for mname, m in sorted_methods:
        print(f"{mname:25s} {m['auc']:.4f} {m['sensitivity_at_spec_80']:.4f} {m['sensitivity_at_spec_90']:.4f} {m['youden_j']:.4f} {m['ppv_at_youden']:.4f} {m['npv_at_youden']:.4f}")
    
    # Clinical comparison
    if disease in CLINICAL_REFERENCES:
        ref = CLINICAL_REFERENCES[disease]
        print(f"\nClinical Reference ({ref.get('source', 'N/A')}):")
        if 'fit_sensitivity_at_spec_90' in ref:
            print(f"  FIT: Sens@90%Spec = {ref['fit_sensitivity_at_spec_90']:.2f}")
        if 'calprotectin_sensitivity_at_spec_90' in ref:
            print(f"  Fecal Calprotectin: Sens@90%Spec = {ref['calprotectin_sensitivity_at_spec_90']:.2f}")
        if 'hba1c_sensitivity_at_spec_90' in ref:
            print(f"  HbA1c: Sens@90%Spec = {ref['hba1c_sensitivity_at_spec_90']:.2f}")
    
    # Save
    save_data = {
        'key': key, 'disease': disease, 'level': level,
        'clinical_reference': CLINICAL_REFERENCES.get(disease, {}),
        'method_metrics': results,
    }
    
    save_path = f"/mnt/results/clinical_{key}_metrics.json"
    with open(save_path, 'w') as f:
        json.dump(save_data, f, indent=2, default=str)
    print(f"\nSaved {save_path}")
    
    return save_data


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--disease', choices=['ibd', 'cd', 'uc', 'crc', 't2d', 't1d', 'all'], required=True)
    parser.add_argument('--level', choices=['genus', 'species', 'both'], required=True)
    args = parser.parse_args()
    
    diseases = ['ibd', 'cd', 'uc', 'crc', 't2d', 't1d'] if args.disease == 'all' else [args.disease]
    levels = ['genus', 'species'] if args.level == 'both' else [args.level]
    
    for d in diseases:
        for l in levels:
            compute_all_clinical_metrics(d, l)
