
"""
PhyloCompoCLR V2 — Contrastive Pretraining Pipeline

Key upgrades from V1:
1. Input space: ILR (PhILR) coordinates instead of CLR
2. Augmentations: Aitchison-geometry-compliant (perturbation, powering, mixup, phylo-structured, subcomp dropout)
3. Scale: 21K samples (vs 7K in V1)
4. Both species and genus levels
"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from typing import Optional, Dict, Tuple
import json
import time
import os
import sys

sys.path.insert(0, "/mnt/shared-workspace")
from aitchison_augmentations import AitchisonAugmentationSuite


# ============ Dataset ============

class ILRDataset(Dataset):
    """Dataset for ILR-transformed microbiome compositions."""

    def __init__(self, ilr_matrix: np.ndarray, sample_ids: Optional[np.ndarray] = None):
        """
        Args:
            ilr_matrix: ILR coordinates, shape (n_samples, n_balances)
            sample_ids: Optional sample identifiers
        """
        self.ilr_matrix = torch.tensor(ilr_matrix, dtype=torch.float32)
        self.sample_ids = sample_ids

    def __len__(self):
        return self.ilr_matrix.shape[0]

    def __getitem__(self, idx):
        return self.ilr_matrix[idx], idx


# ============ Encoder ============

class PhyloCompoCLREncoder(nn.Module):
    """
    MLP encoder for ILR-transformed microbiome data.

    Architecture: [D -> hidden_dims -> embed_dim]
    With BatchNorm + ReLU between layers.
    """
    def __init__(self, input_dim: int, hidden_dims: list, embed_dim: int = 128):
        super().__init__()

        layers = []
        prev_dim = input_dim
        for h_dim in hidden_dims:
            layers.extend([
                nn.Linear(prev_dim, h_dim),
                nn.BatchNorm1d(h_dim),
                nn.ReLU()
            ])
            prev_dim = h_dim
        layers.append(nn.Linear(prev_dim, embed_dim))

        self.encoder = nn.Sequential(*layers)

    def forward(self, x):
        return self.encoder(x)


class Projector(nn.Module):
    """Projection head for VICReg."""
    def __init__(self, input_dim: int, hidden_dims: list = [64, 32], output_dim: int = 32):
        super().__init__()

        layers = []
        prev_dim = input_dim
        for h_dim in hidden_dims:
            layers.extend([
                nn.Linear(prev_dim, h_dim),
                nn.ReLU()
            ])
            prev_dim = h_dim
        layers.append(nn.Linear(prev_dim, output_dim))

        self.projector = nn.Sequential(*layers)

    def forward(self, x):
        return self.projector(x)


# ============ VICReg Loss ============

class VICRegLoss(nn.Module):
    """
    VICReg: Variance-Invariance-Covariance Regularization

    Loss = sim_weight * (1 - cosine_sim) + 
           var_weight * max(0, γ - std(z)) + 
           cov_weight * off_diagonal_cov

    Based on Bardes et al. 2022 ICLR.
    """
    def __init__(self, sim_weight=25.0, var_weight=25.0, cov_weight=1.0, eps=1e-4, gamma=1.0):
        super().__init__()
        self.sim_weight = sim_weight
        self.var_weight = var_weight
        self.cov_weight = cov_weight
        self.eps = eps
        self.gamma = gamma

    def forward(self, z1, z2):
        batch_size = z1.shape[0]

        # Invariance: MSE between views (or cosine similarity)
        sim_loss = nn.functional.mse_loss(z1, z2)

        # Variance: keep std above gamma
        std_z1 = torch.sqrt(z1.var(dim=0) + self.eps)
        std_z2 = torch.sqrt(z2.var(dim=0) + self.eps)
        var_loss = torch.mean(torch.relu(self.gamma - std_z1)) + torch.mean(torch.relu(self.gamma - std_z2))

        # Covariance: minimize off-diagonal elements
        z1_centered = z1 - z1.mean(dim=0)
        z2_centered = z2 - z2.mean(dim=0)
        cov_z1 = (z1_centered.T @ z1_centered) / (batch_size - 1)
        cov_z2 = (z2_centered.T @ z2_centered) / (batch_size - 1)
        off_diag_z1 = cov_z1.flatten()[:-1].view(cov_z1.shape[0] - 1, cov_z1.shape[0] + 1)[:, 1:].flatten()
        off_diag_z2 = cov_z2.flatten()[:-1].view(cov_z2.shape[0] - 1, cov_z2.shape[0] + 1)[:, 1:].flatten()
        cov_loss = (off_diag_z1.pow(2).sum() + off_diag_z2.pow(2).sum()) / z1.shape[1]

        total_loss = self.sim_weight * sim_loss + self.var_weight * var_loss + self.cov_weight * cov_loss

        return total_loss, {
            'sim_loss': sim_loss.item(),
            'var_loss': var_loss.item(),
            'cov_loss': cov_loss.item(),
            'total_loss': total_loss.item()
        }


# ============ Training Loop ============

def pretrain_phylocompoclr_v2(
    ilr_matrix: np.ndarray,
    input_dim: int,
    hidden_dims: list,
    embed_dim: int = 128,
    proj_hidden: list = [64, 32],
    proj_dim: int = 32,
    # Augmentation parameters
    perturbation_alpha: float = 0.3,
    powering_alpha: float = 0.3,
    mixup_alpha: float = 0.4,
    phylo_alpha: float = 0.5,
    phylo_mode: str = 'single',
    dropout_rate: float = 0.25,
    empirical_std: Optional[np.ndarray] = None,
    tree_depths: Optional[np.ndarray] = None,
    balance_to_species: Optional[np.ndarray] = None,
    aug_weights: Optional[list] = None,
    # Training parameters
    batch_size: int = 256,
    lr: float = 1e-3,
    weight_decay: float = 1e-5,
    epochs: int = 300,
    # VICReg parameters
    sim_weight: float = 25.0,
    var_weight: float = 25.0,
    cov_weight: float = 1.0,
    # Other
    device: str = 'cpu',
    save_dir: str = '/mnt/shared-workspace/models',
    run_name: str = 'phylocompoclr_v2',
    save_every: int = 50,
    verbose: bool = True,
) -> Dict:
    """
    Full pretraining pipeline for PhyloCompoCLR V2.

    Returns:
        Dictionary with training history and model paths.
    """
    os.makedirs(save_dir, exist_ok=True)

    # Setup device
    device = torch.device(device)

    # Create augmentation suite
    aug_suite = AitchisonAugmentationSuite(
        perturbation_alpha=perturbation_alpha,
        powering_alpha=powering_alpha,
        mixup_alpha=mixup_alpha,
        phylo_alpha=phylo_alpha,
        phylo_mode=phylo_mode,
        dropout_rate=dropout_rate,
        empirical_std=empirical_std,
        tree_depths=tree_depths,
        balance_to_species=balance_to_species,
        aug_weights=aug_weights,
    )

    # Create dataset and dataloader
    dataset = ILRDataset(ilr_matrix)
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, drop_last=True, num_workers=0)

    # Create model
    encoder = PhyloCompoCLREncoder(input_dim, hidden_dims, embed_dim).to(device)
    projector = Projector(embed_dim, proj_hidden, proj_dim).to(device)

    n_params = sum(p.numel() for p in encoder.parameters()) + sum(p.numel() for p in projector.parameters())
    if verbose:
        print(f"Encoder: {input_dim} -> {hidden_dims} -> {embed_dim}")
        print(f"Projector: {embed_dim} -> {proj_hidden} -> {proj_dim}")
        print(f"Total parameters: {n_params:,}")

    # Loss and optimizer
    vicreg = VICRegLoss(sim_weight=sim_weight, var_weight=var_weight, cov_weight=cov_weight)
    optimizer = optim.AdamW(
        list(encoder.parameters()) + list(projector.parameters()),
        lr=lr, weight_decay=weight_decay
    )
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)

    # Training history
    history = {
        'train_loss': [], 'sim_loss': [], 'var_loss': [], 'cov_loss': [],
        'lr': [], 'epoch_time': []
    }

    best_loss = float('inf')

    # Training loop
    for epoch in range(epochs):
        epoch_start = time.time()
        epoch_losses = {'total': [], 'sim': [], 'var': [], 'cov': []}

        encoder.train()
        projector.train()

        for batch_x, batch_idx in dataloader:
            batch_x = batch_x.to(device)

            # Generate two augmented views
            with torch.no_grad():
                z1, z2 = aug_suite(batch_x, mixup_pool=batch_x)

            # Encode both views
            h1 = encoder(z1)
            h2 = encoder(z2)

            # Project
            p1 = projector(h1)
            p2 = projector(h2)

            # VICReg loss
            loss, loss_dict = vicreg(p1, p2)

            # Backward
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            epoch_losses['total'].append(loss_dict['total_loss'])
            epoch_losses['sim'].append(loss_dict['sim_loss'])
            epoch_losses['var'].append(loss_dict['var_loss'])
            epoch_losses['cov'].append(loss_dict['cov_loss'])

        scheduler.step()

        epoch_time = time.time() - epoch_start
        avg_loss = np.mean(epoch_losses['total'])
        avg_sim = np.mean(epoch_losses['sim'])
        avg_var = np.mean(epoch_losses['var'])
        avg_cov = np.mean(epoch_losses['cov'])
        current_lr = scheduler.get_last_lr()[0]

        history['train_loss'].append(avg_loss)
        history['sim_loss'].append(avg_sim)
        history['var_loss'].append(avg_var)
        history['cov_loss'].append(avg_cov)
        history['lr'].append(current_lr)
        history['epoch_time'].append(epoch_time)

        if verbose and (epoch % 10 == 0 or epoch == epochs - 1):
            print(f"Epoch {epoch:3d}/{epochs} | Loss: {avg_loss:.4f} "
                  f"(sim: {avg_sim:.4f}, var: {avg_var:.4f}, cov: {avg_cov:.6f}) | "
                  f"LR: {current_lr:.6f} | Time: {epoch_time:.1f}s")

        # Save best model
        if avg_loss < best_loss:
            best_loss = avg_loss
            torch.save({
                'encoder_state_dict': encoder.state_dict(),
                'projector_state_dict': projector.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'epoch': epoch,
                'loss': avg_loss,
                'config': {
                    'input_dim': input_dim,
                    'hidden_dims': hidden_dims,
                    'embed_dim': embed_dim,
                    'proj_hidden': proj_hidden,
                    'proj_dim': proj_dim,
                    'aug_config': aug_suite.get_config(),
                }
            }, os.path.join(save_dir, f'{run_name}_best.pt'))

        # Periodic save
        if save_every > 0 and (epoch + 1) % save_every == 0:
            torch.save({
                'encoder_state_dict': encoder.state_dict(),
                'projector_state_dict': projector.state_dict(),
                'epoch': epoch,
                'loss': avg_loss,
            }, os.path.join(save_dir, f'{run_name}_epoch{epoch+1}.pt'))

    # Save final model
    torch.save({
        'encoder_state_dict': encoder.state_dict(),
        'projector_state_dict': projector.state_dict(),
        'epoch': epochs,
        'loss': avg_loss,
        'config': {
            'input_dim': input_dim,
            'hidden_dims': hidden_dims,
            'embed_dim': embed_dim,
            'proj_hidden': proj_hidden,
            'proj_dim': proj_dim,
            'aug_config': aug_suite.get_config(),
        }
    }, os.path.join(save_dir, f'{run_name}_final.pt'))

    # Save history
    with open(os.path.join(save_dir, f'{run_name}_history.json'), 'w') as f:
        json.dump(history, f, indent=2)

    if verbose:
        print(f"\nTraining complete. Best loss: {best_loss:.4f}")
        print(f"Models saved to {save_dir}")

    return {
        'encoder': encoder,
        'projector': projector,
        'history': history,
        'best_loss': best_loss,
        'save_dir': save_dir,
        'run_name': run_name,
    }
