#!/usr/bin/env python3
"""Self-contained genus-level pretraining script for PhyloCompoCLR V2."""

import sys
sys.path.insert(0, "/mnt/shared-workspace")

import numpy as np
import pandas as pd
import importlib.util

# Load training module
spec = importlib.util.spec_from_file_location("phylocompoclr_v2_train", "/mnt/shared-workspace/phylocompoclr_v2_train.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
pretrain_phylocompoclr_v2 = module.pretrain_phylocompoclr_v2

# Load data
print("Loading full genus PhILR transform...")
genus_philr = pd.read_csv("/mnt/shared-workspace/cmd3_data/genus_philr_transform.csv", index_col=0)
genus_ilr = genus_philr.values.astype(np.float32)
print(f"Shape: {genus_ilr.shape}, Range: [{genus_ilr.min():.3f}, {genus_ilr.max():.3f}]")

del genus_philr
import gc; gc.collect()

# Load augmentation parameters
empirical_std = np.load("/mnt/shared-workspace/cmd3_data/genus_balance_std.npy")
tree_depths = np.load("/mnt/shared-workspace/cmd3_data/genus_balance_depths.npy")

# Run pretraining
result = pretrain_phylocompoclr_v2(
    ilr_matrix=genus_ilr,
    input_dim=476,
    hidden_dims=[512, 256, 128],
    embed_dim=128,
    proj_hidden=[64, 32],
    proj_dim=32,
    perturbation_alpha=0.3,
    powering_alpha=0.3,
    mixup_alpha=0.4,
    phylo_alpha=0.5,
    phylo_mode='single',
    dropout_rate=0.25,
    empirical_std=empirical_std,
    tree_depths=tree_depths,
    batch_size=256,
    lr=1e-3,
    weight_decay=1e-5,
    epochs=300,
    sim_weight=25.0,
    var_weight=25.0,
    cov_weight=1.0,
    device='cpu',
    save_dir='/mnt/shared-workspace/models',
    run_name='genus_v2_full',
    save_every=50,
    verbose=True,
)

print(f"\nGenus pretraining complete! Best loss: {result['best_loss']:.4f}")
