#!/usr/bin/env python3
"""
Domain Adaptation Methods for PhyloCompoCLR v2
================================================
Three methods compared:
1. DEBIAS-M: Per-microbe per-batch bias correction factors
2. BatchNorm Adaptation: Replace encoder BN stats with target-study stats
3. CORAL: Align second-order statistics of source/target features

Evaluation: Leave-one-study-out cross-validation
For each disease, train on N-1 studies, test on held-out study.
Compare with/without domain adaptation.
"""
import sys, os, json, time
import numpy as np, pandas as pd
import torch, torch.nn as nn, torch.optim as optim
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from xgboost import XGBClassifier

sys.path.insert(0, "/mnt/shared-workspace")
from phylocompoclr_v2_train import PhyloCompoCLREncoder

DATA_DIR = "/mnt/shared-workspace/cmd3_data"
MODEL_DIR = "/mnt/shared-workspace/models"
RS = 42

XGB_PARAMS = dict(n_estimators=300, max_depth=6, learning_rate=0.1,
                  use_label_encoder=False, eval_metric='logloss', verbosity=0,
                  random_state=RS)

# ============ DEBIAS-M ============
class DebiasM:
    """
    Simplified DEBIAS-M: learn per-feature, per-batch multiplicative bias factors.
    
    For each batch b and feature j, learn a factor beta_{b,j} such that:
    corrected_x_{i,j} = x_{i,j} / beta_{b(i),j}
    
    Optimization minimizes:
    1. Batch effect: variance of corrected features across batches
    2. Phenotype signal: preserve association with labels
    
    Reference: Austin et al. 2024
    """
    def __init__(self, n_features, n_batches, lr=0.01, epochs=200, 
                 batch_weight=1.0, phenotype_weight=0.1):
        self.n_features = n_features
        self.n_batches = n_batches
        self.lr = lr
        self.epochs = epochs
        self.batch_weight = batch_weight
        self.phenotype_weight = phenotype_weight
        
    def fit(self, X, batch_ids, labels):
        X_t = torch.tensor(X, dtype=torch.float32)
        batch_t = torch.tensor(batch_ids, dtype=torch.long)
        y_t = torch.tensor(labels, dtype=torch.float32)
        
        # Initialize bias factors to 1 (no correction)
        log_beta = torch.zeros(self.n_batches, self.n_features, requires_grad=True)
        optimizer = torch.optim.Adam([log_beta], lr=self.lr)
        
        for ep in range(self.epochs):
            optimizer.zero_grad()
            beta = torch.exp(log_beta)
            batch_beta = beta[batch_t]
            X_corrected = X_t / (batch_beta + 1e-8)
            
            # Loss 1: Minimize batch effect (variance of batch means)
            batch_means = []
            for b in range(self.n_batches):
                mask = (batch_t == b)
                if mask.sum() > 0:
                    batch_means.append(X_corrected[mask].mean(dim=0))
            if len(batch_means) > 1:
                batch_means = torch.stack(batch_means)
                batch_loss = batch_means.var(dim=0).mean()
            else:
                batch_loss = torch.tensor(0.0)
            
            # Loss 2: Preserve phenotype signal
            # Use correlation-based weights for a simple linear score
            with torch.no_grad():
                X_corr_np = X_corrected.detach().numpy()
                w = np.zeros(self.n_features)
                for j in range(self.n_features):
                    c = np.corrcoef(X_corr_np[:, j], labels)[0, 1]
                    w[j] = c if not np.isnan(c) else 0.0
            w_t = torch.tensor(w, dtype=torch.float32)
            logits = X_corrected @ w_t
            phenotype_loss = -torch.mean(y_t * logits - torch.log1p(torch.exp(logits)))
            
            loss = self.batch_weight * batch_loss - self.phenotype_weight * phenotype_loss
            loss.backward()
            optimizer.step()
        
        self.beta_ = torch.exp(log_beta).detach().numpy()
        return self
    
    def transform(self, X, batch_ids):
        X_corrected = X.copy()
        for b in range(self.n_batches):
            mask = (batch_ids == b)
            if mask.sum() > 0:
                X_corrected[mask] = X[mask] / (self.beta_[b] + 1e-8)
        return X_corrected


# ============ CORAL ============
class CORAL:
    """
    CORAL: Correlation Alignment
    Align second-order statistics (mean + covariance) of source to target.
    Reference: Sun et al. 2016
    """
    def fit(self, X_source, X_target):
        self.mean_source = X_source.mean(axis=0)
        self.mean_target = X_target.mean(axis=0)
        
        Xs_c = X_source - self.mean_source
        Xt_c = X_target - self.mean_target
        
        Cs = np.cov(Xs_c, rowvar=False) + 1e-6 * np.eye(Xs_c.shape[1])
        Ct = np.cov(Xt_c, rowvar=False) + 1e-6 * np.eye(Xt_c.shape[1])
        
        try:
            Ls = np.linalg.cholesky(Cs)
        except np.linalg.LinAlgError:
            eigvals, eigvecs = np.linalg.eigh(Cs)
            eigvals = np.maximum(eigvals, 1e-6)
            Ls = eigvecs @ np.diag(np.sqrt(eigvals))
        
        try:
            Lt = np.linalg.cholesky(Ct)
        except np.linalg.LinAlgError:
            eigvals_t, eigvecs_t = np.linalg.eigh(Ct)
            eigvals_t = np.maximum(eigvals_t, 1e-6)
            Lt = eigvecs_t @ np.diag(np.sqrt(eigvals_t))
        
        self.A = np.linalg.solve(Ls, Lt)
        return self
    
    def transform(self, X):
        X_c = X - self.mean_source
        X_aligned = X_c @ self.A + self.mean_target
        return X_aligned


# ============ BATCHNORM ADAPTATION ============
def batchnorm_adapt(ilr_source, ilr_target, level, variant='wide256'):
    """
    Replace pretrained encoder's BatchNorm running stats with target-study stats.
    Then extract features using the adapted encoder.
    """
    fname = f"{MODEL_DIR}/{level}_v2_{variant}_best.pt"
    ckpt = torch.load(fname, map_location='cpu', weights_only=False)
    cfg = ckpt['config']
    
    enc = PhyloCompoCLREncoder(cfg['input_dim'], cfg['hidden_dims'], cfg['embed_dim'])
    enc.load_state_dict(ckpt['encoder_state_dict'])
    enc.eval()
    
    # Compute BN stats from target data
    enc.train()
    with torch.no_grad():
        _ = enc(torch.tensor(ilr_target, dtype=torch.float32))
    enc.eval()
    
    # Extract features with adapted BN stats
    def extract_with_hooks(model, data):
        extractor = {}
        hooks = []
        for name, module in model.named_modules():
            if isinstance(module, nn.Linear):
                def make_hook(n):
                    def hook(mod, inp, out):
                        extractor[n] = out.detach().numpy()
                    return hook
                h = module.register_forward_hook(make_hook(name))
                hooks.append(h)
        with torch.no_grad():
            _ = model(torch.tensor(data, dtype=torch.float32))
        for h in hooks:
            h.remove()
        layer_keys = sorted(extractor.keys())
        return extractor[layer_keys[-1]]
    
    emb_source = extract_with_hooks(enc, ilr_source)
    emb_target = extract_with_hooks(enc, ilr_target)
    
    return emb_source, emb_target


# ============ HELPER FUNCTIONS ============
def load_model(level, variant):
    fname = f"{MODEL_DIR}/{level}_v2_{variant}_best.pt"
    ckpt = torch.load(fname, map_location='cpu', weights_only=False)
    cfg = ckpt['config']
    return ckpt, cfg

def extract_all_features(ilr_t, ckpt, cfg):
    enc = PhyloCompoCLREncoder(cfg['input_dim'], cfg['hidden_dims'], cfg['embed_dim'])
    enc.load_state_dict(ckpt['encoder_state_dict'])
    enc.eval()
    X_t = torch.tensor(ilr_t, dtype=torch.float32)
    extractor = {}
    hooks = []
    for name, module in enc.named_modules():
        if isinstance(module, nn.Linear):
            def make_hook(n):
                def hook(mod, inp, out):
                    extractor[n] = out.detach().numpy()
                return hook
            h = module.register_forward_hook(make_hook(name))
            hooks.append(h)
    with torch.no_grad():
        _ = enc(X_t)
    for h in hooks:
        h.remove()
    layer_keys = sorted(extractor.keys())
    emb = extractor[layer_keys[-1]]
    all_layers = np.hstack([extractor[k] for k in layer_keys])
    return emb, all_layers, layer_keys


# ============ LEAVE-ONE-STUDY-OUT EVALUATION ============
def leave_one_study_out_eval(disease, level, min_cases_per_study=50):
    """Leave-one-study-out evaluation with domain adaptation."""
    ilr = pd.read_csv(f"{DATA_DIR}/{level}_philr_transform.csv", index_col=0)
    meta = pd.read_csv(f"{DATA_DIR}/sample_metadata.csv", index_col=0, low_memory=False)
    common = ilr.index.intersection(meta.index)
    ilr_v = ilr.loc[common].values
    meta_l = meta.loc[common]
    del ilr; import gc; gc.collect()
    
    col = f'{disease}_binary'
    mask = meta_l[col].notna()
    labels = meta_l.loc[mask, col].values.astype(int)
    ilr_t = ilr_v[mask.values]
    study_names = meta_l.loc[mask, 'study_name'].values
    
    key = f"{level}_{disease}"
    print(f"\n{'='*70}")
    print(f"LEAVE-ONE-STUDY-OUT: {key}")
    print(f"  Total: n={len(labels)}, pos={labels.sum()}, neg={len(labels)-labels.sum()}")
    print(f"{'='*70}")
    
    # Identify studies with enough cases
    case_mask = labels == 1
    study_case_counts = pd.Series(study_names[case_mask]).value_counts()
    eligible_studies = study_case_counts[study_case_counts >= min_cases_per_study].index.tolist()
    
    print(f"  Eligible studies (>= {min_cases_per_study} cases): {eligible_studies}")
    
    if len(eligible_studies) < 2:
        print(f"  Not enough studies for LOSO. Need >= 2, got {len(eligible_studies)}")
        return None
    
    # Load model for feature extraction
    ckpt_256, cfg_256 = load_model(level, 'wide256')
    print("  Extracting V2 features...")
    emb_256, all_layers_256, _ = extract_all_features(ilr_t, ckpt_256, cfg_256)
    X_v2enh = np.hstack([emb_256, ilr_t])
    
    study_to_id = {s: i for i, s in enumerate(eligible_studies)}
    results = {}
    
    for held_out_study in eligible_studies:
        print(f"\n  --- Held-out study: {held_out_study} ---")
        
        train_mask = study_names != held_out_study
        test_mask = study_names == held_out_study
        
        # Only use samples from eligible studies for train
        train_eligible = train_mask & np.isin(study_names, eligible_studies)
        
        X_train_ilr = ilr_t[train_eligible]
        X_test_ilr = ilr_t[test_mask]
        y_train = labels[train_eligible]
        y_test = labels[test_mask]
        
        X_train_v2 = X_v2enh[train_eligible]
        X_test_v2 = X_v2enh[test_mask]
        
        n_train_pos = y_train.sum()
        n_test_pos = y_test.sum()
        print(f"    Train: {len(y_train)} (pos={n_train_pos}), Test: {len(y_test)} (pos={n_test_pos})")
        
        if n_test_pos < 5 or n_train_pos < 20:
            print(f"    Skipping: too few samples")
            continue
        
        study_result = {}
        
        # ---- BASELINE: No DA ----
        clf = XGBClassifier(**XGB_PARAMS)
        clf.fit(X_train_v2, y_train)
        prob_baseline = clf.predict_proba(X_test_v2)[:, 1]
        auc_baseline = roc_auc_score(y_test, prob_baseline)
        study_result['no_da'] = auc_baseline
        print(f"    No DA: AUC={auc_baseline:.4f}")
        
        # ---- DEBIAS-M ----
        try:
            batch_ids_train = np.array([study_to_id[s] for s in study_names[train_eligible]])
            test_batch_id = len(eligible_studies)
            
            all_ilr = np.vstack([X_train_ilr, X_test_ilr])
            all_labels = np.concatenate([y_train, y_test])
            all_batch = np.concatenate([batch_ids_train, np.full(len(y_test), test_batch_id)])
            
            debias = DebiasM(n_features=ilr_t.shape[1], n_batches=len(eligible_studies) + 1,
                           lr=0.01, epochs=200)
            debias.fit(all_ilr, all_batch, all_labels)
            ilr_corrected = debias.transform(all_ilr, all_batch)
            
            X_train_corr = ilr_corrected[:len(y_train)]
            X_test_corr = ilr_corrected[len(y_train):]
            
            X_train_debias = np.hstack([emb_256[train_eligible], X_train_corr])
            X_test_debias = np.hstack([emb_256[test_mask], X_test_corr])
            
            clf_debias = XGBClassifier(**XGB_PARAMS)
            clf_debias.fit(X_train_debias, y_train)
            prob_debias = clf_debias.predict_proba(X_test_debias)[:, 1]
            auc_debias = roc_auc_score(y_test, prob_debias)
            study_result['debias_m'] = auc_debias
            print(f"    DEBIAS-M: AUC={auc_debias:.4f} (delta={auc_debias-auc_baseline:+.4f})")
        except Exception as e:
            print(f"    DEBIAS-M failed: {e}")
            study_result['debias_m'] = None
        
        # ---- CORAL ----
        try:
            coral = CORAL()
            coral.fit(X_train_ilr, X_test_ilr)
            X_train_coral = coral.transform(X_train_ilr)
            
            X_train_coral_v2 = np.hstack([emb_256[train_eligible], X_train_coral])
            X_test_coral_v2 = np.hstack([emb_256[test_mask], X_test_ilr])
            
            clf_coral = XGBClassifier(**XGB_PARAMS)
            clf_coral.fit(X_train_coral_v2, y_train)
            prob_coral = clf_coral.predict_proba(X_test_coral_v2)[:, 1]
            auc_coral = roc_auc_score(y_test, prob_coral)
            study_result['coral'] = auc_coral
            print(f"    CORAL: AUC={auc_coral:.4f} (delta={auc_coral-auc_baseline:+.4f})")
        except Exception as e:
            print(f"    CORAL failed: {e}")
            study_result['coral'] = None
        
        # ---- BatchNorm Adaptation ----
        try:
            emb_source_adapted, emb_target_adapted = batchnorm_adapt(
                X_train_ilr, X_test_ilr, level, 'wide256')
            
            X_train_bn = np.hstack([emb_source_adapted, X_train_ilr])
            X_test_bn = np.hstack([emb_target_adapted, X_test_ilr])
            
            clf_bn = XGBClassifier(**XGB_PARAMS)
            clf_bn.fit(X_train_bn, y_train)
            prob_bn = clf_bn.predict_proba(X_test_bn)[:, 1]
            auc_bn = roc_auc_score(y_test, prob_bn)
            study_result['bn_adapt'] = auc_bn
            print(f"    BN Adapt: AUC={auc_bn:.4f} (delta={auc_bn-auc_baseline:+.4f})")
        except Exception as e:
            print(f"    BN Adapt failed: {e}")
            study_result['bn_adapt'] = None
        
        results[held_out_study] = study_result
    
    # Summary
    print(f"\n  === LOSO Summary for {key} ===")
    methods = ['no_da', 'debias_m', 'coral', 'bn_adapt']
    summary = {}
    for m in methods:
        vals = [results[s][m] for s in results if results[s].get(m) is not None]
        if vals:
            summary[m] = {'mean': float(np.mean(vals)), 'std': float(np.std(vals)), 'n': len(vals)}
            print(f"    {m:12s}: mean={np.mean(vals):.4f}, std={np.std(vals):.4f}, n={len(vals)}")
        else:
            print(f"    {m:12s}: no results")
    
    save_data = {
        'key': key, 'disease': disease, 'level': level,
        'method': 'leave_one_study_out',
        'eligible_studies': eligible_studies,
        'per_study_results': results,
        'summary': summary
    }
    
    save_path = f"/mnt/results/da_{key}_loso_results.json"
    with open(save_path, 'w') as f:
        json.dump(save_data, f, indent=2, default=str)
    print(f"  Saved {save_path}")
    
    return save_data


# ============ RUN ============
if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--disease', choices=['ibd', 'cd', 'uc', 'crc', 't2d'], required=True)
    parser.add_argument('--level', choices=['genus', 'species'], required=True)
    parser.add_argument('--min-cases', type=int, default=50)
    args = parser.parse_args()
    
    result = leave_one_study_out_eval(args.disease, args.level, args.min_cases)
