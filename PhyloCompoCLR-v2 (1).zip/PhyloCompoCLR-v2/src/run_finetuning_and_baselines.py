"""
PhyloCompoCLR V2 — Fine-tuning + Additional Baselines + DeLong Tests

Runs:
1. Full fine-tuning (V2 + V1, genus/species, T2D/T1D)
2. Progressive unfreezing (V2 + V1, genus/species, T2D/T1D)
3. Additional baselines: MLP from scratch, LASSO on ILR/CLR, XGBoost on ILR
4. DeLong tests on all new pairwise comparisons
5. Gradient attribution for interpretability

All with same CV splits, saving raw predictions for DeLong.
"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler
import json
import os
import sys
import warnings
warnings.filterwarnings('ignore')

sys.path.insert(0, "/mnt/shared-workspace")
from phylocompoclr_v2_train import PhyloCompoCLREncoder

# ============ Configuration ============
DATA_DIR = "/mnt/shared-workspace/cmd3_data"
MODEL_DIR = "/mnt/shared-workspace/models"
RESULTS_DIR = "/mnt/results"
DEVICE = "cpu"
RANDOM_STATE = 42

# ============ Data Loading ============

def load_data(level='genus'):
    """Load ILR/CLR features and metadata."""
    if level == 'genus':
        ilr = pd.read_csv(f"{DATA_DIR}/genus_philr_transform.csv", index_col=0)
        clr = pd.read_csv(f"{DATA_DIR}/genus_clr_transform.csv", index_col=0)
    else:
        ilr = pd.read_csv(f"{DATA_DIR}/species_philr_transform.csv", index_col=0)
        clr = pd.read_csv(f"{DATA_DIR}/species_clr_transform.csv", index_col=0)
    
    meta = pd.read_csv(f"{DATA_DIR}/sample_metadata.csv", index_col=0)
    
    # Align samples
    common = ilr.index.intersection(clr.index).intersection(meta.index)
    ilr = ilr.loc[common]
    clr = clr.loc[common]
    meta = meta.loc[common]
    
    return ilr.values, clr.values, meta, common


def get_task_data(ilr, clr, meta, task='t2d'):
    """Extract task-specific samples and labels."""
    if task == 't2d':
        mask = meta['t2d_binary'].notna()
        labels = meta.loc[mask, 't2d_binary'].values.astype(int)
    elif task == 't1d':
        mask = meta['t1d_binary'].notna()
        labels = meta.loc[mask, 't1d_binary'].values.astype(int)
    else:
        raise ValueError(f"Unknown task: {task}")
    
    ilr_task = ilr[mask.values]
    clr_task = clr[mask.values]
    n_folds = 5 if task == 't2d' else 3
    
    return ilr_task, clr_task, labels, n_folds


# ============ Encoder Loading ============

def load_v2_encoder(level='genus', device='cpu'):
    """Load V2 pretrained encoder."""
    path = f"{MODEL_DIR}/{level}_v2_full_best.pt"
    ckpt = torch.load(path, map_location=device, weights_only=False)
    config = ckpt['config']
    encoder = PhyloCompoCLREncoder(
        input_dim=config['input_dim'],
        hidden_dims=config['hidden_dims'],
        embed_dim=config['embed_dim']
    )
    encoder.load_state_dict(ckpt['encoder_state_dict'])
    return encoder, config


def load_v1_encoder(level='genus', device='cpu'):
    """Load V1 CLR pretrained encoder."""
    path = f"{MODEL_DIR}/{level}_v1_clr_best.pt"
    ckpt = torch.load(path, map_location=device, weights_only=False)
    config = ckpt['config']
    
    if level == 'species':
        # V1 species uses self.net (nn.Sequential)
        layers = []
        prev_dim = config['input_dim']
        for h_dim in config['hidden_dims']:
            layers.extend([
                nn.Linear(prev_dim, h_dim),
                nn.BatchNorm1d(h_dim),
                nn.ReLU()
            ])
            prev_dim = h_dim
        layers.append(nn.Linear(prev_dim, config['embed_dim']))
        encoder = nn.Sequential(*layers)
        state = ckpt['encoder_state_dict']
        encoder.load_state_dict(state)
    else:
        # V1 genus uses self.encoder (same as V2)
        encoder = PhyloCompoCLREncoder(
            input_dim=config['input_dim'],
            hidden_dims=config['hidden_dims'],
            embed_dim=config['embed_dim']
        )
        encoder.load_state_dict(ckpt['encoder_state_dict'])
    
    return encoder, config


def extract_embeddings(encoder, X, device='cpu', batch_size=512):
    """Extract embeddings from encoder."""
    encoder.to(device)
    encoder.eval()
    X_t = torch.tensor(X, dtype=torch.float32)
    embeddings = []
    with torch.no_grad():
        for i in range(0, len(X_t), batch_size):
            batch = X_t[i:i+batch_size].to(device)
            emb = encoder(batch)
            embeddings.append(emb.cpu().numpy())
    return np.vstack(embeddings)


# ============ Fine-tuning Models ============

class FineTuneModel(nn.Module):
    """Pretrained encoder + classifier head."""
    def __init__(self, encoder, embed_dim, n_classes):
        super().__init__()
        self.encoder = encoder
        self.classifier = nn.Sequential(
            nn.Linear(embed_dim, 64),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(64, n_classes)
        )
    
    def forward(self, x):
        h = self.encoder(x)
        return self.classifier(h)


class MLPFromScratch(nn.Module):
    """Same architecture as V2 encoder + classifier, trained from scratch."""
    def __init__(self, input_dim, hidden_dims, embed_dim, n_classes):
        super().__init__()
        layers = []
        prev_dim = input_dim
        for h_dim in hidden_dims:
            layers.extend([
                nn.Linear(prev_dim, h_dim),
                nn.BatchNorm1d(h_dim),
                nn.ReLU()
            ])
            prev_dim = h_dim
        layers.append(nn.Linear(prev_dim, embed_dim))
        self.encoder = nn.Sequential(*layers)
        self.classifier = nn.Sequential(
            nn.Linear(embed_dim, 64),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(64, n_classes)
        )
    
    def forward(self, x):
        h = self.encoder(x)
        return self.classifier(h)


# ============ Training Functions ============

def train_full_finetune(X, y, encoder_fn, level, n_folds=5, 
                        ft_epochs=50, ft_lr=1e-4, device='cpu'):
    """Full fine-tuning: all weights updated."""
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=RANDOM_STATE)
    fold_results = []
    all_preds = []
    
    for fold_idx, (train_idx, test_idx) in enumerate(skf.split(X, y)):
        print(f"    Fold {fold_idx+1}/{n_folds}", end="", flush=True)
        
        # Fresh encoder per fold
        encoder, config = encoder_fn(level, device)
        embed_dim = config['embed_dim']
        n_classes = len(np.unique(y))
        
        model = FineTuneModel(encoder, embed_dim, n_classes).to(device)
        
        X_train = torch.tensor(X[train_idx], dtype=torch.float32).to(device)
        y_train = torch.tensor(y[train_idx], dtype=torch.long).to(device)
        X_test = torch.tensor(X[test_idx], dtype=torch.float32).to(device)
        y_test_np = y[test_idx]
        
        optimizer = torch.optim.Adam(model.parameters(), lr=ft_lr, weight_decay=1e-4)
        criterion = nn.CrossEntropyLoss()
        
        # Training with early stopping
        best_auc = 0
        patience = 10
        patience_counter = 0
        
        # Split train into train/val for early stopping
        n_val = max(1, len(train_idx) // 5)
        val_idx_es = train_idx[:n_val]
        train_idx_es = train_idx[n_val:]
        
        X_tr = torch.tensor(X[train_idx_es], dtype=torch.float32).to(device)
        y_tr = torch.tensor(y[train_idx_es], dtype=torch.long).to(device)
        X_val = torch.tensor(X[val_idx_es], dtype=torch.float32).to(device)
        y_val = y[val_idx_es]
        
        for epoch in range(ft_epochs):
            model.train()
            optimizer.zero_grad()
            logits = model(X_tr)
            loss = criterion(logits, y_tr)
            loss.backward()
            optimizer.step()
            
            # Validation AUC
            if (epoch + 1) % 5 == 0:
                model.eval()
                with torch.no_grad():
                    val_logits = model(X_val)
                    val_prob = torch.softmax(val_logits, dim=1).cpu().numpy()
                    if n_classes == 2:
                        val_auc = roc_auc_score(y_val, val_prob[:, 1])
                    else:
                        val_auc = roc_auc_score(y_val, val_prob, multi_class='ovr')
                    if val_auc > best_auc:
                        best_auc = val_auc
                        patience_counter = 0
                    else:
                        patience_counter += 1
                    if patience_counter >= patience // 5:
                        break
        
        # Final evaluation on test set
        model.eval()
        with torch.no_grad():
            logits = model(X_test)
            y_prob = torch.softmax(logits, dim=1).cpu().numpy()
            y_pred = logits.argmax(dim=1).cpu().numpy()
        
        if n_classes == 2:
            auc = roc_auc_score(y_test_np, y_prob[:, 1])
        else:
            auc = roc_auc_score(y_test_np, y_prob, multi_class='ovr')
        
        fold_results.append({'fold': fold_idx, 'auc': auc})
        all_preds.append({'y_true': y_test_np.tolist(), 'y_prob': y_prob[:, 1].tolist() if n_classes == 2 else y_prob.tolist()})
        print(f" AUC={auc:.4f}")
    
    aucs = [r['auc'] for r in fold_results]
    return {
        'fold_results': fold_results,
        'auc_mean': np.mean(aucs),
        'auc_std': np.std(aucs),
        'fold_predictions': all_preds
    }


def train_progressive_unfreezing(X, y, encoder_fn, level, n_folds=5, device='cpu'):
    """Progressive unfreezing: head -> last layer -> full network."""
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=RANDOM_STATE)
    fold_results = []
    all_preds = []
    
    for fold_idx, (train_idx, test_idx) in enumerate(skf.split(X, y)):
        print(f"    Fold {fold_idx+1}/{n_folds}", end="", flush=True)
        
        encoder, config = encoder_fn(level, device)
        embed_dim = config['embed_dim']
        n_classes = len(np.unique(y))
        
        model = FineTuneModel(encoder, embed_dim, n_classes).to(device)
        
        X_train = torch.tensor(X[train_idx], dtype=torch.float32).to(device)
        y_train = torch.tensor(y[train_idx], dtype=torch.long).to(device)
        X_test = torch.tensor(X[test_idx], dtype=torch.float32).to(device)
        y_test_np = y[test_idx]
        
        criterion = nn.CrossEntropyLoss()
        
        # Stage 1: Freeze encoder, train head only (10 epochs)
        for param in model.encoder.parameters():
            param.requires_grad = False
        optimizer = torch.optim.Adam(model.classifier.parameters(), lr=1e-3, weight_decay=1e-4)
        
        for epoch in range(10):
            model.train()
            optimizer.zero_grad()
            logits = model(X_train)
            loss = criterion(logits, y_train)
            loss.backward()
            optimizer.step()
        
        # Stage 2: Unfreeze last encoder layer (20 epochs)
        encoder_layers = list(model.encoder.children())
        for param in model.encoder.parameters():
            param.requires_grad = False
        # Unfreeze last Linear layer
        for layer in reversed(encoder_layers):
            if isinstance(layer, nn.Linear):
                for param in layer.parameters():
                    param.requires_grad = True
                break
        
        optimizer = torch.optim.Adam(
            filter(lambda p: p.requires_grad, model.parameters()),
            lr=1e-4, weight_decay=1e-4
        )
        
        for epoch in range(20):
            model.train()
            optimizer.zero_grad()
            logits = model(X_train)
            loss = criterion(logits, y_train)
            loss.backward()
            optimizer.step()
        
        # Stage 3: Unfreeze all (20 epochs, small LR)
        for param in model.encoder.parameters():
            param.requires_grad = True
        
        optimizer = torch.optim.Adam(model.parameters(), lr=1e-5, weight_decay=1e-4)
        
        for epoch in range(20):
            model.train()
            optimizer.zero_grad()
            logits = model(X_train)
            loss = criterion(logits, y_train)
            loss.backward()
            optimizer.step()
        
        # Final evaluation
        model.eval()
        with torch.no_grad():
            logits = model(X_test)
            y_prob = torch.softmax(logits, dim=1).cpu().numpy()
        
        if n_classes == 2:
            auc = roc_auc_score(y_test_np, y_prob[:, 1])
        else:
            auc = roc_auc_score(y_test_np, y_prob, multi_class='ovr')
        
        fold_results.append({'fold': fold_idx, 'auc': auc})
        all_preds.append({'y_true': y_test_np.tolist(), 'y_prob': y_prob[:, 1].tolist() if n_classes == 2 else y_prob.tolist()})
        print(f" AUC={auc:.4f}")
    
    aucs = [r['auc'] for r in fold_results]
    return {
        'fold_results': fold_results,
        'auc_mean': np.mean(aucs),
        'auc_std': np.std(aucs),
        'fold_predictions': all_preds
    }


def train_mlp_scratch(X, y, input_dim, hidden_dims, embed_dim, n_folds=5, 
                      epochs=100, lr=1e-3, device='cpu'):
    """MLP trained from scratch (no pretraining)."""
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=RANDOM_STATE)
    fold_results = []
    all_preds = []
    n_classes = len(np.unique(y))
    
    for fold_idx, (train_idx, test_idx) in enumerate(skf.split(X, y)):
        print(f"    Fold {fold_idx+1}/{n_folds}", end="", flush=True)
        
        model = MLPFromScratch(input_dim, hidden_dims, embed_dim, n_classes).to(device)
        
        X_train = torch.tensor(X[train_idx], dtype=torch.float32).to(device)
        y_train = torch.tensor(y[train_idx], dtype=torch.long).to(device)
        X_test = torch.tensor(X[test_idx], dtype=torch.float32).to(device)
        y_test_np = y[test_idx]
        
        optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=1e-4)
        criterion = nn.CrossEntropyLoss()
        
        for epoch in range(epochs):
            model.train()
            optimizer.zero_grad()
            logits = model(X_train)
            loss = criterion(logits, y_train)
            loss.backward()
            optimizer.step()
        
        model.eval()
        with torch.no_grad():
            logits = model(X_test)
            y_prob = torch.softmax(logits, dim=1).cpu().numpy()
        
        if n_classes == 2:
            auc = roc_auc_score(y_test_np, y_prob[:, 1])
        else:
            auc = roc_auc_score(y_test_np, y_prob, multi_class='ovr')
        
        fold_results.append({'fold': fold_idx, 'auc': auc})
        all_preds.append({'y_true': y_test_np.tolist(), 'y_prob': y_prob[:, 1].tolist() if n_classes == 2 else y_prob.tolist()})
        print(f" AUC={auc:.4f}")
    
    aucs = [r['auc'] for r in fold_results]
    return {
        'fold_results': fold_results,
        'auc_mean': np.mean(aucs),
        'auc_std': np.std(aucs),
        'fold_predictions': all_preds
    }


# ============ Sklearn Baselines ============

def run_lasso(X, y, n_folds=5, penalty='l1'):
    """LASSO (L1) logistic regression."""
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=RANDOM_STATE)
    fold_results = []
    all_preds = []
    solver = 'saga' if penalty == 'l1' else 'lbfgs'
    
    for fold_idx, (train_idx, test_idx) in enumerate(skf.split(X, y)):
        scaler = StandardScaler()
        X_train = scaler.fit_transform(X[train_idx])
        X_test = scaler.transform(X[test_idx])
        y_train = y[train_idx]
        y_test = y[test_idx]
        
        clf = LogisticRegression(
            penalty=penalty, C=1.0, solver=solver, max_iter=2000,
            random_state=RANDOM_STATE
        )
        clf.fit(X_train, y_train)
        y_prob = clf.predict_proba(X_test)
        
        n_classes = len(np.unique(y))
        if n_classes == 2:
            auc = roc_auc_score(y_test, y_prob[:, 1])
        else:
            auc = roc_auc_score(y_test, y_prob, multi_class='ovr')
        
        fold_results.append({'fold': fold_idx, 'auc': auc})
        all_preds.append({'y_true': y_test.tolist(), 'y_prob': y_prob[:, 1].tolist() if n_classes == 2 else y_prob.tolist()})
        print(f"    Fold {fold_idx+1}: AUC={auc:.4f}")
    
    aucs = [r['auc'] for r in fold_results]
    return {
        'fold_results': fold_results,
        'auc_mean': np.mean(aucs),
        'auc_std': np.std(aucs),
        'fold_predictions': all_preds
    }


def run_xgboost(X, y, n_folds=5):
    """XGBoost classifier."""
    try:
        from xgboost import XGBClassifier
    except ImportError:
        print("    XGBoost not available, skipping")
        return None
    
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=RANDOM_STATE)
    fold_results = []
    all_preds = []
    n_classes = len(np.unique(y))
    
    for fold_idx, (train_idx, test_idx) in enumerate(skf.split(X, y)):
        X_train, X_test = X[train_idx], X[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]
        
        clf = XGBClassifier(
            n_estimators=500, max_depth=6, learning_rate=0.1,
            random_state=RANDOM_STATE, use_label_encoder=False,
            eval_metric='logloss' if n_classes == 2 else 'mlogloss',
            objective='binary:logistic' if n_classes == 2 else 'multi:softprob'
        )
        clf.fit(X_train, y_train)
        y_prob = clf.predict_proba(X_test)
        
        if n_classes == 2:
            auc = roc_auc_score(y_test, y_prob[:, 1])
        else:
            auc = roc_auc_score(y_test, y_prob, multi_class='ovr')
        
        fold_results.append({'fold': fold_idx, 'auc': auc})
        all_preds.append({'y_true': y_test.tolist(), 'y_prob': y_prob[:, 1].tolist() if n_classes == 2 else y_prob.tolist()})
        print(f"    Fold {fold_idx+1}: AUC={auc:.4f}")
    
    aucs = [r['auc'] for r in fold_results]
    return {
        'fold_results': fold_results,
        'auc_mean': np.mean(aucs),
        'auc_std': np.std(aucs),
        'fold_predictions': all_preds
    }


# ============ DeLong Test ============

def _compute_midrank(x):
    sorted_idx = np.argsort(x)
    n = len(x)
    midranks = np.zeros(n)
    i = 0
    while i < n:
        j = i
        while j < n - 1 and x[sorted_idx[j+1]] == x[sorted_idx[j]]:
            j += 1
        rank = (i + j + 2.0) / 2.0
        for k in range(i, j+1):
            midranks[sorted_idx[k]] = rank
        i = j + 1
    return midranks


def delong_roc_test(y_true, y_pred_A, y_pred_B):
    """DeLong test for two correlated ROC curves."""
    n = len(y_true)
    n_pos = np.sum(y_true == 1)
    n_neg = n - n_pos
    
    if n_pos == 0 or n_neg == 0:
        return 1.0, 0.0
    
    auc_A = roc_auc_score(y_true, y_pred_A)
    auc_B = roc_auc_score(y_true, y_pred_B)
    
    V10_A = np.zeros(n_pos)
    V01_A = np.zeros(n_neg)
    V10_B = np.zeros(n_pos)
    V01_B = np.zeros(n_neg)
    
    pos_idx = np.where(y_true == 1)[0]
    neg_idx = np.where(y_true == 0)[0]
    
    for i, pi in enumerate(pos_idx):
        V10_A[i] = np.mean(y_pred_A[pi] > y_pred_A[neg_idx]) + 0.5 * np.mean(y_pred_A[pi] == y_pred_A[neg_idx])
        V10_B[i] = np.mean(y_pred_B[pi] > y_pred_B[neg_idx]) + 0.5 * np.mean(y_pred_B[pi] == y_pred_B[neg_idx])
    
    for j, ni in enumerate(neg_idx):
        V01_A[j] = np.mean(y_pred_A[ni] < y_pred_A[pos_idx]) + 0.5 * np.mean(y_pred_A[ni] == y_pred_A[pos_idx])
        V01_B[j] = np.mean(y_pred_B[ni] < y_pred_B[pos_idx]) + 0.5 * np.mean(y_pred_B[ni] == y_pred_B[pos_idx])
    
    S10 = np.cov(np.vstack([V10_A, V10_B]))
    S01 = np.cov(np.vstack([V01_A, V01_B]))
    S = S10 / n_neg + S01 / n_pos
    
    var_diff = S[0, 0] + S[1, 1] - 2 * S[0, 1]
    
    if var_diff <= 0:
        return 1.0, auc_A - auc_B
    
    z = (auc_A - auc_B) / np.sqrt(var_diff)
    
    from scipy.stats import norm
    p_value = 2 * (1 - norm.cdf(abs(z)))
    
    return p_value, auc_A - auc_B


def delong_paired_test(all_preds_A, all_preds_B):
    """DeLong test combining fold predictions."""
    all_y_true = []
    all_y_prob_A = []
    all_y_prob_B = []
    
    for fold_a, fold_b in zip(all_preds_A, all_preds_B):
        all_y_true.extend(fold_a['y_true'])
        all_y_prob_A.extend(fold_a['y_prob'])
        all_y_prob_B.extend(fold_b['y_prob'])
    
    y_true = np.array(all_y_true)
    y_prob_A = np.array(all_y_prob_A)
    y_prob_B = np.array(all_y_prob_B)
    
    p_value, delta_auc = delong_roc_test(y_true, y_prob_A, y_prob_B)
    auc_A = roc_auc_score(y_true, y_prob_A)
    auc_B = roc_auc_score(y_true, y_prob_B)
    
    return {
        'auc_A': auc_A,
        'auc_B': auc_B,
        'delta_auc': delta_auc,
        'p_value_raw': p_value,
    }


def benjamini_hochberg(p_values):
    n = len(p_values)
    if n == 0:
        return []
    sorted_idx = np.argsort(p_values)
    sorted_p = p_values[sorted_idx]
    adjusted = np.zeros(n)
    for i in range(n):
        adjusted[i] = sorted_p[i] * n / (i + 1)
    for i in range(n - 2, -1, -1):
        adjusted[i] = min(adjusted[i], adjusted[i + 1])
    adjusted = np.minimum(adjusted, 1.0)
    result = np.zeros(n)
    result[sorted_idx] = adjusted
    return result


# ============ Gradient Attribution ============

def integrated_gradients(model, X_baseline, X_input, n_steps=50, device='cpu'):
    """Compute integrated gradients for binary classification."""
    model.to(device)
    model.eval()
    
    X_base = torch.tensor(X_baseline, dtype=torch.float32).to(device)
    X_inp = torch.tensor(X_input, dtype=torch.float32).to(device)
    
    alphas = torch.linspace(0, 1, n_steps + 1).to(device)
    all_grads = []
    
    for alpha in alphas:
        X_interp = X_base + alpha * (X_inp - X_base)
        X_interp.requires_grad_(True)
        
        logits = model(X_interp)
        score = logits[:, 1] if logits.shape[1] == 2 else logits.max(dim=1)[0]
        
        grad = torch.autograd.grad(score.sum(), X_interp)[0]
        all_grads.append(grad.detach().cpu().numpy())
    
    avg_grads = np.mean(all_grads, axis=0)
    ig = avg_grads * (X_inp.cpu().numpy() - X_base.cpu().numpy())
    
    return ig


# ============ Main Execution ============

def main():
    all_results = {}
    all_predictions = {}
    
    for level in ['genus', 'species']:
        print(f"\n{'='*60}")
        print(f"LEVEL: {level.upper()}")
        print(f"{'='*60}")
        
        ilr, clr, meta, sample_ids = load_data(level)
        level_results = {}
        level_preds = {}
        
        for task in ['t2d', 't1d']:
            print(f"\n--- Task: {task.upper()} ---")
            ilr_task, clr_task, labels, n_folds = get_task_data(ilr, clr, meta, task)
            print(f"  Samples: {len(labels)}, Cases: {labels.sum()}, Controls: {len(labels)-labels.sum()}")
            print(f"  ILR dim: {ilr_task.shape[1]}, CLR dim: {clr_task.shape[1]}")
            
            task_results = {}
            task_preds = {}
            
            # ---- 1. V2 Full Fine-tuning ----
            print(f"\n  [1/8] V2 Full Fine-tuning:")
            v2_ft = train_full_finetune(ilr_task, labels, load_v2_encoder, level, 
                                        n_folds=n_folds, device=DEVICE)
            task_results['V2_FT_full'] = {k: v for k, v in v2_ft.items() if k != 'fold_predictions'}
            task_preds['V2_FT_full'] = v2_ft['fold_predictions']
            print(f"  -> AUC = {v2_ft['auc_mean']:.4f} +/- {v2_ft['auc_std']:.4f}")
            
            # ---- 2. V2 Progressive Unfreezing ----
            print(f"\n  [2/8] V2 Progressive Unfreezing:")
            v2_pu = train_progressive_unfreezing(ilr_task, labels, load_v2_encoder, level,
                                                  n_folds=n_folds, device=DEVICE)
            task_results['V2_FT_progressive'] = {k: v for k, v in v2_pu.items() if k != 'fold_predictions'}
            task_preds['V2_FT_progressive'] = v2_pu['fold_predictions']
            print(f"  -> AUC = {v2_pu['auc_mean']:.4f} +/- {v2_pu['auc_std']:.4f}")
            
            best_v2_key = 'V2_FT_full' if v2_ft['auc_mean'] >= v2_pu['auc_mean'] else 'V2_FT_progressive'
            best_v2_auc = max(v2_ft['auc_mean'], v2_pu['auc_mean'])
            task_results['V2_FT_best'] = best_v2_key
            print(f"  -> Best V2 FT: {best_v2_key} (AUC={best_v2_auc:.4f})")
            
            # ---- 3. V1 Full Fine-tuning ----
            print(f"\n  [3/8] V1 CLR Full Fine-tuning:")
            v1_ft = train_full_finetune(clr_task, labels, load_v1_encoder, level,
                                         n_folds=n_folds, device=DEVICE)
            task_results['V1_FT_full'] = {k: v for k, v in v1_ft.items() if k != 'fold_predictions'}
            task_preds['V1_FT_full'] = v1_ft['fold_predictions']
            print(f"  -> AUC = {v1_ft['auc_mean']:.4f} +/- {v1_ft['auc_std']:.4f}")
            
            # ---- 4. V1 Progressive Unfreezing ----
            print(f"\n  [4/8] V1 CLR Progressive Unfreezing:")
            v1_pu = train_progressive_unfreezing(clr_task, labels, load_v1_encoder, level,
                                                  n_folds=n_folds, device=DEVICE)
            task_results['V1_FT_progressive'] = {k: v for k, v in v1_pu.items() if k != 'fold_predictions'}
            task_preds['V1_FT_progressive'] = v1_pu['fold_predictions']
            print(f"  -> AUC = {v1_pu['auc_mean']:.4f} +/- {v1_pu['auc_std']:.4f}")
            
            best_v1_key = 'V1_FT_full' if v1_ft['auc_mean'] >= v1_pu['auc_mean'] else 'V1_FT_progressive'
            best_v1_auc = max(v1_ft['auc_mean'], v1_pu['auc_mean'])
            task_results['V1_FT_best'] = best_v1_key
            print(f"  -> Best V1 FT: {best_v1_key} (AUC={best_v1_auc:.4f})")
            
            # ---- 5. MLP from scratch ----
            print(f"\n  [5/8] MLP from scratch:")
            if level == 'genus':
                mlp_config = {'input_dim': ilr_task.shape[1], 'hidden_dims': [512, 256, 128], 'embed_dim': 128}
            else:
                mlp_config = {'input_dim': ilr_task.shape[1], 'hidden_dims': [1024, 512, 256, 128], 'embed_dim': 128}
            
            mlp = train_mlp_scratch(ilr_task, labels, 
                                     mlp_config['input_dim'], mlp_config['hidden_dims'],
                                     mlp_config['embed_dim'], n_folds=n_folds, device=DEVICE)
            task_results['MLP_scratch'] = {k: v for k, v in mlp.items() if k != 'fold_predictions'}
            task_preds['MLP_scratch'] = mlp['fold_predictions']
            print(f"  -> AUC = {mlp['auc_mean']:.4f} +/- {mlp['auc_std']:.4f}")
            
            # ---- 6. LASSO on ILR ----
            print(f"\n  [6/8] LASSO on ILR:")
            lasso_ilr = run_lasso(ilr_task, labels, n_folds=n_folds, penalty='l1')
            task_results['LASSO_ILR'] = {k: v for k, v in lasso_ilr.items() if k != 'fold_predictions'}
            task_preds['LASSO_ILR'] = lasso_ilr['fold_predictions']
            print(f"  -> AUC = {lasso_ilr['auc_mean']:.4f} +/- {lasso_ilr['auc_std']:.4f}")
            
            # ---- 7. LASSO on CLR ----
            print(f"\n  [7/8] LASSO on CLR:")
            lasso_clr = run_lasso(clr_task, labels, n_folds=n_folds, penalty='l1')
            task_results['LASSO_CLR'] = {k: v for k, v in lasso_clr.items() if k != 'fold_predictions'}
            task_preds['LASSO_CLR'] = lasso_clr['fold_predictions']
            print(f"  -> AUC = {lasso_clr['auc_mean']:.4f} +/- {lasso_clr['auc_std']:.4f}")
            
            # ---- 8. XGBoost on ILR ----
            print(f"\n  [8/8] XGBoost on ILR:")
            xgb = run_xgboost(ilr_task, labels, n_folds=n_folds)
            if xgb is not None:
                task_results['XGBoost_ILR'] = {k: v for k, v in xgb.items() if k != 'fold_predictions'}
                task_preds['XGBoost_ILR'] = xgb['fold_predictions']
                print(f"  -> AUC = {xgb['auc_mean']:.4f} +/- {xgb['auc_std']:.4f}")
            
            level_results[task] = task_results
            level_preds[task] = task_preds
        
        all_results[level] = level_results
        all_predictions[level] = level_preds
    
    # ============ DeLong Tests ============
    print(f"\n{'='*60}")
    print("DELONG TESTS FOR NEW COMPARISONS")
    print(f"{'='*60}")
    
    # Load existing predictions from DeLong run
    existing_preds_path = f"{RESULTS_DIR}/delong_predictions.json"
    existing_preds = {}
    if os.path.exists(existing_preds_path):
        with open(existing_preds_path) as f:
            existing_preds = json.load(f)
    
    delong_new = {}
    
    for level in ['genus', 'species']:
        for task in ['t2d', 't1d']:
            key = f"{level}_{task}"
            preds = all_predictions[level][task]
            
            # Add existing LP/RF predictions
            if key in existing_preds:
                for method, method_preds in existing_preds[key].items():
                    if method not in preds:
                        preds[method] = method_preds
            
            # All pairwise DeLong tests
            methods = list(preds.keys())
            comparisons = []
            
            for i in range(len(methods)):
                for j in range(i+1, len(methods)):
                    mA, mB = methods[i], methods[j]
                    try:
                        result = delong_paired_test(preds[mA], preds[mB])
                        result['method_A'] = mA
                        result['method_B'] = mB
                        comparisons.append(result)
                    except Exception as e:
                        print(f"  DeLong failed for {mA} vs {mB}: {e}")
            
            # BH correction
            if comparisons:
                p_vals = np.array([c['p_value_raw'] for c in comparisons])
                p_bh = benjamini_hochberg(p_vals)
                for k, c in enumerate(comparisons):
                    c['p_value_bh'] = float(p_bh[k])
                    c['significant_bh_005'] = bool(p_bh[k] < 0.05)
            
            delong_new[key] = comparisons
            
            print(f"\n{key}: {len(comparisons)} comparisons")
            for c in comparisons:
                if 'V2_FT' in c['method_A'] or 'V2_FT' in c['method_B']:
                    sig = "***" if c['p_value_bh'] < 0.001 else "**" if c['p_value_bh'] < 0.01 else "*" if c['p_value_bh'] < 0.05 else "ns"
                    print(f"  {c['method_A']} vs {c['method_B']}: dAUC={c['delta_auc']:.4f}, p_BH={c['p_value_bh']:.4f} {sig}")
    
    # ============ Gradient Attribution ============
    print(f"\n{'='*60}")
    print("GRADIENT ATTRIBUTION")
    print(f"{'='*60}")
    
    grad_attr = {}
    
    for level in ['genus', 'species']:
        ilr, clr, meta, _ = load_data(level)
        
        for task in ['t2d', 't1d']:
            key = f"{level}_{task}"
            ilr_task, clr_task, labels, n_folds = get_task_data(ilr, clr, meta, task)
            
            print(f"\n  {key}:")
            
            best_ft_key = all_results[level][task]['V2_FT_best']
            
            encoder, config = load_v2_encoder(level, DEVICE)
            n_classes = 2
            model = FineTuneModel(encoder, config['embed_dim'], n_classes).to(DEVICE)
            
            skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=RANDOM_STATE)
            for fold_idx, (train_idx, test_idx) in enumerate(skf.split(ilr_task, labels)):
                if fold_idx > 0:
                    continue
                
                X_train = torch.tensor(ilr_task[train_idx], dtype=torch.float32).to(DEVICE)
                y_train = torch.tensor(labels[train_idx], dtype=torch.long).to(DEVICE)
                
                optimizer = torch.optim.Adam(model.parameters(), lr=1e-4, weight_decay=1e-4)
                criterion = nn.CrossEntropyLoss()
                for epoch in range(30):
                    model.train()
                    optimizer.zero_grad()
                    logits = model(X_train)
                    loss = criterion(logits, y_train)
                    loss.backward()
                    optimizer.step()
                
                pos_idx = np.where(labels[test_idx] == 1)[0][:20]
                X_test_pos = ilr_task[test_idx[pos_idx]]
                X_baseline = np.zeros_like(X_test_pos)
                
                ig = integrated_gradients(model, X_baseline, X_test_pos, n_steps=30, device=DEVICE)
                
                mean_attr = np.mean(np.abs(ig), axis=0)
                top_k = 20
                top_indices = np.argsort(mean_attr)[::-1][:top_k]
                
                grad_attr[key] = {
                    'top_indices': top_indices.tolist(),
                    'top_attributions': mean_attr[top_indices].tolist(),
                    'mean_attribution': mean_attr.tolist()
                }
                
                print(f"    Top 5 ILR balance indices: {top_indices[:5]}")
                print(f"    Top 5 attributions: {mean_attr[top_indices[:5]]}")
                break
    
    # ============ Save Everything ============
    print(f"\n{'='*60}")
    print("SAVING RESULTS")
    print(f"{'='*60}")
    
    def convert_numpy(obj):
        if isinstance(obj, np.integer): return int(obj)
        elif isinstance(obj, np.floating): return float(obj)
        elif isinstance(obj, np.ndarray): return obj.tolist()
        elif isinstance(obj, dict): return {k: convert_numpy(v) for k, v in obj.items()}
        elif isinstance(obj, list): return [convert_numpy(v) for v in obj]
        elif isinstance(obj, bool): return bool(obj)
        return obj
    
    results_serializable = convert_numpy(all_results)
    with open(f"{RESULTS_DIR}/finetuning_results.json", 'w') as f:
        json.dump(results_serializable, f, indent=2)
    print(f"  Saved: {RESULTS_DIR}/finetuning_results.json")
    
    preds_serializable = convert_numpy(all_predictions)
    with open(f"{RESULTS_DIR}/finetuning_predictions.json", 'w') as f:
        json.dump(preds_serializable, f, indent=2)
    print(f"  Saved: {RESULTS_DIR}/finetuning_predictions.json")
    
    delong_serializable = convert_numpy(delong_new)
    with open(f"{RESULTS_DIR}/delong_finetuning_results.json", 'w') as f:
        json.dump(delong_serializable, f, indent=2)
    print(f"  Saved: {RESULTS_DIR}/delong_finetuning_results.json")
    
    grad_serializable = convert_numpy(grad_attr)
    with open(f"{RESULTS_DIR}/gradient_attribution.json", 'w') as f:
        json.dump(grad_serializable, f, indent=2)
    print(f"  Saved: {RESULTS_DIR}/gradient_attribution.json")
    
    # ============ Summary ============
    print(f"\n{'='*60}")
    print("SUMMARY")
    print(f"{'='*60}")
    
    for level in ['genus', 'species']:
        for task in ['t2d', 't1d']:
            key = f"{level}_{task}"
            r = all_results[level][task]
            print(f"\n{key}:")
            for method in ['V2_FT_full', 'V2_FT_progressive', 'V1_FT_full', 'V1_FT_progressive',
                          'MLP_scratch', 'LASSO_ILR', 'LASSO_CLR', 'XGBoost_ILR']:
                if method in r and isinstance(r[method], dict):
                    print(f"  {method:<25} AUC={r[method]['auc_mean']:.4f} +/- {r[method]['auc_std']:.4f}")
            print(f"  Best V2 FT: {r['V2_FT_best']}")
            print(f"  Best V1 FT: {r['V1_FT_best']}")


if __name__ == '__main__':
    main()
