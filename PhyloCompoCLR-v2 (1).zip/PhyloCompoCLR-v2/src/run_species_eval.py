#!/usr/bin/env python3
"""Species-level evaluation for PhyloCompoCLR V2."""

import sys
sys.path.insert(0, "/mnt/shared-workspace")

import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import StratifiedKFold, StratifiedShuffleSplit
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, f1_score
import json, os

# Load species PhILR data
print("Loading species PhILR transform...")
species_philr = pd.read_csv("/mnt/shared-workspace/cmd3_data/species_philr_transform.csv", index_col=0)
species_ilr = species_philr.values.astype(np.float32)
sample_ids = species_philr.index.tolist()
del species_philr
import gc; gc.collect()

# Load metadata
metadata = pd.read_csv("/mnt/shared-workspace/cmd3_data/sample_metadata.csv", index_col=0, low_memory=False)
metadata_aligned = metadata.loc[sample_ids]

# Load encoder
from phylocompoclr_v2_train import PhyloCompoCLREncoder
encoder_path = "/mnt/shared-workspace/models/species_v2_full_best.pt"
checkpoint = torch.load(encoder_path, map_location='cpu', weights_only=False)
config = checkpoint['config']
encoder = PhyloCompoCLREncoder(config['input_dim'], config['hidden_dims'], config['embed_dim'])
encoder.load_state_dict(checkpoint['encoder_state_dict'])
encoder.eval()

# Extract embeddings
print("Extracting species-level embeddings...")
X = torch.tensor(species_ilr, dtype=torch.float32)
embeddings = []
with torch.no_grad():
    for i in range(0, len(X), 256):
        batch = X[i:i+256]
        emb = encoder(batch)
        embeddings.append(emb.numpy())
embeddings = np.vstack(embeddings)
print(f"Embeddings shape: {embeddings.shape}")

# T2D evaluation
print("\n=== T2D Classification (5-fold CV) ===")
t2d_mask = metadata_aligned['t2d_binary'].notna()
t2d_emb = embeddings[t2d_mask.values]
t2d_labels = metadata_aligned.loc[t2d_mask, 't2d_binary'].values.astype(int)
print(f"Samples: {len(t2d_labels)} (T2D={t2d_labels.sum()}, ctrl={len(t2d_labels)-t2d_labels.sum()})")

skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
t2d_lp_aucs = []
for fold_idx, (train_idx, test_idx) in enumerate(skf.split(t2d_emb, t2d_labels)):
    clf = LogisticRegression(max_iter=1000, C=1.0, random_state=42)
    clf.fit(t2d_emb[train_idx], t2d_labels[train_idx])
    y_prob = clf.predict_proba(t2d_emb[test_idx])[:, 1]
    auc = roc_auc_score(t2d_labels[test_idx], y_prob)
    t2d_lp_aucs.append(auc)
    print(f"  Fold {fold_idx}: AUC={auc:.3f}")
print(f"  Linear Probe: AUC={np.mean(t2d_lp_aucs):.3f} +/- {np.std(t2d_lp_aucs):.3f}")

# RF on species ILR
t2d_ilr = species_ilr[t2d_mask.values]
t2d_rf_aucs = []
for fold_idx, (train_idx, test_idx) in enumerate(skf.split(t2d_ilr, t2d_labels)):
    clf = RandomForestClassifier(n_estimators=500, random_state=42, n_jobs=-1)
    clf.fit(t2d_ilr[train_idx], t2d_labels[train_idx])
    y_prob = clf.predict_proba(t2d_ilr[test_idx])[:, 1]
    auc = roc_auc_score(t2d_labels[test_idx], y_prob)
    t2d_rf_aucs.append(auc)
print(f"  RF (ILR): AUC={np.mean(t2d_rf_aucs):.3f} +/- {np.std(t2d_rf_aucs):.3f}")

# T1D evaluation
print("\n=== T1D Classification ===")
t1d_mask = metadata_aligned['t1d_binary'].notna()
t1d_emb = embeddings[t1d_mask.values]
t1d_labels = metadata_aligned.loc[t1d_mask, 't1d_binary'].values.astype(int)
print(f"Samples: {len(t1d_labels)} (T1D={t1d_labels.sum()}, ctrl={len(t1d_labels)-t1d_labels.sum()})")

skf_t1d = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
t1d_lp_aucs = []
for fold_idx, (train_idx, test_idx) in enumerate(skf_t1d.split(t1d_emb, t1d_labels)):
    clf = LogisticRegression(max_iter=1000, C=1.0, random_state=42)
    clf.fit(t1d_emb[train_idx], t1d_labels[train_idx])
    y_prob = clf.predict_proba(t1d_emb[test_idx])[:, 1]
    auc = roc_auc_score(t1d_labels[test_idx], y_prob)
    t1d_lp_aucs.append(auc)
print(f"  Linear Probe: AUC={np.mean(t1d_lp_aucs):.3f} +/- {np.std(t1d_lp_aucs):.3f}")

# Glucose subgroup
print("\n=== Glucose Subgroup ===")
glucose_mask = metadata_aligned['glucose_status'].isin(['healthy', 'prediabetic', 'T2D'])
glucose_emb = embeddings[glucose_mask.values]
glucose_labels = metadata_aligned.loc[glucose_mask, 'glucose_status'].map(
    {'healthy': 0, 'prediabetic': 1, 'T2D': 2}).values.astype(int)
skf_g = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
glucose_lp_aucs = []
for fold_idx, (train_idx, test_idx) in enumerate(skf_g.split(glucose_emb, glucose_labels)):
    clf = LogisticRegression(max_iter=1000, C=1.0, random_state=42)
    clf.fit(glucose_emb[train_idx], glucose_labels[train_idx])
    y_prob = clf.predict_proba(glucose_emb[test_idx])
    auc = roc_auc_score(glucose_labels[test_idx], y_prob, multi_class='ovr')
    glucose_lp_aucs.append(auc)
print(f"  3-class OvR: AUC={np.mean(glucose_lp_aucs):.3f} +/- {np.std(glucose_lp_aucs):.3f}")

# IGT vs T2D
igt_t2d_mask = metadata_aligned['glucose_status'].isin(['prediabetic', 'T2D'])
igt_t2d_emb = embeddings[igt_t2d_mask.values]
igt_t2d_labels = metadata_aligned.loc[igt_t2d_mask, 'glucose_status'].map(
    {'prediabetic': 0, 'T2D': 1}).values.astype(int)
skf_igt = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
igt_lp_aucs = []
for fold_idx, (train_idx, test_idx) in enumerate(skf_igt.split(igt_t2d_emb, igt_t2d_labels)):
    clf = LogisticRegression(max_iter=1000, C=1.0, random_state=42)
    clf.fit(igt_t2d_emb[train_idx], igt_t2d_labels[train_idx])
    y_prob = clf.predict_proba(igt_t2d_emb[test_idx])[:, 1]
    auc = roc_auc_score(igt_t2d_labels[test_idx], y_prob)
    igt_lp_aucs.append(auc)
print(f"  IGT vs T2D: AUC={np.mean(igt_lp_aucs):.3f} +/- {np.std(igt_lp_aucs):.3f}")

# Data-limited
print("\n=== Data-Limited Learning Curves ===")
sample_sizes = [10, 20, 50, 100, 200, 500]
dl_results = {}
for n in sample_sizes:
    aucs = []
    for repeat in range(5):
        sss = StratifiedShuffleSplit(n_splits=1, train_size=n, random_state=42+repeat)
        for train_idx, test_idx in sss.split(t2d_emb, t2d_labels):
            clf = LogisticRegression(max_iter=1000, C=1.0)
            clf.fit(t2d_emb[train_idx], t2d_labels[train_idx])
            y_prob = clf.predict_proba(t2d_emb[test_idx])[:, 1]
            auc = roc_auc_score(t2d_labels[test_idx], y_prob)
            aucs.append(auc)
    dl_results[n] = {'auc_mean': np.mean(aucs), 'auc_std': np.std(aucs)}
    print(f"  n={n:4d}: AUC={np.mean(aucs):.3f} +/- {np.std(aucs):.3f}")

# Save results
species_eval = {
    't2d': {
        'linear_probe': {'auc_mean': float(np.mean(t2d_lp_aucs)), 'auc_std': float(np.std(t2d_lp_aucs))},
        'rf_ilr': {'auc_mean': float(np.mean(t2d_rf_aucs)), 'auc_std': float(np.std(t2d_rf_aucs))},
    },
    't1d': {
        'linear_probe': {'auc_mean': float(np.mean(t1d_lp_aucs)), 'auc_std': float(np.std(t1d_lp_aucs))},
    },
    'glucose_subgroup': {
        '3class_ovr': {'auc_mean': float(np.mean(glucose_lp_aucs)), 'auc_std': float(np.std(glucose_lp_aucs))},
        'igt_vs_t2d': {'auc_mean': float(np.mean(igt_lp_aucs)), 'auc_std': float(np.std(igt_lp_aucs))},
    },
    'data_limited': {
        str(n): {'auc_mean': float(v['auc_mean']), 'auc_std': float(v['auc_std'])} for n, v in dl_results.items()
    },
}

with open('/mnt/results/evaluation_species_v2.json', 'w') as f:
    json.dump(species_eval, f, indent=2)
print(f"\nSpecies evaluation saved to /mnt/results/evaluation_species_v2.json")
