#!/usr/bin/env python3
"""
Unified Clean Evaluation for PhyloCompoCLR V2
==============================================
All methods use IDENTICAL:
- CV splits (StratifiedKFold, random_state=42)
- XGBoost hyperparameters (n_estimators=300, max_depth=6, lr=0.1)
- RF hyperparameters (n_estimators=500, random_state=42)
- LASSO hyperparameters (C=1.0, saga, max_iter=2000)
- Fine-tuning hyperparameters (Adam, lr=1e-4, wd=1e-4, 50 epochs)
- MLP hyperparameters (Adam, lr=1e-3, wd=1e-4, 100 epochs)

Saves per-fold predictions for DeLong tests.
"""
import sys, os, json, time
import numpy as np, pandas as pd
import torch, torch.nn as nn, torch.optim as optim
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier
from itertools import combinations

sys.path.insert(0, "/mnt/shared-workspace")
from phylocompoclr_v2_train import PhyloCompoCLREncoder

DATA_DIR = "/mnt/shared-workspace/cmd3_data"
MODEL_DIR = "/mnt/shared-workspace/models"
RS = 42

# ============ UNIFIED HYPERPARAMETERS ============
XGB_PARAMS = dict(n_estimators=300, max_depth=6, learning_rate=0.1,
                  use_label_encoder=False, eval_metric='logloss', verbosity=0,
                  random_state=RS)
RF_PARAMS = dict(n_estimators=500, random_state=RS, n_jobs=-1)
LASSO_PARAMS = dict(penalty='l1', C=1.0, solver='saga', max_iter=2000)
FT_PARAMS = dict(lr=1e-4, weight_decay=1e-4, epochs=50)
MLP_PARAMS = dict(lr=1e-3, weight_decay=1e-4, epochs=100)

# ============ MODEL LOADING ============
def load_model(level, variant):
    """Load encoder checkpoint. variant: 'full' (128d) or 'wide256' (256d)"""
    if variant == 'full':
        fname = f"{MODEL_DIR}/{level}_v2_full_best.pt"
    elif variant == 'wide256':
        fname = f"{MODEL_DIR}/{level}_v2_wide256_best.pt"
    else:
        raise ValueError(f"Unknown variant: {variant}")
    ckpt = torch.load(fname, map_location='cpu', weights_only=False)
    cfg = ckpt['config']
    return ckpt, cfg

def extract_all_features(ilr_t, ckpt, cfg):
    """Extract features from ALL intermediate layers + final embedding."""
    enc = PhyloCompoCLREncoder(cfg['input_dim'], cfg['hidden_dims'], cfg['embed_dim'])
    enc.load_state_dict(ckpt['encoder_state_dict'])
    enc.eval()
    X_t = torch.tensor(ilr_t, dtype=torch.float32)
    
    extractor = {}
    hooks = []
    for name, module in enc.named_modules():
        if isinstance(module, nn.Linear):
            def make_hook(n):
                def hook(mod, inp, out):
                    extractor[n] = out.detach().numpy()
                return hook
            h = module.register_forward_hook(make_hook(name))
            hooks.append(h)
    with torch.no_grad():
        _ = enc(X_t)
    for h in hooks:
        h.remove()
    
    layer_keys = sorted(extractor.keys())
    emb = extractor[layer_keys[-1]]  # Final embedding
    all_layers = np.hstack([extractor[k] for k in layer_keys])
    return emb, all_layers, layer_keys

# ============ CLASSIFIERS ============
class FineTuneModel(nn.Module):
    def __init__(self, encoder, embed_dim, n_classes=2):
        super().__init__()
        self.encoder = encoder
        self.classifier = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(embed_dim // 2, n_classes)
        )
    def forward(self, x):
        return self.classifier(self.encoder(x))

class MLPFromScratch(nn.Module):
    def __init__(self, input_dim, hidden_dims, embed_dim, n_classes=2):
        super().__init__()
        layers = []
        prev_dim = input_dim
        for h_dim in hidden_dims:
            layers.extend([nn.Linear(prev_dim, h_dim), nn.BatchNorm1d(h_dim), nn.ReLU()])
            prev_dim = h_dim
        layers.append(nn.Linear(prev_dim, embed_dim))
        self.encoder = nn.Sequential(*layers)
        self.classifier = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(embed_dim // 2, n_classes)
        )
    def forward(self, x):
        return self.classifier(self.encoder(x))

# ============ EVALUATION FUNCTIONS ============
def run_ft(ilr_t, labels, ckpt, cfg, nfolds, head_dim=None):
    """Fine-tune with unified hyperparameters."""
    if head_dim is None:
        head_dim = cfg['embed_dim'] // 2
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tri, tei in skf.split(ilr_t, labels):
        enc = PhyloCompoCLREncoder(cfg['input_dim'], cfg['hidden_dims'], cfg['embed_dim'])
        enc.load_state_dict(ckpt['encoder_state_dict'])
        model = FineTuneModel(enc, cfg['embed_dim'])
        opt = optim.Adam(model.parameters(), lr=FT_PARAMS['lr'], weight_decay=FT_PARAMS['weight_decay'])
        X_tr = torch.tensor(ilr_t[tri], dtype=torch.float32)
        y_tr = torch.tensor(labels[tri], dtype=torch.long)
        X_te = torch.tensor(ilr_t[tei], dtype=torch.float32)
        model.train()
        for ep in range(FT_PARAMS['epochs']):
            opt.zero_grad()
            nn.CrossEntropyLoss()(model(X_tr), y_tr).backward()
            opt.step()
        model.eval()
        with torch.no_grad():
            prob = torch.softmax(model(X_te), dim=1)[:, 1].numpy()
        preds.append(prob)
        aucs.append(roc_auc_score(labels[tei], prob))
    return preds, aucs

def run_mlp(ilr_t, labels, cfg, nfolds):
    """MLP from scratch with unified hyperparameters."""
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tri, tei in skf.split(ilr_t, labels):
        model = MLPFromScratch(cfg['input_dim'], cfg['hidden_dims'], cfg['embed_dim'])
        opt = optim.Adam(model.parameters(), lr=MLP_PARAMS['lr'], weight_decay=MLP_PARAMS['weight_decay'])
        X_tr = torch.tensor(ilr_t[tri], dtype=torch.float32)
        y_tr = torch.tensor(labels[tri], dtype=torch.long)
        X_te = torch.tensor(ilr_t[tei], dtype=torch.float32)
        model.train()
        for ep in range(MLP_PARAMS['epochs']):
            opt.zero_grad()
            nn.CrossEntropyLoss()(model(X_tr), y_tr).backward()
            opt.step()
        model.eval()
        with torch.no_grad():
            prob = torch.softmax(model(X_te), dim=1)[:, 1].numpy()
        preds.append(prob)
        aucs.append(roc_auc_score(labels[tei], prob))
    return preds, aucs

def run_xgb(X, labels, nfolds):
    """XGBoost with unified hyperparameters."""
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tri, tei in skf.split(X, labels):
        clf = XGBClassifier(**XGB_PARAMS)
        clf.fit(X[tri], labels[tri])
        prob = clf.predict_proba(X[tei])[:, 1]
        preds.append(prob)
        aucs.append(roc_auc_score(labels[tei], prob))
    return preds, aucs

def run_rf(X, labels, nfolds):
    """RF with unified hyperparameters."""
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tri, tei in skf.split(X, labels):
        clf = RandomForestClassifier(**RF_PARAMS)
        clf.fit(X[tri], labels[tri])
        prob = clf.predict_proba(X[tei])[:, 1]
        preds.append(prob)
        aucs.append(roc_auc_score(labels[tei], prob))
    return preds, aucs

def run_lasso(X, labels, nfolds):
    """LASSO with unified hyperparameters."""
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tri, tei in skf.split(X, labels):
        scaler = StandardScaler()
        clf = LogisticRegression(**LASSO_PARAMS)
        clf.fit(scaler.fit_transform(X[tri]), labels[tri])
        prob = clf.predict_proba(scaler.transform(X[tei]))[:, 1]
        preds.append(prob)
        aucs.append(roc_auc_score(labels[tei], prob))
    return preds, aucs

def run_lp(emb, labels, nfolds):
    """Linear probe on embeddings."""
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tri, tei in skf.split(emb, labels):
        clf = LogisticRegression(max_iter=2000, C=1.0)
        clf.fit(emb[tri], labels[tri])
        prob = clf.predict_proba(emb[tei])[:, 1]
        preds.append(prob)
        aucs.append(roc_auc_score(labels[tei], prob))
    return preds, aucs

def run_stacking(all_preds, y_trues, nfolds, combo_methods):
    """Stacking with logistic regression meta-learner."""
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tf in range(nfolds):
        tm = np.column_stack([np.concatenate([all_preds[m][i] for i in range(nfolds) if i != tf]) for m in combo_methods])
        ty = np.concatenate([y_trues[i] for i in range(nfolds) if i != tf])
        tem = np.column_stack([all_preds[m][tf] for m in combo_methods])
        mc = LogisticRegression(max_iter=1000)
        mc.fit(tm, ty)
        mp = mc.predict_proba(tem)[:, 1]
        preds.append(mp)
        aucs.append(roc_auc_score(y_trues[tf], mp))
    return preds, aucs

# ============ DELONG TEST ============
def delong_roc_test(y_true, y_pred1, y_pred2):
    from scipy import stats
    n = len(y_true)
    n1 = np.sum(y_true == 1)
    n2 = np.sum(y_true == 0)
    auc1 = roc_auc_score(y_true, y_pred1)
    auc2 = roc_auc_score(y_true, y_pred2)
    
    def compute_placement(pred, labels):
        pos_pred = pred[labels == 1]
        neg_pred = pred[labels == 0]
        placements_pos = np.array([np.sum(neg_pred < p) + 0.5 * np.sum(neg_pred == p) for p in pos_pred]) / n2
        placements_neg = np.array([np.sum(pos_pred > p) + 0.5 * np.sum(pos_pred == p) for p in neg_pred]) / n1
        return placements_pos, placements_neg
    
    p1_pos, p1_neg = compute_placement(y_pred1, y_true)
    p2_pos, p2_neg = compute_placement(y_pred2, y_true)
    
    S1_pos, S1_neg = np.var(p1_pos, ddof=1), np.var(p1_neg, ddof=1)
    S2_pos, S2_neg = np.var(p2_pos, ddof=1), np.var(p2_neg, ddof=1)
    cov_pos = np.cov(p1_pos, p2_pos)[0, 1]
    cov_neg = np.cov(p1_neg, p2_neg)[0, 1]
    
    var_diff = (1/n1) * (S1_pos + S2_pos - 2*cov_pos) + (1/n2) * (S1_neg + S2_neg - 2*cov_neg)
    if var_diff <= 0:
        return 1.0, auc1, auc2
    z = (auc1 - auc2) / np.sqrt(var_diff)
    p_value = 2 * (1 - stats.norm.cdf(abs(z)))
    return p_value, auc1, auc2

# ============ MAIN EVALUATION ============
def evaluate_level_task(level, task, ilr_all, meta):
    """Run ALL methods with unified hyperparameters for one level/task combo."""
    col = f'{task}_binary'
    mask = meta[col].notna()
    labels = meta.loc[mask, col].values.astype(int)
    ilr_t = ilr_all[mask.values]
    nfolds = 5 if task == 't2d' else 3
    
    key = f"{level}_{task}"
    print(f"\n{'='*70}")
    print(f"UNIFIED EVALUATION: {key} (n={len(labels)}, {nfolds}-fold)")
    print(f"{'='*70}")
    
    # Load models
    ckpt_128, cfg_128 = load_model(level, 'full')
    ckpt_256, cfg_256 = load_model(level, 'wide256')
    
    # Extract features
    emb_128, all_layers_128, lk_128 = extract_all_features(ilr_t, ckpt_128, cfg_128)
    emb_256, all_layers_256, lk_256 = extract_all_features(ilr_t, ckpt_256, cfg_256)
    
    # Feature matrices
    X_v2enh_128 = np.hstack([emb_128, ilr_t])           # 128d emb + raw
    X_v2enh_256 = np.hstack([emb_256, ilr_t])           # 256d emb + raw
    X_allv2_128 = np.hstack([all_layers_128, ilr_t])    # all layers + raw (128d model)
    X_allv2_256 = np.hstack([all_layers_256, ilr_t])    # all layers + raw (256d model)
    
    # Run all methods
    results = {}
    all_preds = {}
    y_trues = []
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    for tri, tei in skf.split(ilr_t, labels):
        y_trues.append(labels[tei])
    
    # 1. Linear Probes
    for name, emb, cfg in [('V2_LP_128', emb_128, cfg_128), ('V2_LP_256', emb_256, cfg_256)]:
        p, a = run_lp(emb, labels, nfolds)
        all_preds[name] = p
        results[name] = {'auc_mean': np.mean(a), 'auc_std': np.std(a)}
        print(f"  {name}: {np.mean(a):.4f} ± {np.std(a):.4f}")
    
    # 2. Fine-tuning
    for name, ckpt, cfg in [('V2_FT_128', ckpt_128, cfg_128), ('V2_FT_256', ckpt_256, cfg_256)]:
        p, a = run_ft(ilr_t, labels, ckpt, cfg, nfolds)
        all_preds[name] = p
        results[name] = {'auc_mean': np.mean(a), 'auc_std': np.std(a)}
        print(f"  {name}: {np.mean(a):.4f} ± {np.std(a):.4f}")
    
    # 3. MLP from scratch (use 256d architecture as it's better)
    p, a = run_mlp(ilr_t, labels, cfg_256, nfolds)
    all_preds['MLP_scratch'] = p
    results['MLP_scratch'] = {'auc_mean': np.mean(a), 'auc_std': np.std(a)}
    print(f"  MLP_scratch: {np.mean(a):.4f} ± {np.std(a):.4f}")
    
    # 4. LASSO on ILR
    p, a = run_lasso(ilr_t, labels, nfolds)
    all_preds['LASSO_ILR'] = p
    results['LASSO_ILR'] = {'auc_mean': np.mean(a), 'auc_std': np.std(a)}
    print(f"  LASSO_ILR: {np.mean(a):.4f} ± {np.std(a):.4f}")
    
    # 5. RF on raw ILR
    p, a = run_rf(ilr_t, labels, nfolds)
    all_preds['RF_raw'] = p
    results['RF_raw'] = {'auc_mean': np.mean(a), 'auc_std': np.std(a)}
    print(f"  RF_raw: {np.mean(a):.4f} ± {np.std(a):.4f}")
    
    # 6. XGBoost variants (ALL with identical hyperparameters)
    for name, X in [('XGB_raw', ilr_t), 
                     ('XGB_V2enh_128', X_v2enh_128),
                     ('XGB_V2enh_256', X_v2enh_256),
                     ('XGB_allV2_128', X_allv2_128),
                     ('XGB_allV2_256', X_allv2_256)]:
        p, a = run_xgb(X, labels, nfolds)
        all_preds[name] = p
        results[name] = {'auc_mean': np.mean(a), 'auc_std': np.std(a)}
        print(f"  {name}: {np.mean(a):.4f} ± {np.std(a):.4f}")
    
    # 7. Stacking ensembles
    # Best combos from prior analysis: XGB_raw + XGB_allV2_256 + RF_raw
    stack_combos = {
        'Stack_XGB_RF': ['XGB_raw', 'RF_raw'],
        'Stack_XGB_V2enh_RF': ['XGB_raw', 'XGB_allV2_256', 'RF_raw'],
        'Stack_FT_XGB_RF': ['V2_FT_256', 'XGB_raw', 'RF_raw'],
        'Stack_all5': ['V2_FT_256', 'XGB_raw', 'XGB_allV2_256', 'RF_raw', 'LASSO_ILR'],
    }
    
    for sname, combo in stack_combos.items():
        p, a = run_stacking(all_preds, y_trues, nfolds, combo)
        all_preds[sname] = p
        results[sname] = {'auc_mean': np.mean(a), 'auc_std': np.std(a), 'combo': combo}
        print(f"  {sname}: {np.mean(a):.4f} ± {np.std(a):.4f}")
    
    # 8. DeLong tests on key comparisons
    print(f"\n--- DeLong Tests ({key}) ---")
    y_all = np.concatenate(y_trues)
    
    delong_comparisons = [
        ('XGB_allV2_256 vs XGB_raw', 'XGB_allV2_256', 'XGB_raw'),
        ('Stack_XGB_V2enh_RF vs XGB_raw', 'Stack_XGB_V2enh_RF', 'XGB_raw'),
        ('Stack_all5 vs XGB_raw', 'Stack_all5', 'XGB_raw'),
        ('XGB_allV2_256 vs RF_raw', 'XGB_allV2_256', 'RF_raw'),
        ('V2_FT_256 vs V2_FT_128', 'V2_FT_256', 'V2_FT_128'),
        ('V2_FT_128 vs XGB_raw', 'V2_FT_128', 'XGB_raw'),
    ]
    
    delong_results = []
    for comp_name, m1, m2 in delong_comparisons:
        pred1 = np.concatenate(all_preds[m1])
        pred2 = np.concatenate(all_preds[m2])
        p, auc1, auc2 = delong_roc_test(y_all, pred1, pred2)
        delta = auc1 - auc2
        delong_results.append({
            'comparison': comp_name, 'method1': m1, 'method2': m2,
            'auc1': auc1, 'auc2': auc2, 'delta_auc': delta, 'p_value': p
        })
        sig = '***' if p < 0.001 else '**' if p < 0.01 else '*' if p < 0.05 else 'ns'
        print(f"  {comp_name}: ΔAUC={delta:+.4f}, p={p:.4f} {sig}")
    
    # BH correction
    from statsmodels.stats.multitest import multipletests
    pvals = [d['p_value'] for d in delong_results]
    reject, pvals_corr, _, _ = multipletests(pvals, method='fdr_bh')
    for i, d in enumerate(delong_results):
        d['p_BH'] = pvals_corr[i]
        d['sig_BH'] = '***' if pvals_corr[i] < 0.001 else '**' if pvals_corr[i] < 0.01 else '*' if pvals_corr[i] < 0.05 else 'ns'
    
    print(f"\n  BH-corrected:")
    for d in delong_results:
        print(f"    {d['comparison']}: ΔAUC={d['delta_auc']:+.4f}, p_BH={d['p_BH']:.4f} {d['sig_BH']}")
    
    return {
        'key': key,
        'n': len(labels),
        'nfolds': nfolds,
        'results': results,
        'delong': delong_results,
        'predictions': {m: [{'y_true': y_trues[i].tolist(), 'y_prob': all_preds[m][i].tolist()} for i in range(nfolds)] for m in all_preds}
    }

# ============ RUN ALL ============
if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--level', choices=['genus', 'species', 'both'], default='both')
    parser.add_argument('--task', choices=['t2d', 't1d', 'both'], default='both')
    args = parser.parse_args()
    
    levels = ['genus', 'species'] if args.level == 'both' else [args.level]
    tasks = ['t2d', 't1d'] if args.task == 'both' else [args.task]
    
    all_results = {}
    
    for level in levels:
        ilr = pd.read_csv(f"{DATA_DIR}/{level}_philr_transform.csv", index_col=0)
        meta = pd.read_csv(f"{DATA_DIR}/sample_metadata.csv", index_col=0)
        common = ilr.index.intersection(meta.index)
        ilr_v = ilr.loc[common].values
        meta_l = meta.loc[common]
        del ilr; import gc; gc.collect()
        
        for task in tasks:
            r = evaluate_level_task(level, task, ilr_v, meta_l)
            all_results[r['key']] = r
            
            # Save incrementally
            save_path = f"/mnt/results/unified_{r['key']}_results.json"
            # Don't save predictions in this file (too large)
            save_data = {k: v for k, v in r.items() if k != 'predictions'}
            with open(save_path, 'w') as f:
                json.dump(save_data, f, indent=2, default=str)
            print(f"Saved {save_path}")
    
    # Save predictions separately
    pred_path = "/mnt/results/unified_all_predictions.json"
    pred_data = {}
    for key, r in all_results.items():
        pred_data[key] = r['predictions']
    with open(pred_path, 'w') as f:
        json.dump(pred_data, f)
    print(f"\nSaved predictions to {pred_path}")
    
    # Print final summary table
    print("\n" + "="*80)
    print("UNIFIED EVALUATION SUMMARY")
    print("="*80)
    
    method_order = ['V2_LP_128', 'V2_LP_256', 'V2_FT_128', 'V2_FT_256', 'MLP_scratch',
                    'LASSO_ILR', 'RF_raw', 'XGB_raw', 'XGB_V2enh_256', 'XGB_allV2_256',
                    'Stack_XGB_V2enh_RF', 'Stack_all5']
    
    # Header
    keys = list(all_results.keys())
    print(f"{'Method':25s}", end='')
    for k in keys:
        print(f"  {k:14s}", end='')
    print()
    print("-" * (25 + 16 * len(keys)))
    
    for m in method_order:
        print(f"{m:25s}", end='')
        for k in keys:
            if m in all_results[k]['results']:
                v = all_results[k]['results'][m]
                print(f"  {v['auc_mean']:.4f}±{v['auc_std']:.3f}", end='')
            else:
                print(f"  {'N/A':14s}", end='')
        print()
    
    # DeLong summary
    print("\nKey DeLong comparisons (BH-corrected):")
    for k in keys:
        print(f"\n  {k}:")
        for d in all_results[k]['delong']:
            print(f"    {d['comparison']}: ΔAUC={d['delta_auc']:+.4f}, p_BH={d['p_BH']:.4f} {d['sig_BH']}")

