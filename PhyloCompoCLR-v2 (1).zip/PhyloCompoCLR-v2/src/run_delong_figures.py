#!/usr/bin/env python3
"""Generate DeLong test significance figures and tables."""

import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')
from itertools import combinations
import seaborn as sns

# Load DeLong results
with open('/mnt/results/delong_test_results.json') as f:
    delong = json.load(f)

with open('/mnt/results/delong_auc_summary.json') as f:
    aucs = json.load(f)

# ============================================================
# Figure 1: Significance heatmaps for each task/level
# ============================================================

def create_significance_heatmap(comparisons, methods, title, save_path):
    """Create a heatmap showing DeLong p-values and significance."""
    n = len(methods)
    # Create matrices
    pval_matrix = np.ones((n, n))
    delta_auc_matrix = np.zeros((n, n))
    sig_matrix = np.zeros((n, n), dtype=bool)
    
    method_idx = {m: i for i, m in enumerate(methods)}
    
    for comp in comparisons:
        i = method_idx[comp['method_A']]
        j = method_idx[comp['method_B']]
        pval_matrix[i, j] = comp['p_value_bh']
        pval_matrix[j, i] = comp['p_value_bh']
        delta_auc_matrix[i, j] = comp['delta_auc']
        delta_auc_matrix[j, i] = -comp['delta_auc']
        sig_matrix[i, j] = comp['significant_bh_005']
        sig_matrix[j, i] = comp['significant_bh_005']
    
    # Create annotation labels
    annot = np.empty((n, n), dtype=object)
    for i in range(n):
        for j in range(n):
            if i == j:
                annot[i, j] = ''
            elif sig_matrix[i, j]:
                stars = '***' if pval_matrix[i, j] < 0.001 else '**' if pval_matrix[i, j] < 0.01 else '*' if pval_matrix[i, j] < 0.05 else ''
                annot[i, j] = f'{delta_auc_matrix[i, j]:+.3f}\n{stars}'
            else:
                annot[i, j] = f'{delta_auc_matrix[i, j]:+.3f}'
    
    fig, ax = plt.subplots(figsize=(10, 8))
    
    # Use -log10(p) for color scale
    log_p = -np.log10(np.maximum(pval_matrix, 1e-10))
    np.fill_diagonal(log_p, 0)
    
    # Custom colormap
    cmap = sns.color_palette("YlOrRd", as_cmap=True)
    
    mask = np.eye(n, dtype=bool)
    
    hm = sns.heatmap(log_p, mask=mask, cmap=cmap, center=0, 
                     annot=annot, fmt='', linewidths=0.5,
                     xticklabels=methods, yticklabels=methods,
                     ax=ax, cbar_kws={'label': '-log10(p_BH)'})
    
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha='right', fontsize=9)
    ax.set_yticklabels(ax.get_yticklabels(), rotation=0, fontsize=9)
    
    # Add significance threshold line in colorbar
    cbar = hm.collections[0].colorbar
    cbar.ax.axhline(y=-np.log10(0.05), color='blue', linestyle='--', linewidth=1.5)
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.savefig(save_path.replace('.png', '.svg'), bbox_inches='tight')
    plt.close()
    print(f"Saved: {save_path}")


# Genus T2D
g_t2d_comps = delong['genus_t2d']
g_t2d_methods = sorted(set(c['method_A'] for c in g_t2d_comps) | set(c['method_B'] for c in g_t2d_comps))
# Order: V2 full first, then ablations, then V1, then RF
order = ['V2_ILR_LP', 'V2_pert_only', 'V2_no_aug', 'V2_phylo_only', 'V2_power_only', 'V2_mixup_only', 'V1_CLR_LP', 'RF_ILR', 'RF_CLR']
g_t2d_methods = [m for m in order if m in g_t2d_methods]
create_significance_heatmap(g_t2d_comps, g_t2d_methods, 
    'Genus T2D: DeLong Test Significance (BH-corrected)', 
    '/mnt/results/fig_delong_genus_t2d.png')

# Genus T1D
g_t1d_comps = delong['genus_t1d']
g_t1d_methods = sorted(set(c['method_A'] for c in g_t1d_comps) | set(c['method_B'] for c in g_t1d_comps))
order_t1d = ['V2_ILR_LP', 'V2_pert_only', 'V2_no_aug', 'V2_phylo_only', 'V2_power_only', 'V2_mixup_only', 'V1_CLR_LP', 'RF_ILR']
g_t1d_methods = [m for m in order_t1d if m in g_t1d_methods]
create_significance_heatmap(g_t1d_comps, g_t1d_methods,
    'Genus T1D: DeLong Test Significance (BH-corrected)',
    '/mnt/results/fig_delong_genus_t1d.png')

# Species T2D
s_t2d_comps = delong['species_t2d']
s_t2d_methods = sorted(set(c['method_A'] for c in s_t2d_comps) | set(c['method_B'] for c in s_t2d_comps))
create_significance_heatmap(s_t2d_comps, s_t2d_methods,
    'Species T2D: DeLong Test Significance (BH-corrected)',
    '/mnt/results/fig_delong_species_t2d.png')

# Species T1D
s_t1d_comps = delong['species_t1d']
s_t1d_methods = sorted(set(c['method_A'] for c in s_t1d_comps) | set(c['method_B'] for c in s_t1d_comps))
create_significance_heatmap(s_t1d_comps, s_t1d_methods,
    'Species T1D: DeLong Test Significance (BH-corrected)',
    '/mnt/results/fig_delong_species_t1d.png')


# ============================================================
# Figure 2: Updated ablation bar chart with significance brackets
# ============================================================

def create_ablation_bar_with_sig(auc_data, delong_comps, task, level, save_path):
    """Create ablation bar chart with DeLong significance brackets."""
    methods = list(auc_data.keys())
    means = [auc_data[m]['auc_mean'] for m in methods]
    stds = [auc_data[m]['auc_std'] for m in methods]
    
    # Short labels
    labels = [m.replace('V2_', '').replace('V1_', 'V1 CLR') for m in methods]
    labels = [l.replace('ILR_LP', 'Full (V2)') for l in labels]
    
    fig, ax = plt.subplots(figsize=(12, 6))
    
    x = np.arange(len(methods))
    bars = ax.bar(x, means, yerr=stds, capsize=4, color=sns.color_palette("Set2", len(methods)),
                  edgecolor='black', linewidth=0.5)
    
    # Add significance brackets comparing each method to V2 Full
    v2_idx = methods.index('V2_ILR_LP') if 'V2_ILR_LP' in methods else 0
    
    # Find comparisons with V2_ILR_LP
    sig_y = max(means) + max(stds) + 0.02
    bracket_count = 0
    
    for comp in delong_comps:
        if comp['method_A'] == 'V2_ILR_LP' or comp['method_B'] == 'V2_ILR_LP':
            other = comp['method_B'] if comp['method_A'] == 'V2_ILR_LP' else comp['method_A']
            if other in methods:
                other_idx = methods.index(other)
                p_bh = comp['p_value_bh']
                if p_bh < 0.05:
                    stars = '***' if p_bh < 0.001 else '**' if p_bh < 0.01 else '*'
                    y_pos = sig_y + bracket_count * 0.04
                    ax.plot([v2_idx, v2_idx, other_idx, other_idx], 
                           [y_pos - 0.005, y_pos, y_pos, y_pos - 0.005], 
                           'k-', linewidth=1)
                    ax.text((v2_idx + other_idx) / 2, y_pos + 0.005, stars, 
                           ha='center', va='bottom', fontsize=10, fontweight='bold')
                    bracket_count += 1
    
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=45, ha='right', fontsize=10)
    ax.set_ylabel('AUC', fontsize=12)
    ax.set_title(f'{level.capitalize()} {task.upper()}: Method Comparison with DeLong Significance', 
                fontsize=13, fontweight='bold')
    ax.set_ylim(0.5, max(means) + max(stds) + 0.15)
    ax.axhline(y=0.5, color='gray', linestyle='--', alpha=0.3)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    
    # Add AUC values on bars
    for i, (m, s) in enumerate(zip(means, stds)):
        ax.text(i, m - s - 0.015, f'{m:.3f}', ha='center', va='top', fontsize=8, fontweight='bold')
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.savefig(save_path.replace('.png', '.svg'), bbox_inches='tight')
    plt.close()
    print(f"Saved: {save_path}")


# Genus T2D
create_ablation_bar_with_sig(
    aucs['genus']['t2d'], delong['genus_t2d'], 'T2D', 'genus',
    '/mnt/results/fig_delong_genus_t2d_bars.png')

# Genus T1D
create_ablation_bar_with_sig(
    aucs['genus']['t1d'], delong['genus_t1d'], 'T1D', 'genus',
    '/mnt/results/fig_delong_genus_t1d_bars.png')

# Species T2D
create_ablation_bar_with_sig(
    aucs['species']['t2d'], delong['species_t2d'], 'T2D', 'species',
    '/mnt/results/fig_delong_species_t2d_bars.png')

# Species T1D
create_ablation_bar_with_sig(
    aucs['species']['t1d'], delong['species_t1d'], 'T1D', 'species',
    '/mnt/results/fig_delong_species_t1d_bars.png')


# ============================================================
# Figure 3: Comprehensive 4-panel DeLong summary
# ============================================================

fig, axes = plt.subplots(2, 2, figsize=(16, 14))

for idx, (level, task) in enumerate([('genus', 't2d'), ('genus', 't1d'), ('species', 't2d'), ('species', 't1d')]):
    ax = axes[idx // 2, idx % 2]
    key = f'{level}_{task}'
    if key not in delong:
        ax.text(0.5, 0.5, 'No data', ha='center', va='center', transform=ax.transAxes)
        continue
    
    comps = delong[key]
    methods = sorted(set(c['method_A'] for c in comps) | set(c['method_B'] for c in comps))
    n = len(methods)
    method_idx = {m: i for i, m in enumerate(methods)}
    
    # Build p-value matrix
    pval_matrix = np.ones((n, n))
    for comp in comps:
        i = method_idx[comp['method_A']]
        j = method_idx[comp['method_B']]
        pval_matrix[i, j] = comp['p_value_bh']
        pval_matrix[j, i] = comp['p_value_bh']
    
    log_p = -np.log10(np.maximum(pval_matrix, 1e-10))
    np.fill_diagonal(log_p, np.nan)
    
    # Short method names
    short_names = [m.replace('V2_', '').replace('V1_', 'V1 ').replace('ILR_LP', 'Full').replace('RF_', 'RF ') for m in methods]
    
    mask = np.eye(n, dtype=bool)
    sns.heatmap(log_p, mask=mask, cmap='YlOrRd', annot=True, fmt='.1f',
                xticklabels=short_names, yticklabels=short_names,
                ax=ax, cbar=True, vmin=0, vmax=4,
                linewidths=0.5, linecolor='white')
    
    # Mark significant cells
    for comp in comps:
        i = method_idx[comp['method_A']]
        j = method_idx[comp['method_B']]
        if comp['significant_bh_005']:
            ax.add_patch(plt.Rectangle((j, i), 1, 1, fill=False, edgecolor='blue', lw=2))
            ax.add_patch(plt.Rectangle((i, j), 1, 1, fill=False, edgecolor='blue', lw=2))
    
    ax.set_title(f'{level.capitalize()} {task.upper()}\n-log10(p_BH), blue border = FDR<0.05', 
                fontsize=11, fontweight='bold')
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha='right', fontsize=8)
    ax.set_yticklabels(ax.get_yticklabels(), rotation=0, fontsize=8)

plt.suptitle('DeLong Test: Pairwise AUC Comparisons (BH-corrected)', fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/mnt/results/fig_delong_comprehensive.png', dpi=150, bbox_inches='tight')
plt.savefig('/mnt/results/fig_delong_comprehensive.svg', bbox_inches='tight')
plt.close()
print("Saved: /mnt/results/fig_delong_comprehensive.png")


# ============================================================
# Generate formatted significance summary table
# ============================================================

print("\n" + "=" * 80)
print("FORMATTED SIGNIFICANCE SUMMARY TABLE")
print("=" * 80)

for key, comps in delong.items():
    level, task = key.split('_')
    n_total = len(comps)
    n_sig = sum(1 for c in comps if c['significant_bh_005'])
    n_sig_001 = sum(1 for c in comps if c['p_value_bh'] < 0.001)
    
    print(f"\n{level.upper()} {task.upper()}: {n_sig}/{n_total} significant (FDR<0.05), {n_sig_001} at p<0.001")
    
    # Key comparisons
    key_pairs = [
        ('V2_ILR_LP', 'V1_CLR_LP'),
        ('V2_ILR_LP', 'RF_ILR'),
        ('V2_ILR_LP', 'V2_no_aug'),
        ('V2_ILR_LP', 'V2_pert_only'),
        ('V2_ILR_LP', 'V2_power_only'),
        ('V2_ILR_LP', 'V2_mixup_only'),
        ('V2_ILR_LP', 'V2_phylo_only'),
    ]
    
    print(f"  {'Comparison':<35} {'ΔAUC':>8} {'p_raw':>10} {'p_BH':>10} {'Sig':>5}")
    print(f"  {'-'*35} {'-'*8} {'-'*10} {'-'*10} {'-'*5}")
    for mA, mB in key_pairs:
        match = [c for c in comps if (c['method_A'] == mA and c['method_B'] == mB) or 
                 (c['method_A'] == mB and c['method_B'] == mA)]
        if match:
            c = match[0]
            sig = '***' if c['p_value_bh'] < 0.001 else '**' if c['p_value_bh'] < 0.01 else '*' if c['p_value_bh'] < 0.05 else 'ns'
            pair_name = f"{mA} vs {mB}"
            print(f"  {pair_name:<35} {c['delta_auc']:+8.4f} {c['p_value_raw']:10.4f} {c['p_value_bh']:10.4f} {sig:>5}")

print("\nDone!")
