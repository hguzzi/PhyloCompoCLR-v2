#!/usr/bin/env python3
"""Comprehensive species-level evaluation for PhyloCompoCLR V2."""

import sys
sys.path.insert(0, "/mnt/shared-workspace")

import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import StratifiedKFold, StratifiedShuffleSplit
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, f1_score
import json, os, time

# Load species PhILR data
print("Loading species PhILR transform...")
species_philr = pd.read_csv("/mnt/shared-workspace/cmd3_data/species_philr_transform.csv", index_col=0)
species_ilr = species_philr.values.astype(np.float32)
sample_ids = species_philr.index.tolist()
del species_philr
import gc; gc.collect()
print(f"Species ILR: {species_ilr.shape}")

# Load species CLR data
print("Loading species CLR transform...")
species_clr = pd.read_csv("/mnt/shared-workspace/cmd3_data/species_clr_transform.csv", index_col=0)
species_clr_vals = species_clr.values.astype(np.float32)
del species_clr; gc.collect()
print(f"Species CLR: {species_clr_vals.shape}")

# Load metadata
metadata = pd.read_csv("/mnt/shared-workspace/cmd3_data/sample_metadata.csv", index_col=0, low_memory=False)
metadata_aligned = metadata.loc[sample_ids]

# Load encoder class
from phylocompoclr_v2_train import PhyloCompoCLREncoder

def extract_embeddings(model_path, input_data):
    """Extract embeddings from a saved model checkpoint."""
    checkpoint = torch.load(model_path, map_location="cpu", weights_only=False)
    config = checkpoint["config"]
    encoder = PhyloCompoCLREncoder(config["input_dim"], config["hidden_dims"], config["embed_dim"])
    encoder.load_state_dict(checkpoint["encoder_state_dict"])
    encoder.eval()

    X = torch.tensor(input_data, dtype=torch.float32)
    embeddings = []
    with torch.no_grad():
        for i in range(0, len(X), 256):
            batch = X[i:i+256]
            emb = encoder(batch)
            embeddings.append(emb.numpy())
    return np.vstack(embeddings)

def linear_probe_cv(X, y, n_splits=5, random_state=42):
    """Run linear probe with stratified k-fold CV."""
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    aucs = []
    for train_idx, test_idx in skf.split(X, y):
        clf = LogisticRegression(max_iter=1000, C=1.0, random_state=42)
        clf.fit(X[train_idx], y[train_idx])
        y_prob = clf.predict_proba(X[test_idx])[:, 1]
        auc = roc_auc_score(y[test_idx], y_prob)
        aucs.append(auc)
    return aucs

def rf_cv(X, y, n_splits=5, random_state=42):
    """Run RF with stratified k-fold CV."""
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    aucs = []
    for train_idx, test_idx in skf.split(X, y):
        clf = RandomForestClassifier(n_estimators=500, random_state=42, n_jobs=-1)
        clf.fit(X[train_idx], y[train_idx])
        y_prob = clf.predict_proba(X[test_idx])[:, 1]
        auc = roc_auc_score(y[test_idx], y_prob)
        aucs.append(auc)
    return aucs

def data_limited_curve(X, y, sample_sizes=[10, 20, 50, 100, 200, 500], n_repeats=5):
    """Run data-limited learning curve."""
    results = {}
    for n in sample_sizes:
        aucs = []
        for repeat in range(n_repeats):
            sss = StratifiedShuffleSplit(n_splits=1, train_size=n, random_state=42+repeat)
            for train_idx, test_idx in sss.split(X, y):
                clf = LogisticRegression(max_iter=1000, C=1.0)
                clf.fit(X[train_idx], y[train_idx])
                y_prob = clf.predict_proba(X[test_idx])[:, 1]
                auc = roc_auc_score(y[test_idx], y_prob)
                aucs.append(auc)
        results[n] = {"auc_mean": float(np.mean(aucs)), "auc_std": float(np.std(aucs))}
        print(f"    n={n:4d}: AUC={np.mean(aucs):.3f} +/- {np.std(aucs):.3f}")
    return results

results = {}

# ============================================================
# 1. Extract embeddings from all models
# ============================================================
print("\n=== Extracting Embeddings ===")

# V2 ILR (species PhILR)
v2_emb = extract_embeddings("/mnt/shared-workspace/models/species_v2_full_best.pt", species_ilr)
print(f"V2 ILR embeddings: {v2_emb.shape}")

# V1 CLR (species CLR) - check if model exists
v1_clr_path = "/mnt/shared-workspace/models/species_v1_clr_best.pt"
if os.path.exists(v1_clr_path):
    v1_emb = extract_embeddings(v1_clr_path, species_clr_vals)
    print(f"V1 CLR embeddings: {v1_emb.shape}")
    has_v1 = True
else:
    print("V1 CLR model not found - skipping V1 comparison")
    has_v1 = False

# ============================================================
# 2. T2D Classification
# ============================================================
print("\n=== T2D Classification (5-fold CV) ===")
t2d_mask = metadata_aligned["t2d_binary"].notna()
t2d_labels = metadata_aligned.loc[t2d_mask, "t2d_binary"].values.astype(int)
print(f"Samples: {len(t2d_labels)} (T2D={t2d_labels.sum()}, ctrl={len(t2d_labels)-t2d_labels.sum()})")

# V2 ILR LP
t2d_v2_aucs = linear_probe_cv(v2_emb[t2d_mask.values], t2d_labels)
print(f"  V2 ILR LP: AUC={np.mean(t2d_v2_aucs):.3f} +/- {np.std(t2d_v2_aucs):.3f}")
results["t2d"] = {"v2_ilr_lp": {"auc_mean": float(np.mean(t2d_v2_aucs)), "auc_std": float(np.std(t2d_v2_aucs))}}

# V1 CLR LP
if has_v1:
    t2d_v1_aucs = linear_probe_cv(v1_emb[t2d_mask.values], t2d_labels)
    print(f"  V1 CLR LP: AUC={np.mean(t2d_v1_aucs):.3f} +/- {np.std(t2d_v1_aucs):.3f}")
    results["t2d"]["v1_clr_lp"] = {"auc_mean": float(np.mean(t2d_v1_aucs)), "auc_std": float(np.std(t2d_v1_aucs))}

# RF on ILR
t2d_rf_ilr_aucs = rf_cv(species_ilr[t2d_mask.values], t2d_labels)
print(f"  RF (ILR): AUC={np.mean(t2d_rf_ilr_aucs):.3f} +/- {np.std(t2d_rf_ilr_aucs):.3f}")
results["t2d"]["rf_ilr"] = {"auc_mean": float(np.mean(t2d_rf_ilr_aucs)), "auc_std": float(np.std(t2d_rf_ilr_aucs))}

# RF on CLR
t2d_rf_clr_aucs = rf_cv(species_clr_vals[t2d_mask.values], t2d_labels)
print(f"  RF (CLR): AUC={np.mean(t2d_rf_clr_aucs):.3f} +/- {np.std(t2d_rf_clr_aucs):.3f}")
results["t2d"]["rf_clr"] = {"auc_mean": float(np.mean(t2d_rf_clr_aucs)), "auc_std": float(np.std(t2d_rf_clr_aucs))}

# ============================================================
# 3. T1D Classification
# ============================================================
print("\n=== T1D Classification (3-fold CV) ===")
t1d_mask = metadata_aligned["t1d_binary"].notna()
t1d_labels = metadata_aligned.loc[t1d_mask, "t1d_binary"].values.astype(int)
print(f"Samples: {len(t1d_labels)} (T1D={t1d_labels.sum()}, ctrl={len(t1d_labels)-t1d_labels.sum()})")

t1d_v2_aucs = linear_probe_cv(v2_emb[t1d_mask.values], t1d_labels, n_splits=3)
print(f"  V2 ILR LP: AUC={np.mean(t1d_v2_aucs):.3f} +/- {np.std(t1d_v2_aucs):.3f}")
results["t1d"] = {"v2_ilr_lp": {"auc_mean": float(np.mean(t1d_v2_aucs)), "auc_std": float(np.std(t1d_v2_aucs))}}

if has_v1:
    t1d_v1_aucs = linear_probe_cv(v1_emb[t1d_mask.values], t1d_labels, n_splits=3)
    print(f"  V1 CLR LP: AUC={np.mean(t1d_v1_aucs):.3f} +/- {np.std(t1d_v1_aucs):.3f}")
    results["t1d"]["v1_clr_lp"] = {"auc_mean": float(np.mean(t1d_v1_aucs)), "auc_std": float(np.std(t1d_v1_aucs))}

t1d_rf_ilr_aucs = rf_cv(species_ilr[t1d_mask.values], t1d_labels, n_splits=3)
print(f"  RF (ILR): AUC={np.mean(t1d_rf_ilr_aucs):.3f} +/- {np.std(t1d_rf_ilr_aucs):.3f}")
results["t1d"]["rf_ilr"] = {"auc_mean": float(np.mean(t1d_rf_ilr_aucs)), "auc_std": float(np.std(t1d_rf_ilr_aucs))}

# ============================================================
# 4. Glucose Subgroup
# ============================================================
print("\n=== Glucose Subgroup ===")
glucose_mask = metadata_aligned["glucose_status"].isin(["healthy", "prediabetic", "T2D"])
glucose_emb = v2_emb[glucose_mask.values]
glucose_labels = metadata_aligned.loc[glucose_mask, "glucose_status"].map(
    {"healthy": 0, "prediabetic": 1, "T2D": 2}).values.astype(int)

skf_g = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
glucose_aucs = []
for train_idx, test_idx in skf_g.split(glucose_emb, glucose_labels):
    clf = LogisticRegression(max_iter=1000, C=1.0, random_state=42)
    clf.fit(glucose_emb[train_idx], glucose_labels[train_idx])
    y_prob = clf.predict_proba(glucose_emb[test_idx])
    auc = roc_auc_score(glucose_labels[test_idx], y_prob, multi_class="ovr")
    glucose_aucs.append(auc)
print(f"  3-class OvR: AUC={np.mean(glucose_aucs):.3f} +/- {np.std(glucose_aucs):.3f}")
results["glucose_subgroup"] = {"3class_ovr": {"auc_mean": float(np.mean(glucose_aucs)), "auc_std": float(np.std(glucose_aucs))}}

# IGT vs T2D
igt_t2d_mask = metadata_aligned["glucose_status"].isin(["prediabetic", "T2D"])
igt_t2d_emb = v2_emb[igt_t2d_mask.values]
igt_t2d_labels = metadata_aligned.loc[igt_t2d_mask, "glucose_status"].map(
    {"prediabetic": 0, "T2D": 1}).values.astype(int)
igt_aucs = linear_probe_cv(igt_t2d_emb, igt_t2d_labels)
print(f"  IGT vs T2D: AUC={np.mean(igt_aucs):.3f} +/- {np.std(igt_aucs):.3f}")
results["glucose_subgroup"]["igt_vs_t2d"] = {"auc_mean": float(np.mean(igt_aucs)), "auc_std": float(np.std(igt_aucs))}

# ============================================================
# 5. Cross-type Transfer
# ============================================================
print("\n=== Cross-type Transfer ===")
# T2D -> T1D
t2d_train_mask = metadata_aligned["t2d_binary"] == 1
t2d_ctrl_mask = metadata_aligned["t2d_binary"] == 0
t1d_test_mask = metadata_aligned["t1d_binary"].notna()

t2d_train_emb = v2_emb[t2d_train_mask.values | t2d_ctrl_mask.values]
t2d_train_labels = metadata_aligned.loc[t2d_train_mask.values | t2d_ctrl_mask.values, "t2d_binary"].values.astype(int)
t1d_test_emb = v2_emb[t1d_test_mask.values]
t1d_test_labels = metadata_aligned.loc[t1d_test_mask, "t1d_binary"].values.astype(int)

clf_transfer = LogisticRegression(max_iter=1000, C=1.0, random_state=42)
clf_transfer.fit(t2d_train_emb, t2d_train_labels)
t2d_to_t1d_auc = roc_auc_score(t1d_test_labels, clf_transfer.predict_proba(t1d_test_emb)[:, 1])
print(f"  T2D -> T1D: AUC={t2d_to_t1d_auc:.3f}")

# T1D -> T2D
t1d_train_mask = metadata_aligned["t1d_binary"] == 1
t1d_ctrl_mask = metadata_aligned["t1d_binary"] == 0
t2d_test_mask = metadata_aligned["t2d_binary"].notna()

t1d_train_emb = v2_emb[t1d_train_mask.values | t1d_ctrl_mask.values]
t1d_train_labels = metadata_aligned.loc[t1d_train_mask.values | t1d_ctrl_mask.values, "t1d_binary"].values.astype(int)
t2d_test_emb = v2_emb[t2d_test_mask.values]
t2d_test_labels = metadata_aligned.loc[t2d_test_mask, "t2d_binary"].values.astype(int)

clf_transfer2 = LogisticRegression(max_iter=1000, C=1.0, random_state=42)
clf_transfer2.fit(t1d_train_emb, t1d_train_labels)
t1d_to_t2d_auc = roc_auc_score(t2d_test_labels, clf_transfer2.predict_proba(t2d_test_emb)[:, 1])
print(f"  T1D -> T2D: AUC={t1d_to_t2d_auc:.3f}")

results["cross_type"] = {
    "t2d_to_t1d": {"auc": float(t2d_to_t1d_auc)},
    "t1d_to_t2d": {"auc": float(t1d_to_t2d_auc)},
}

# ============================================================
# 6. Multi-type Classification
# ============================================================
print("\n=== Multi-type Classification (4-class) ===")
multi_mask = metadata_aligned["diabetes_type"].isin(["control", "T2D", "T1D", "GDM"])
multi_emb = v2_emb[multi_mask.values]
multi_labels = metadata_aligned.loc[multi_mask, "diabetes_type"].map(
    {"control": 0, "T2D": 1, "T1D": 2, "GDM": 3}).values.astype(int)
print(f"Samples: {len(multi_labels)} (ctrl={sum(multi_labels==0)}, T2D={sum(multi_labels==1)}, T1D={sum(multi_labels==2)}, GDM={sum(multi_labels==3)})")

skf_multi = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
multi_aucs = []
for train_idx, test_idx in skf_multi.split(multi_emb, multi_labels):
    clf = LogisticRegression(max_iter=1000, C=1.0, random_state=42)
    clf.fit(multi_emb[train_idx], multi_labels[train_idx])
    y_prob = clf.predict_proba(multi_emb[test_idx])
    auc = roc_auc_score(multi_labels[test_idx], y_prob, multi_class="ovr")
    multi_aucs.append(auc)
print(f"  4-class OvR: AUC={np.mean(multi_aucs):.3f} +/- {np.std(multi_aucs):.3f}")
results["multi_type"] = {"4class_ovr": {"auc_mean": float(np.mean(multi_aucs)), "auc_std": float(np.std(multi_aucs))}}

# ============================================================
# 7. Data-Limited Learning Curves
# ============================================================
print("\n=== Data-Limited Learning Curves ===")
t2d_emb_all = v2_emb[t2d_mask.values]

print("  V2 ILR LP:")
results["data_limited"] = {"v2_ilr_lp": data_limited_curve(t2d_emb_all, t2d_labels)}

if has_v1:
    print("  V1 CLR LP:")
    t2d_v1_emb_all = v1_emb[t2d_mask.values]
    results["data_limited"]["v1_clr_lp"] = data_limited_curve(t2d_v1_emb_all, t2d_labels)

print("  RF (ILR):")
t2d_ilr_all = species_ilr[t2d_mask.values]
rf_dl = {}
for n in [10, 50, 100, 500]:
    aucs = []
    for repeat in range(5):
        sss = StratifiedShuffleSplit(n_splits=1, train_size=n, random_state=42+repeat)
        for train_idx, test_idx in sss.split(t2d_ilr_all, t2d_labels):
            clf = RandomForestClassifier(n_estimators=500, random_state=42, n_jobs=-1)
            clf.fit(t2d_ilr_all[train_idx], t2d_labels[train_idx])
            y_prob = clf.predict_proba(t2d_ilr_all[test_idx])[:, 1]
            auc = roc_auc_score(t2d_labels[test_idx], y_prob)
            aucs.append(auc)
    rf_dl[n] = {"auc_mean": float(np.mean(aucs)), "auc_std": float(np.std(aucs))}
    print(f"    n={n:4d}: AUC={np.mean(aucs):.3f} +/- {np.std(aucs):.3f}")
results["data_limited"]["rf_ilr"] = rf_dl

# Save
with open("/mnt/results/evaluation_species_v2.json", "w") as f:
    json.dump(results, f, indent=2)
print(f"\nSpecies evaluation saved to /mnt/results/evaluation_species_v2.json")
