#!/usr/bin/env python3
"""Species-level V1 CLR baseline pretraining."""

import sys
sys.path.insert(0, "/mnt/shared-workspace")

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import json, os, time

# Load species CLR data
print("Loading species CLR transform...")
species_clr = pd.read_csv("/mnt/shared-workspace/cmd3_data/species_clr_transform.csv", index_col=0)
species_clr_vals = species_clr.values.astype(np.float32)
sample_ids = species_clr.index.tolist()
del species_clr
import gc; gc.collect()
print(f"Species CLR: {species_clr_vals.shape}")

# V1 CLR augmentation: Gaussian noise + feature dropout
class CLRDataset(Dataset):
    def __init__(self, X, alpha_noise=0.3, dropout_rate=0.25, cutmix_alpha=0.4):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.alpha_noise = alpha_noise
        self.dropout_rate = dropout_rate
        self.cutmix_alpha = cutmix_alpha

    def __len__(self):
        return len(self.X)

    def augment_v1(self, x):
        """V1 CLR augmentation: Gaussian noise + feature dropout (view1), noise + CutMix (view2)"""
        # View 1: Gaussian noise + feature dropout
        noise1 = torch.randn_like(x) * self.alpha_noise
        mask1 = (torch.rand_like(x) > self.dropout_rate).float()
        v1 = (x + noise1) * mask1

        # View 2: Gaussian noise + CutMix
        noise2 = torch.randn_like(x) * self.alpha_noise
        # CutMix: mix with another sample
        lam = np.random.beta(self.cutmix_alpha, self.cutmix_alpha) if self.cutmix_alpha > 0 else 1.0
        idx = np.random.randint(0, len(self.X))
        x2 = self.X[idx]
        v2 = lam * x + (1 - lam) * x2 + noise2

        return v1, v2

    def __getitem__(self, idx):
        x = self.X[idx]
        v1, v2 = self.augment_v1(x)
        return v1, v2

# Encoder (same architecture as V2 species)
class Encoder(nn.Module):
    def __init__(self, input_dim=1661, hidden_dims=[1024, 512, 256], embed_dim=128):
        super().__init__()
        layers = []
        prev_dim = input_dim
        for h in hidden_dims:
            layers.extend([nn.Linear(prev_dim, h), nn.BatchNorm1d(h), nn.ReLU()])
            prev_dim = h
        layers.append(nn.Linear(prev_dim, embed_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)

class Projector(nn.Module):
    def __init__(self, embed_dim=128, proj_dims=[64, 32]):
        super().__init__()
        layers = []
        prev = embed_dim
        for p in proj_dims:
            layers.extend([nn.Linear(prev, p), nn.BatchNorm1d(p), nn.ReLU()])
            prev = p
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)

# VICReg loss
def vicreg_loss(z1, z2, sim_weight=25.0, var_weight=25.0, cov_weight=1.0, eps=1e-4, gamma=1.0):
    repr_loss = ((z1 - z2) ** 2).mean()
    z1_centered = z1 - z1.mean(dim=0)
    z2_centered = z2 - z2.mean(dim=0)
    std_z1 = torch.sqrt(z1_centered.var(dim=0) + eps)
    std_z2 = torch.sqrt(z2_centered.var(dim=0) + eps)
    var_loss = torch.mean(torch.relu(gamma - std_z1)) + torch.mean(torch.relu(gamma - std_z2))
    cov_z1 = (z1_centered.T @ z1_centered) / (z1.shape[0] - 1)
    cov_z2 = (z2_centered.T @ z2_centered) / (z2.shape[0] - 1)
    off_diag = lambda c: c.flatten()[:-1].view(c.shape[0] - 1, c.shape[0] + 1)[:, 1:].flatten() ** 2
    cov_loss = off_diag(cov_z1).sum() / cov_z1.shape[0] + off_diag(cov_z2).sum() / cov_z2.shape[0]
    return sim_weight * repr_loss + var_weight * var_loss + cov_weight * cov_loss

# Training
dataset = CLRDataset(species_clr_vals)
loader = DataLoader(dataset, batch_size=256, shuffle=True, num_workers=0, drop_last=True)

encoder = Encoder(input_dim=1661, hidden_dims=[1024, 512, 256], embed_dim=128)
projector = Projector(embed_dim=128, proj_dims=[64, 32])

optimizer = torch.optim.Adam(
    list(encoder.parameters()) + list(projector.parameters()),
    lr=1e-3, weight_decay=1e-5
)
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=200)

history = {"train_loss": [], "epoch": []}
best_loss = float("inf")
save_dir = "/mnt/shared-workspace/models"

for epoch in range(1, 201):
    encoder.train()
    projector.train()
    epoch_loss = 0.0
    n_batches = 0
    t0 = time.time()

    for v1, v2 in loader:
        z1 = projector(encoder(v1))
        z2 = projector(encoder(v2))
        loss = vicreg_loss(z1, z2)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        epoch_loss += loss.item()
        n_batches += 1

    scheduler.step()
    avg_loss = epoch_loss / n_batches
    history["train_loss"].append(avg_loss)
    history["epoch"].append(epoch)

    if avg_loss < best_loss:
        best_loss = avg_loss
        torch.save({
            "encoder_state_dict": encoder.state_dict(),
            "projector_state_dict": projector.state_dict(),
            "optimizer_state_dict": optimizer.state_dict(),
            "epoch": epoch,
            "loss": avg_loss,
            "config": {"input_dim": 1661, "hidden_dims": [1024, 512, 256], "embed_dim": 128},
        }, os.path.join(save_dir, "species_v1_clr_best.pt"))

    if epoch % 50 == 0 or epoch == 200:
        torch.save({
            "encoder_state_dict": encoder.state_dict(),
            "projector_state_dict": projector.state_dict(),
            "optimizer_state_dict": optimizer.state_dict(),
            "epoch": epoch,
            "loss": avg_loss,
            "config": {"input_dim": 1661, "hidden_dims": [1024, 512, 256], "embed_dim": 128},
        }, os.path.join(save_dir, f"species_v1_clr_epoch{epoch}.pt"))

    dt = time.time() - t0
    if epoch % 10 == 0:
        print(f"Epoch {epoch}: loss={avg_loss:.4f}, best={best_loss:.4f}, time={dt:.1f}s")

# Save final
torch.save({
    "encoder_state_dict": encoder.state_dict(),
    "projector_state_dict": projector.state_dict(),
    "epoch": 200,
    "loss": avg_loss,
    "config": {"input_dim": 1661, "hidden_dims": [1024, 512, 256], "embed_dim": 128},
}, os.path.join(save_dir, "species_v1_clr_final.pt"))

with open(os.path.join(save_dir, "species_v1_clr_history.json"), "w") as f:
    json.dump(history, f)

print(f"\nSpecies V1 CLR training complete. Best loss: {best_loss:.4f}")
