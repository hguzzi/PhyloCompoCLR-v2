#!/usr/bin/env python3
"""Compute global DeLong tests across ALL 12 task/level combos with BH correction."""

import json, os, numpy as np
from scipy import stats

# ── DeLong test implementation ──────────────────────────────────────────
def _fast_auc(pos, neg):
    """Fast AUC from positive and negative scores."""
    n_pos = len(pos)
    n_neg = len(neg)
    auc = 0.0
    for p in pos:
        auc += np.sum(neg < p) + 0.5 * np.sum(neg == p)
    return auc / (n_pos * n_neg)

def delong_roc_test(y_true, y_pred1, y_pred2):
    """DeLong test for two correlated ROC curves. Returns z-stat and p-value."""
    y_true = np.asarray(y_true, dtype=int)
    y_pred1 = np.asarray(y_pred1, dtype=float)
    y_pred2 = np.asarray(y_pred2, dtype=float)
    
    m = y_true.sum()
    n = len(y_true) - m
    if m == 0 or n == 0:
        return 0.0, 1.0
    
    X1 = y_pred1[y_true == 1]
    Y1 = y_pred1[y_true == 0]
    X2 = y_pred2[y_true == 1]
    Y2 = y_pred2[y_true == 0]
    
    auc1 = _fast_auc(X1, Y1)
    auc2 = _fast_auc(X2, Y2)
    
    # DeLong placements
    V10_1 = np.array([np.mean(Y1 < xi) + 0.5 * np.mean(Y1 == xi) for xi in X1])
    V01_1 = np.array([np.mean(X1 > yi) + 0.5 * np.mean(X1 == yi) for yi in Y1])
    V10_2 = np.array([np.mean(Y2 < xi) + 0.5 * np.mean(Y2 == xi) for xi in X2])
    V01_2 = np.array([np.mean(X2 > yi) + 0.5 * np.mean(X2 == yi) for yi in Y2])
    
    # Covariance matrices
    c10 = np.cov(V10_1, V10_2)
    c01 = np.cov(V01_1, V01_2)
    
    S = c10 / m + c01 / n
    
    delta = auc1 - auc2
    try:
        var = S[0,0] + S[1,1] - 2 * S[0,1]
        if var <= 0:
            return 0.0, 1.0
        z = delta / np.sqrt(var)
        p = 2 * stats.norm.sf(abs(z))
    except:
        return 0.0, 1.0
    
    return z, p

# ── Configuration ───────────────────────────────────────────────────────
TASKS = ['t2d', 't1d', 'ibd', 'cd', 'uc', 'crc']
LEVELS = ['genus', 'species']
COMPARISONS = [
    ('XGB_allV2_256', 'XGB_raw'),
    ('Stack_XGB_V2enh_RF', 'XGB_raw'),
    ('Stack_all5', 'XGB_raw'),
    ('XGB_allV2_256', 'RF_raw'),
    ('V2_FT_256', 'V2_FT_128'),
    ('V2_FT_128', 'XGB_raw'),
]

PRED_DIR = '/mnt/shared-workspace'

all_results = []

for level in LEVELS:
    for task in TASKS:
        pred_file = os.path.join(PRED_DIR, f'predictions_{level}_{task}.json')
        if not os.path.exists(pred_file):
            print(f"  SKIP {level}_{task}: no predictions file")
            continue
        
        with open(pred_file) as f:
            preds = json.load(f)
        
        task_label = f'{level}_{task}'
        
        # Get true labels from first method's first fold
        first_method = list(preds.keys())[0]
        y_true_all = np.array(preds[first_method][0]['y_true'])
        print(f"\n=== {task_label} (n={len(y_true_all)}, pos={y_true_all.sum()}) ===")
        
        for m1_name, m2_name in COMPARISONS:
            if m1_name not in preds or m2_name not in preds:
                print(f"  SKIP {m1_name} vs {m2_name}: method not found")
                continue
            
            # Concatenate predictions across folds (key is 'y_prob')
            m1_preds = np.concatenate([np.array(fold['y_prob']) for fold in preds[m1_name]])
            m2_preds = np.concatenate([np.array(fold['y_prob']) for fold in preds[m2_name]])
            y_true = np.concatenate([np.array(fold['y_true']) for fold in preds[m1_name]])
            
            auc1 = _fast_auc(m1_preds[y_true==1], m1_preds[y_true==0])
            auc2 = _fast_auc(m2_preds[y_true==1], m2_preds[y_true==0])
            
            z, p_raw = delong_roc_test(y_true, m1_preds, m2_preds)
            
            all_results.append({
                'task': task_label,
                'comparison': f'{m1_name} vs {m2_name}',
                'method1': m1_name,
                'method2': m2_name,
                'auc1': float(auc1),
                'auc2': float(auc2),
                'delta_auc': float(auc1 - auc2),
                'z_stat': float(z),
                'p_value': float(p_raw),
            })
            
            print(f"  {m1_name} vs {m2_name}: dAUC={auc1-auc2:+.4f} p={p_raw:.4f}")

# ── Global BH correction ───────────────────────────────────────────────
n_tests = len(all_results)
p_raw_all = [r['p_value'] for r in all_results]

p_arr = np.array(p_raw_all)
sorted_idx = np.argsort(p_arr)
p_sorted = p_arr[sorted_idx]
n = len(p_sorted)

# BH step-up
p_adj = np.zeros(n)
for i in range(n):
    p_adj[sorted_idx[i]] = min(p_sorted[i] * n / (i + 1), 1.0)

# Enforce monotonicity
rev_idx = np.argsort(p_arr)[::-1]
cummin = 1.0
for i in rev_idx:
    cummin = min(cummin, p_adj[i])
    p_adj[i] = cummin

for i, r in enumerate(all_results):
    r['p_BH_global'] = float(p_adj[i])
    if r['p_BH_global'] < 0.001:
        r['sig_BH_global'] = '***'
    elif r['p_BH_global'] < 0.01:
        r['sig_BH_global'] = '**'
    elif r['p_BH_global'] < 0.05:
        r['sig_BH_global'] = '*'
    else:
        r['sig_BH_global'] = 'ns'

# Save
out_path = '/mnt/results/global_delong_all_tasks.json'
with open(out_path, 'w') as f:
    json.dump(all_results, f, indent=2)

# Print summary
print(f"\n{'='*90}")
print(f"GLOBAL DELONG TESTS — {n_tests} comparisons, BH-corrected across all tasks")
print(f"{'='*90}")
sig_count = sum(1 for r in all_results if r['sig_BH_global'] != 'ns')
print(f"Significant after global BH: {sig_count}/{n_tests}")
print()
print(f"{'Task':20s} {'Comparison':45s} {'dAUC':>8s} {'p_raw':>8s} {'p_BH':>8s} {'Sig':>4s}")
print('-'*90)
for r in all_results:
    print(f"{r['task']:20s} {r['comparison']:45s} {r['delta_auc']:+8.4f} {r['p_value']:8.4f} {r['p_BH_global']:8.4f} {r['sig_BH_global']:>4s}")

# Per-task summary
print(f"\nPer-task significance summary:")
for level in LEVELS:
    for task in TASKS:
        tl = f'{level}_{task}'
        task_res = [r for r in all_results if r['task'] == tl]
        if not task_res:
            continue
        n_sig = sum(1 for r in task_res if r['sig_BH_global'] != 'ns')
        print(f"  {tl}: {n_sig}/{len(task_res)} significant")

print(f"\nSaved to {out_path}")
