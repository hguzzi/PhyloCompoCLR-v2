#!/usr/bin/env python3
"""Species-level UMAP visualization for PhyloCompoCLR V2."""

import sys
sys.path.insert(0, "/mnt/shared-workspace")

import numpy as np
import pandas as pd
import torch
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
import json

# Load species PhILR data
species_philr = pd.read_csv("/mnt/shared-workspace/cmd3_data/species_philr_transform.csv", index_col=0)
species_ilr = species_philr.values.astype(np.float32)
sample_ids = species_philr.index.tolist()
del species_philr
import gc; gc.collect()

metadata = pd.read_csv("/mnt/shared-workspace/cmd3_data/sample_metadata.csv", index_col=0, low_memory=False)
metadata_aligned = metadata.loc[sample_ids]

# Load V2 model
from phylocompoclr_v2_train import PhyloCompoCLREncoder
checkpoint = torch.load("/mnt/shared-workspace/models/species_v2_full_best.pt", map_location="cpu", weights_only=False)
config = checkpoint["config"]
encoder = PhyloCompoCLREncoder(config["input_dim"], config["hidden_dims"], config["embed_dim"])
encoder.load_state_dict(checkpoint["encoder_state_dict"])
encoder.eval()

# Extract embeddings
X = torch.tensor(species_ilr, dtype=torch.float32)
embeddings = []
with torch.no_grad():
    for i in range(0, len(X), 256):
        batch = X[i:i+256]
        emb = encoder(batch)
        embeddings.append(emb.numpy())
embeddings = np.vstack(embeddings)
print(f"Embeddings shape: {embeddings.shape}")

# UMAP
import umap
reducer = umap.UMAP(n_neighbors=30, min_dist=0.3, random_state=42, n_components=2)
embedding_2d = reducer.fit_transform(embeddings)
print(f"UMAP shape: {embedding_2d.shape}")

# Create 4-panel figure
fig, axes = plt.subplots(2, 2, figsize=(14, 12))

# Panel 1: Diabetes type
ax = axes[0, 0]
diabetes_type = metadata_aligned["diabetes_type"].values
mask = diabetes_type != "other"
scatter = ax.scatter(embedding_2d[mask, 0], embedding_2d[mask, 1], 
                     c=pd.Categorical(diabetes_type[mask]).codes, 
                     cmap="Set1", s=3, alpha=0.5)
ax.set_title("Diabetes Type", fontsize=14)
legend_labels = sorted(set(diabetes_type[mask]))
handles = [plt.Line2D([0], [0], marker='o', color='w', markerfacecolor=plt.cm.Set1(i/len(legend_labels)), 
                       markersize=8, label=l) for i, l in enumerate(legend_labels)]
ax.legend(handles=handles, fontsize=8)

# Panel 2: Glucose gradient
ax = axes[0, 1]
glucose_status = metadata_aligned["glucose_status"].values
glucose_map = {"healthy": 0, "prediabetic": 1, "T2D": 2}
glucose_numeric = np.array([glucose_map.get(g, -1) for g in glucose_status])
mask = glucose_numeric >= 0
scatter = ax.scatter(embedding_2d[mask, 0], embedding_2d[mask, 1],
                     c=glucose_numeric[mask], cmap="RdYlGn_r", s=3, alpha=0.5)
ax.set_title("Glucose Gradient", fontsize=14)
plt.colorbar(scatter, ax=ax, label="0=Healthy, 1=Pre-D, 2=T2D")

# Panel 3: T2D case-control
ax = axes[1, 0]
t2d_mask = metadata_aligned["t2d_binary"].notna()
t2d_labels = metadata_aligned.loc[t2d_mask, "t2d_binary"].values
scatter = ax.scatter(embedding_2d[t2d_mask, 0], embedding_2d[t2d_mask, 1],
                     c=t2d_labels, cmap="coolwarm", s=5, alpha=0.6)
ax.set_title("T2D Case-Control", fontsize=14)

# Panel 4: T1D case-control
ax = axes[1, 1]
t1d_mask = metadata_aligned["t1d_binary"].notna()
t1d_labels = metadata_aligned.loc[t1d_mask, "t1d_binary"].values
scatter = ax.scatter(embedding_2d[t1d_mask, 0], embedding_2d[t1d_mask, 1],
                     c=t1d_labels, cmap="coolwarm", s=5, alpha=0.6)
ax.set_title("T1D Case-Control", fontsize=14)

for ax in axes.flat:
    ax.set_xlabel("UMAP 1")
    ax.set_ylabel("UMAP 2")

plt.tight_layout()
plt.savefig("/mnt/results/fig_umap_species_v2.png", dpi=150, bbox_inches="tight")
plt.savefig("/mnt/results/fig_umap_species_v2.svg", bbox_inches="tight")
print("Species UMAP saved")
