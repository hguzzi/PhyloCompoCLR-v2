#!/usr/bin/env python3
"""
External T1D Data Evaluation.

Evaluates PhyloCompoCLR V2 and V1 CLR on:
1. External T1D data alone (141 samples: 64 T1D + 77 controls)
2. Combined cMD3 + external T1D data
"""

import sys
sys.path.insert(0, "/mnt/shared-workspace")

import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score
import json
import os
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# 1. Load and prepare data
# ============================================================
print("=" * 70)
print("External T1D Data Evaluation")
print("=" * 70)

# Load cMD3 data
print("\nLoading cMD3 data...")
cmd3_species = pd.read_csv("/mnt/shared-workspace/cmd3_data/species_abundance.csv", index_col=0)
cmd3_philr = pd.read_csv("/mnt/shared-workspace/cmd3_data/species_philr_transform.csv", index_col=0)
cmd3_clr = pd.read_csv("/mnt/shared-workspace/cmd3_data/species_clr_transform.csv", index_col=0)
metadata = pd.read_csv("/mnt/shared-workspace/cmd3_data/sample_metadata.csv", index_col=0, low_memory=False)

print(f"cMD3 species abundance: {cmd3_species.shape}")
print(f"cMD3 PhILR: {cmd3_philr.shape}")
print(f"cMD3 CLR: {cmd3_clr.shape}")

# Load external data
print("\nLoading external T1D data...")
ext_species = pd.read_csv("/mnt/shared-workspace/external_data/Metagenomic analysis/Heatmap/species.xls", sep='\t', index_col=0)
ext_rel = ext_species.div(ext_species.sum(axis=0), axis=1)  # Convert to relative abundance

# Build name mapping
cmd3_to_short = {}
short_to_cmd3 = {}
for col in cmd3_species.columns:
    parts = col.split('|')
    species_part = [p for p in parts if p.startswith('s__')]
    if species_part:
        short = species_part[0].replace('s__', '')
        cmd3_to_short[col] = short
        short_to_cmd3[short] = col

overlap_short = set(ext_species.index) & set(cmd3_to_short.values())
print(f"Overlapping species: {len(overlap_short)} / {len(cmd3_to_short)} cMD3 species")

# Create external data aligned to cMD3 species (fill missing with 0)
ext_aligned = pd.DataFrame(0.0, index=ext_rel.columns, columns=cmd3_species.columns)
for short_name in overlap_short:
    cmd3_name = short_to_cmd3[short_name]
    if short_name in ext_rel.index:
        ext_aligned[cmd3_name] = ext_rel.loc[short_name].values

print(f"External aligned to cMD3 format: {ext_aligned.shape}")
print(f"Non-zero fraction: {(ext_aligned > 0).sum().sum() / (ext_aligned.shape[0] * ext_aligned.shape[1]):.3f}")

# External labels
ext_t1d_labels = np.array([1 if 'DM' in s else 0 for s in ext_rel.columns])
print(f"External T1D: {ext_t1d_labels.sum()} cases, {len(ext_t1d_labels) - ext_t1d_labels.sum()} controls")

# ============================================================
# 2. Apply CLR transform to external data
# ============================================================
print("\n=== Applying CLR Transform ===")

# CLR: log(X + pseudocount) - rowMeans(log(X + pseudocount))
pseudocount = 1e-6
log_ext = np.log(ext_aligned.values + pseudocount)
ext_clr = log_ext - log_ext.mean(axis=1, keepdims=True)
print(f"External CLR shape: {ext_clr.shape}")
print(f"CLR range: [{ext_clr.min():.2f}, {ext_clr.max():.2f}]")

# ============================================================
# 3. Apply PhILR transform to external data
# ============================================================
print("\n=== Applying PhILR Transform ===")

# We need to use the same PhILR parameters as cMD3
# The cMD3 PhILR was computed using the R philr package with:
# part.weights="uniform", ilr.weights="uniform", pseudocount=1e-6
# The tree and contrast matrix are saved

# Load the PhILR contrast matrix and SBP
philr_contrast = pd.read_csv("/mnt/shared-workspace/cmd3_data/philr_contrast_matrix.csv", index_col=0)
philr_sbp = pd.read_csv("/mnt/shared-workspace/cmd3_data/philr_sbp.csv", index_col=0)

print(f"PhILR contrast matrix: {philr_contrast.shape}")
print(f"PhILR SBP: {philr_sbp.shape}")

# Apply PhILR transform manually using the contrast matrix
# PhILR: y = ilr(x) where x is the CLR-transformed composition
# The ILR transform is: y = V^T * clr(x) where V is the contrast matrix
# But we need to handle the tree structure properly

# Actually, the simplest approach: since we have the CLR transform,
# and the PhILR is just an ILR transform on the CLR values using the phylogenetic tree,
# we can compute: philr = clr @ contrast_matrix
# But the contrast matrix from R's philr package includes the sequential binary partition

# Let me use the saved contrast matrix directly
# The contrast matrix V has shape (D, D-1) where D = number of species
# PhILR values = CLR_values @ V

# However, the external data has zeros for missing species, which will affect the CLR
# and hence the PhILR transform. This is a known issue - we need to handle it carefully.

# For now, let's use the contrast matrix approach
V = philr_contrast.values  # (1661, 1660)
print(f"Contrast matrix V shape: {V.shape}")

# Apply: philr = clr @ V
ext_philr_raw = ext_clr @ V
print(f"External PhILR raw shape: {ext_philr_raw.shape}")

# Pad to match cMD3 PhILR dimension (1660 vs 1659)
# The contrast matrix is missing one balance dimension
n_philr_expected = 1660  # cMD3 PhILR has 1660 features
if ext_philr_raw.shape[1] < n_philr_expected:
    padding = np.zeros((ext_philr_raw.shape[0], n_philr_expected - ext_philr_raw.shape[1]))
    ext_philr = np.hstack([ext_philr_raw, padding])
    print(f"Padded PhILR from {ext_philr_raw.shape[1]} to {ext_philr.shape[1]} features")
else:
    ext_philr = ext_philr_raw
print(f"External PhILR shape: {ext_philr.shape}")
print(f"PhILR range: [{ext_philr.min():.2f}, {ext_philr.max():.2f}]")

# ============================================================
# 4. Extract embeddings from pretrained models
# ============================================================
print("\n=== Extracting Embeddings ===")

from phylocompoclr_v2_train import PhyloCompoCLREncoder

def extract_embeddings(model_path, input_data):
    checkpoint = torch.load(model_path, map_location="cpu", weights_only=False)
    config = checkpoint["config"]
    encoder = PhyloCompoCLREncoder(config["input_dim"], config["hidden_dims"], config["embed_dim"])
    encoder.load_state_dict(checkpoint["encoder_state_dict"])
    encoder.eval()
    X = torch.tensor(input_data, dtype=torch.float32)
    embeddings = []
    with torch.no_grad():
        for i in range(0, len(X), 512):
            batch = X[i:i+512]
            emb = encoder(batch)
            embeddings.append(emb.numpy())
    return np.vstack(embeddings)

class V1CLREncoder(torch.nn.Module):
    def __init__(self, input_dim, hidden_dims, embed_dim):
        super().__init__()
        layers = []
        prev_dim = input_dim
        for h_dim in hidden_dims:
            layers.extend([torch.nn.Linear(prev_dim, h_dim), torch.nn.BatchNorm1d(h_dim), torch.nn.ReLU()])
            prev_dim = h_dim
        layers.append(torch.nn.Linear(prev_dim, embed_dim))
        self.net = torch.nn.Sequential(*layers)
    def forward(self, x):
        return self.net(x)

def extract_embeddings_v1(model_path, input_data):
    checkpoint = torch.load(model_path, map_location="cpu", weights_only=False)
    config = checkpoint["config"]
    encoder = V1CLREncoder(config["input_dim"], config["hidden_dims"], config["embed_dim"])
    encoder.load_state_dict(checkpoint["encoder_state_dict"])
    encoder.eval()
    X = torch.tensor(input_data, dtype=torch.float32)
    embeddings = []
    with torch.no_grad():
        for i in range(0, len(X), 512):
            batch = X[i:i+512]
            emb = encoder(batch)
            embeddings.append(emb.numpy())
    return np.vstack(embeddings)

# V2 ILR embeddings for external data
ext_v2_emb = extract_embeddings("/mnt/shared-workspace/models/species_v2_full_best.pt", ext_philr)
print(f"External V2 ILR embeddings: {ext_v2_emb.shape}")

# V1 CLR embeddings for external data
ext_v1_emb = extract_embeddings_v1("/mnt/shared-workspace/models/species_v1_clr_best.pt", ext_clr)
print(f"External V1 CLR embeddings: {ext_v1_emb.shape}")

# Also get cMD3 embeddings for comparison
cmd3_philr_vals = cmd3_philr.values.astype(np.float32)
cmd3_clr_vals = cmd3_clr.values.astype(np.float32)

cmd3_v2_emb = extract_embeddings("/mnt/shared-workspace/models/species_v2_full_best.pt", cmd3_philr_vals)
print(f"cMD3 V2 ILR embeddings: {cmd3_v2_emb.shape}")

cmd3_v1_emb = extract_embeddings_v1("/mnt/shared-workspace/models/species_v1_clr_best.pt", cmd3_clr_vals)
print(f"cMD3 V1 CLR embeddings: {cmd3_v1_emb.shape}")

# ============================================================
# 5. Evaluate on external T1D data alone
# ============================================================
print("\n" + "=" * 70)
print("EVALUATION: External T1D Data Alone (141 samples)")
print("=" * 70)

def evaluate_with_cv(X, y, n_splits=5, method_name="LR", random_state=42):
    """Evaluate with stratified CV, returning AUC and predictions."""
    if len(np.unique(y)) < 2:
        return None
    n_pos = y.sum()
    n_neg = len(y) - n_pos
    min_splits = min(n_splits, min(n_pos, n_neg))
    if min_splits < 2:
        return None
    
    skf = StratifiedKFold(n_splits=min_splits, shuffle=True, random_state=random_state)
    aucs = []
    fold_preds = []
    
    for train_idx, test_idx in skf.split(X, y):
        if method_name == "RF":
            clf = RandomForestClassifier(n_estimators=500, random_state=random_state, n_jobs=-1)
        else:
            clf = LogisticRegression(max_iter=1000, C=1.0, random_state=random_state)
        clf.fit(X[train_idx], y[train_idx])
        y_prob = clf.predict_proba(X[test_idx])[:, 1]
        auc = roc_auc_score(y[test_idx], y_prob)
        aucs.append(auc)
        fold_preds.append((y[test_idx].copy(), y_prob.copy()))
    
    return {
        'auc_mean': float(np.mean(aucs)),
        'auc_std': float(np.std(aucs)),
        'per_fold_aucs': [float(a) for a in aucs],
        'n_splits': min_splits,
        'fold_predictions': fold_preds,
    }

# External-only evaluation
ext_results = {}

# V2 ILR LP
r = evaluate_with_cv(ext_v2_emb, ext_t1d_labels, n_splits=5, method_name="LR")
if r:
    ext_results['V2_ILR_LP'] = {k: v for k, v in r.items() if k != 'fold_predictions'}
    ext_results['V2_ILR_LP']['fold_predictions'] = r['fold_predictions']
    print(f"  V2 ILR LP: AUC = {r['auc_mean']:.4f} +/- {r['auc_std']:.4f} ({r['n_splits']}-fold)")

# V1 CLR LP
r = evaluate_with_cv(ext_v1_emb, ext_t1d_labels, n_splits=5, method_name="LR")
if r:
    ext_results['V1_CLR_LP'] = {k: v for k, v in r.items() if k != 'fold_predictions'}
    ext_results['V1_CLR_LP']['fold_predictions'] = r['fold_predictions']
    print(f"  V1 CLR LP: AUC = {r['auc_mean']:.4f} +/- {r['auc_std']:.4f} ({r['n_splits']}-fold)")

# RF on PhILR
r = evaluate_with_cv(ext_philr, ext_t1d_labels, n_splits=5, method_name="RF")
if r:
    ext_results['RF_ILR'] = {k: v for k, v in r.items() if k != 'fold_predictions'}
    ext_results['RF_ILR']['fold_predictions'] = r['fold_predictions']
    print(f"  RF (ILR): AUC = {r['auc_mean']:.4f} +/- {r['auc_std']:.4f} ({r['n_splits']}-fold)")

# RF on CLR
r = evaluate_with_cv(ext_clr, ext_t1d_labels, n_splits=5, method_name="RF")
if r:
    ext_results['RF_CLR'] = {k: v for k, v in r.items() if k != 'fold_predictions'}
    ext_results['RF_CLR']['fold_predictions'] = r['fold_predictions']
    print(f"  RF (CLR): AUC = {r['auc_mean']:.4f} +/- {r['auc_std']:.4f} ({r['n_splits']}-fold)")

# ============================================================
# 6. Evaluate on combined cMD3 + external T1D data
# ============================================================
print("\n" + "=" * 70)
print("EVALUATION: Combined cMD3 + External T1D Data")
print("=" * 70)

# Get cMD3 T1D samples
cmd3_sample_ids = cmd3_philr.index.tolist()
cmd3_meta = metadata.loc[cmd3_sample_ids]
t1d_mask = cmd3_meta['t1d_binary'].notna()
cmd3_t1d_labels = cmd3_meta.loc[t1d_mask, 't1d_binary'].values.astype(int)

# Combine cMD3 T1D embeddings with external T1D embeddings
combined_v2_emb = np.vstack([cmd3_v2_emb[t1d_mask.values], ext_v2_emb])
combined_v1_emb = np.vstack([cmd3_v1_emb[t1d_mask.values], ext_v1_emb])
combined_t1d_labels = np.concatenate([cmd3_t1d_labels, ext_t1d_labels])

print(f"Combined T1D: {len(combined_t1d_labels)} samples (T1D={combined_t1d_labels.sum()}, ctrl={len(combined_t1d_labels)-combined_t1d_labels.sum()})")
print(f"  cMD3: {len(cmd3_t1d_labels)} (T1D={cmd3_t1d_labels.sum()}, ctrl={len(cmd3_t1d_labels)-cmd3_t1d_labels.sum()})")
print(f"  External: {len(ext_t1d_labels)} (T1D={ext_t1d_labels.sum()}, ctrl={len(ext_t1d_labels)-ext_t1d_labels.sum()})")

combined_results = {}

# V2 ILR LP on combined
r = evaluate_with_cv(combined_v2_emb, combined_t1d_labels, n_splits=5, method_name="LR")
if r:
    combined_results['V2_ILR_LP'] = {k: v for k, v in r.items() if k != 'fold_predictions'}
    combined_results['V2_ILR_LP']['fold_preds'] = r['fold_predictions']
    print(f"  V2 ILR LP (combined): AUC = {r['auc_mean']:.4f} +/- {r['auc_std']:.4f} ({r['n_splits']}-fold)")

# V1 CLR LP on combined
r = evaluate_with_cv(combined_v1_emb, combined_t1d_labels, n_splits=5, method_name="LR")
if r:
    combined_results['V1_CLR_LP'] = {k: v for k, v in r.items() if k != 'fold_predictions'}
    combined_results['V1_CLR_LP']['fold_preds'] = r['fold_predictions']
    print(f"  V1 CLR LP (combined): AUC = {r['auc_mean']:.4f} +/- {r['auc_std']:.4f} ({r['n_splits']}-fold)")

# ============================================================
# 7. Cross-dataset evaluation: train on cMD3, test on external
# ============================================================
print("\n" + "=" * 70)
print("CROSS-DATASET EVALUATION: Train cMD3 -> Test External")
print("=" * 70)

# Train on cMD3 T1D, test on external T1D
cross_results = {}

# V2 ILR LP
clf_v2 = LogisticRegression(max_iter=1000, C=1.0, random_state=42)
clf_v2.fit(cmd3_v2_emb[t1d_mask.values], cmd3_t1d_labels)
y_prob_v2 = clf_v2.predict_proba(ext_v2_emb)[:, 1]
cross_auc_v2 = roc_auc_score(ext_t1d_labels, y_prob_v2)
cross_results['V2_ILR_LP'] = {'auc': float(cross_auc_v2)}
print(f"  V2 ILR LP: AUC = {cross_auc_v2:.4f}")

# V1 CLR LP
clf_v1 = LogisticRegression(max_iter=1000, C=1.0, random_state=42)
clf_v1.fit(cmd3_v1_emb[t1d_mask.values], cmd3_t1d_labels)
y_prob_v1 = clf_v1.predict_proba(ext_v1_emb)[:, 1]
cross_auc_v1 = roc_auc_score(ext_t1d_labels, y_prob_v1)
cross_results['V1_CLR_LP'] = {'auc': float(cross_auc_v1)}
print(f"  V1 CLR LP: AUC = {cross_auc_v1:.4f}")

# RF on ILR
rf_ilr = RandomForestClassifier(n_estimators=500, random_state=42, n_jobs=-1)
rf_ilr.fit(cmd3_philr_vals[t1d_mask.values], cmd3_t1d_labels)
y_prob_rf = rf_ilr.predict_proba(ext_philr)[:, 1]
cross_auc_rf = roc_auc_score(ext_t1d_labels, y_prob_rf)
cross_results['RF_ILR'] = {'auc': float(cross_auc_rf)}
print(f"  RF (ILR): AUC = {cross_auc_rf:.4f}")

# RF on CLR
rf_clr = RandomForestClassifier(n_estimators=500, random_state=42, n_jobs=-1)
rf_clr.fit(cmd3_clr_vals[t1d_mask.values], cmd3_t1d_labels)
y_prob_rf_clr = rf_clr.predict_proba(ext_clr)[:, 1]
cross_auc_rf_clr = roc_auc_score(ext_t1d_labels, y_prob_rf_clr)
cross_results['RF_CLR'] = {'auc': float(cross_auc_rf_clr)}
print(f"  RF (CLR): AUC = {cross_auc_rf_clr:.4f}")

# ============================================================
# 8. DeLong tests for external evaluation
# ============================================================
print("\n" + "=" * 70)
print("DELONG TESTS: External T1D Evaluation")
print("=" * 70)

# Import DeLong test from our module
sys.path.insert(0, "/mnt/shared-workspace")
from run_delong_tests import delong_roc_test, benjamini_hochberg

# Cross-dataset DeLong tests (all methods tested on same external samples)
cross_comparisons = []
cross_preds = {
    'V2_ILR_LP': (ext_t1d_labels, y_prob_v2),
    'V1_CLR_LP': (ext_t1d_labels, y_prob_v1),
    'RF_ILR': (ext_t1d_labels, y_prob_rf),
    'RF_CLR': (ext_t1d_labels, y_prob_rf_clr),
}

from itertools import combinations as comb
for mA, mB in comb(list(cross_preds.keys()), 2):
    y_true_A, y_prob_A = cross_preds[mA]
    y_true_B, y_prob_B = cross_preds[mB]
    z, p, auc_A, auc_B = delong_roc_test(y_true_A, y_prob_A, y_prob_B)
    cross_comparisons.append({
        'method_A': mA, 'method_B': mB,
        'auc_A': float(auc_A), 'auc_B': float(auc_B),
        'delta_auc': float(auc_A - auc_B),
        'z_stat': float(z), 'p_value_raw': float(p),
    })
    sig = "***" if p < 0.001 else "**" if p < 0.01 else "*" if p < 0.05 else ""
    print(f"  {mA} vs {mB}: dAUC={auc_A-auc_B:+.4f}, z={z:.3f}, p={p:.4f} {sig}")

# BH correction
raw_p = np.array([c['p_value_raw'] for c in cross_comparisons])
corrected_p, significant = benjamini_hochberg(raw_p, alpha=0.05)
for i, comp in enumerate(cross_comparisons):
    comp['p_value_bh'] = float(corrected_p[i])
    comp['significant_bh_005'] = bool(significant[i])

n_sig = sum(significant)
print(f"\n  BH-corrected: {n_sig}/{len(cross_comparisons)} significant at FDR<0.05")

# ============================================================
# 9. Save all results
# ============================================================
print("\n" + "=" * 70)
print("SAVING RESULTS")
print("=" * 70)

# Clean up fold_preds for JSON serialization
def clean_for_json(obj):
    if isinstance(obj, np.integer): return int(obj)
    elif isinstance(obj, np.floating): return float(obj)
    elif isinstance(obj, np.ndarray): return obj.tolist()
    elif isinstance(obj, dict): return {k: clean_for_json(v) for k, v in obj.items()}
    elif isinstance(obj, list): return [clean_for_json(v) for v in obj]
    elif isinstance(obj, tuple): return list(clean_for_json(v) for v in obj)
    return obj

# Remove fold_preds from serializable results
ext_results_clean = {}
for k, v in ext_results.items():
    ext_results_clean[k] = {kk: vv for kk, vv in v.items() if kk != 'fold_predictions'}

combined_results_clean = {}
for k, v in combined_results.items():
    combined_results_clean[k] = {kk: vv for kk, vv in v.items() if kk != 'fold_predictions'}

all_external_results = {
    'external_only': ext_results_clean,
    'combined_cmd3_external': combined_results_clean,
    'cross_dataset_cmd3_to_external': cross_results,
    'delong_cross_dataset': cross_comparisons,
    'external_cohort_info': {
        'n_total': len(ext_t1d_labels),
        'n_t1d': int(ext_t1d_labels.sum()),
        'n_control': int(len(ext_t1d_labels) - ext_t1d_labels.sum()),
        'source': 'Nature Communications 2022 (PRJNA664632)',
        'n_species_overlap': len(overlap_short),
        'n_species_cmd3': len(cmd3_to_short),
    }
}

with open("/mnt/results/evaluation_external_t1d.json", "w") as f:
    json.dump(clean_for_json(all_external_results), f, indent=2)
print("Saved: /mnt/results/evaluation_external_t1d.json")

# ============================================================
# 10. Print final summary
# ============================================================
print("\n" + "=" * 70)
print("FINAL SUMMARY: External T1D Evaluation")
print("=" * 70)

print("\n--- External T1D Only (141 samples: 64 T1D, 77 ctrl) ---")
for method, res in ext_results_clean.items():
    print(f"  {method}: AUC = {res['auc_mean']:.4f} +/- {res['auc_std']:.4f}")

print("\n--- Combined cMD3 + External T1D ---")
for method, res in combined_results_clean.items():
    print(f"  {method}: AUC = {res['auc_mean']:.4f} +/- {res['auc_std']:.4f}")

print("\n--- Cross-Dataset: Train cMD3 -> Test External ---")
for method, res in cross_results.items():
    print(f"  {method}: AUC = {res['auc']:.4f}")

print("\n--- DeLong Tests (Cross-Dataset) ---")
for comp in cross_comparisons:
    sig = "***" if comp['p_value_bh'] < 0.001 else "**" if comp['p_value_bh'] < 0.01 else "*" if comp['p_value_bh'] < 0.05 else "ns"
    print(f"  {comp['method_A']} vs {comp['method_B']}: dAUC={comp['delta_auc']:+.4f}, p_BH={comp['p_value_bh']:.4f} [{sig}]")

# Compare with cMD3-only T1D results
print("\n--- Comparison: cMD3 T1D Only vs External Validation ---")
cmd3_t1d_v2 = evaluate_with_cv(cmd3_v2_emb[t1d_mask.values], cmd3_t1d_labels, n_splits=3, method_name="LR")
cmd3_t1d_v1 = evaluate_with_cv(cmd3_v1_emb[t1d_mask.values], cmd3_t1d_labels, n_splits=3, method_name="LR")
if cmd3_t1d_v2:
    print(f"  cMD3-only V2 ILR LP: AUC = {cmd3_t1d_v2['auc_mean']:.4f} +/- {cmd3_t1d_v2['auc_std']:.4f}")
if cmd3_t1d_v1:
    print(f"  cMD3-only V1 CLR LP: AUC = {cmd3_t1d_v1['auc_mean']:.4f} +/- {cmd3_t1d_v1['auc_std']:.4f}")
print(f"  Cross-dataset V2 ILR LP: AUC = {cross_auc_v2:.4f}")
print(f"  Cross-dataset V1 CLR LP: AUC = {cross_auc_v1:.4f}")
print(f"  Cross-dataset RF (ILR): AUC = {cross_auc_rf:.4f}")
print(f"  Cross-dataset RF (CLR): AUC = {cross_auc_rf_clr:.4f}")

print("\nDone!")
