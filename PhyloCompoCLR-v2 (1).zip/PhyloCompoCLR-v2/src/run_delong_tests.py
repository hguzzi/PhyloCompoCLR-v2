#!/usr/bin/env python3
"""
DeLong Statistical Tests for PhyloCompoCLR V2 Results.

Re-runs all evaluations saving raw predictions (y_true, y_prob per fold),
then applies the DeLong test for all pairwise AUC comparisons with
Benjamini-Hochberg FDR correction.
"""

import sys
sys.path.insert(0, "/mnt/shared-workspace")

import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score
from scipy import stats
from itertools import combinations
import json
import os
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# DeLong Test Implementation
# ============================================================

def _compute_midrank(x):
    """Computes midranks for the DeLong test."""
    J = np.argsort(x)
    Z = x[J]
    N = len(x)
    T = np.zeros(N, dtype=float)
    i = 0
    while i < N:
        j = i
        while j < N and Z[j] == Z[i]:
            j += 1
        T[i:j] = 0.5 * (i + j + 1)
        i = j
    T2 = np.empty(N, dtype=float)
    T2[J] = T
    return T2


def delong_roc_test(y_true, y_pred_A, y_pred_B):
    """
    DeLong's test for comparing two correlated AUCs.
    
    Returns z_stat, p_value, auc_A, auc_B.
    """
    y_true = np.asarray(y_true)
    y_pred_A = np.asarray(y_pred_A)
    y_pred_B = np.asarray(y_pred_B)
    
    auc_A = roc_auc_score(y_true, y_pred_A)
    auc_B = roc_auc_score(y_true, y_pred_B)
    
    n_pos = np.sum(y_true == 1)
    n_neg = np.sum(y_true == 0)
    
    if n_pos == 0 or n_neg == 0:
        return 0.0, 1.0, auc_A, auc_B
    
    V_A10 = y_pred_A[y_true == 1]
    V_A01 = y_pred_A[y_true == 0]
    V_B10 = y_pred_B[y_true == 1]
    V_B01 = y_pred_B[y_true == 0]
    
    def compute_V(V10, V01):
        m = len(V10)
        n = len(V01)
        combined = np.concatenate([V10, V01])
        midranks = _compute_midrank(combined)
        V10_ranks = midranks[:m]
        V01_ranks = midranks[m:]
        V10_vals = (V10_ranks - np.arange(m) - 1) / n
        V01_vals = (V01_ranks - np.arange(n) - 1) / m
        return V10_vals, V01_vals
    
    V10_A, V01_A = compute_V(V_A10, V_A01)
    V10_B, V01_B = compute_V(V_B10, V_B01)
    
    S10 = np.cov(np.vstack([V10_A, V10_B]), bias=True)
    S01 = np.cov(np.vstack([V01_A, V01_B]), bias=True)
    
    S = S10 / n_pos + S01 / n_neg
    var_diff = S[0, 0] + S[1, 1] - 2 * S[0, 1]
    
    if var_diff <= 0:
        var_diff = max(var_diff, 1e-10)
    
    z_stat = (auc_A - auc_B) / np.sqrt(var_diff)
    p_value = 2 * (1 - stats.norm.cdf(abs(z_stat)))
    
    return z_stat, p_value, auc_A, auc_B


def delong_roc_test_paired(fold_predictions_A, fold_predictions_B):
    """
    DeLong test for paired ROC curves from cross-validation.
    Combines predictions across folds and runs a single DeLong test.
    """
    y_true_all = np.concatenate([fp[0] for fp in fold_predictions_A])
    y_prob_A_all = np.concatenate([fp[1] for fp in fold_predictions_A])
    y_prob_B_all = np.concatenate([fp[1] for fp in fold_predictions_B])
    
    z_stat, p_value, auc_A, auc_B = delong_roc_test(y_true_all, y_prob_A_all, y_prob_B_all)
    
    return {
        'z_stat': float(z_stat),
        'p_value': float(p_value),
        'auc_A': float(auc_A),
        'auc_B': float(auc_B),
        'delta_auc': float(auc_A - auc_B),
    }


def benjamini_hochberg(p_values, alpha=0.05):
    """Apply Benjamini-Hochberg FDR correction."""
    p_values = np.asarray(p_values)
    n = len(p_values)
    sorted_idx = np.argsort(p_values)
    sorted_p = p_values[sorted_idx]
    
    adjusted = np.zeros(n)
    for i in range(n):
        adjusted[sorted_idx[i]] = sorted_p[i] * n / (i + 1)
    
    # Ensure monotonicity (step-up)
    cummin = np.zeros(n)
    cummin[sorted_idx[-1]] = adjusted[sorted_idx[-1]]
    for i in range(n - 2, -1, -1):
        cummin[sorted_idx[i]] = min(adjusted[sorted_idx[i]], cummin[sorted_idx[i + 1]])
    
    corrected_p = np.minimum(cummin, 1.0)
    significant = corrected_p <= alpha
    
    return corrected_p, significant


# ============================================================
# Evaluation with prediction saving
# ============================================================

def linear_probe_with_preds(X, y, n_splits=5, random_state=42):
    """Linear probe that saves raw predictions per fold."""
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    fold_preds = []
    aucs = []
    for train_idx, test_idx in skf.split(X, y):
        clf = LogisticRegression(max_iter=1000, C=1.0, random_state=random_state)
        clf.fit(X[train_idx], y[train_idx])
        y_prob = clf.predict_proba(X[test_idx])[:, 1]
        y_true = y[test_idx]
        auc = roc_auc_score(y_true, y_prob)
        aucs.append(auc)
        fold_preds.append((y_true.copy(), y_prob.copy()))
    return {
        'auc_mean': float(np.mean(aucs)),
        'auc_std': float(np.std(aucs)),
        'per_fold_aucs': [float(a) for a in aucs],
        'fold_predictions': fold_preds,
    }


def rf_with_preds(X, y, n_splits=5, random_state=42):
    """RF baseline that saves raw predictions per fold."""
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    fold_preds = []
    aucs = []
    for train_idx, test_idx in skf.split(X, y):
        clf = RandomForestClassifier(n_estimators=500, random_state=random_state, n_jobs=-1)
        clf.fit(X[train_idx], y[train_idx])
        y_prob = clf.predict_proba(X[test_idx])[:, 1]
        y_true = y[test_idx]
        auc = roc_auc_score(y_true, y_prob)
        aucs.append(auc)
        fold_preds.append((y_true.copy(), y_prob.copy()))
    return {
        'auc_mean': float(np.mean(aucs)),
        'auc_std': float(np.std(aucs)),
        'per_fold_aucs': [float(a) for a in aucs],
        'fold_predictions': fold_preds,
    }


def extract_embeddings(model_path, input_data):
    """Extract embeddings from a saved model checkpoint."""
    from phylocompoclr_v2_train import PhyloCompoCLREncoder
    checkpoint = torch.load(model_path, map_location="cpu", weights_only=False)
    config = checkpoint["config"]
    encoder = PhyloCompoCLREncoder(config["input_dim"], config["hidden_dims"], config["embed_dim"])
    encoder.load_state_dict(checkpoint["encoder_state_dict"])
    encoder.eval()
    X = torch.tensor(input_data, dtype=torch.float32)
    embeddings = []
    with torch.no_grad():
        for i in range(0, len(X), 512):
            batch = X[i:i+512]
            emb = encoder(batch)
            embeddings.append(emb.numpy())
    return np.vstack(embeddings)



class V1CLREncoder(torch.nn.Module):
    """V1 CLR Encoder that uses self.net instead of self.encoder."""
    def __init__(self, input_dim, hidden_dims, embed_dim):
        super().__init__()
        layers = []
        prev_dim = input_dim
        for h_dim in hidden_dims:
            layers.extend([
                torch.nn.Linear(prev_dim, h_dim),
                torch.nn.BatchNorm1d(h_dim),
                torch.nn.ReLU(),
            ])
            prev_dim = h_dim
        layers.append(torch.nn.Linear(prev_dim, embed_dim))
        self.net = torch.nn.Sequential(*layers)
    
    def forward(self, x):
        return self.net(x)


def extract_embeddings_v1(model_path, input_data):
    """Extract embeddings from a V1 CLR model checkpoint (uses self.net)."""
    checkpoint = torch.load(model_path, map_location="cpu", weights_only=False)
    config = checkpoint["config"]
    encoder = V1CLREncoder(config["input_dim"], config["hidden_dims"], config["embed_dim"])
    encoder.load_state_dict(checkpoint["encoder_state_dict"])
    encoder.eval()
    X = torch.tensor(input_data, dtype=torch.float32)
    embeddings = []
    with torch.no_grad():
        for i in range(0, len(X), 512):
            batch = X[i:i+512]
            emb = encoder(batch)
            embeddings.append(emb.numpy())
    return np.vstack(embeddings)

# ============================================================
# Main evaluation + DeLong test pipeline
# ============================================================

def run_delong_analysis():
    """Run the complete DeLong test analysis for all methods and tasks."""
    
    print("=" * 70)
    print("DeLong Statistical Tests for PhyloCompoCLR V2")
    print("=" * 70)
    
    # --------------------------------------------------------
    # Load data
    # --------------------------------------------------------
    print("\nLoading data...")
    
    # Genus level
    genus_philr = pd.read_csv("/mnt/shared-workspace/cmd3_data/genus_philr_transform.csv", index_col=0)
    genus_ilr = genus_philr.values.astype(np.float32)
    genus_sample_ids = genus_philr.index.tolist()
    del genus_philr
    import gc; gc.collect()
    print(f"Genus ILR: {genus_ilr.shape}")
    
    genus_clr = pd.read_csv("/mnt/shared-workspace/cmd3_data/genus_clr_transform.csv", index_col=0)
    genus_clr_vals = genus_clr.values.astype(np.float32)
    del genus_clr; gc.collect()
    print(f"Genus CLR: {genus_clr_vals.shape}")
    
    # Species level
    species_philr = pd.read_csv("/mnt/shared-workspace/cmd3_data/species_philr_transform.csv", index_col=0)
    species_ilr = species_philr.values.astype(np.float32)
    species_sample_ids = species_philr.index.tolist()
    del species_philr; gc.collect()
    print(f"Species ILR: {species_ilr.shape}")
    
    species_clr = pd.read_csv("/mnt/shared-workspace/cmd3_data/species_clr_transform.csv", index_col=0)
    species_clr_vals = species_clr.values.astype(np.float32)
    del species_clr; gc.collect()
    print(f"Species CLR: {species_clr_vals.shape}")
    
    # Metadata
    metadata = pd.read_csv("/mnt/shared-workspace/cmd3_data/sample_metadata.csv", index_col=0, low_memory=False)
    genus_meta = metadata.loc[genus_sample_ids]
    species_meta = metadata.loc[species_sample_ids]
    
    # --------------------------------------------------------
    # Extract all embeddings
    # --------------------------------------------------------
    print("\n=== Extracting Embeddings ===")
    
    # Genus models
    genus_models = {
        'V2_ILR_LP': ('/mnt/shared-workspace/models/genus_v2_full_best.pt', genus_ilr),
        'V2_pert_only': ('/mnt/shared-workspace/models/genus_v2_pert_only_best.pt', genus_ilr),
        'V2_power_only': ('/mnt/shared-workspace/models/genus_v2_power_only_best.pt', genus_ilr),
        'V2_mixup_only': ('/mnt/shared-workspace/models/genus_v2_mixup_only_best.pt', genus_ilr),
        'V2_phylo_only': ('/mnt/shared-workspace/models/genus_v2_phylo_only_best.pt', genus_ilr),
        'V2_no_aug': ('/mnt/shared-workspace/models/genus_v2_no_aug_best.pt', genus_ilr),
    }
    
    genus_embeddings = {}
    for name, (path, data) in genus_models.items():
        if os.path.exists(path):
            print(f"  {name}: extracting...")
            genus_embeddings[name] = extract_embeddings(path, data)
            print(f"    Shape: {genus_embeddings[name].shape}")
        else:
            print(f"  {name}: model not found at {path}")
    
    # Genus V1 CLR (uses CLR data, not ILR)
    v1_clr_path = '/mnt/shared-workspace/models/genus_v1_clr_best.pt'
    if os.path.exists(v1_clr_path):
        print(f"  V1_CLR_LP: extracting...")
        genus_embeddings['V1_CLR_LP'] = extract_embeddings(v1_clr_path, genus_clr_vals)
        print(f"    Shape: {genus_embeddings['V1_CLR_LP'].shape}")
    
    # Species models
    species_models = {
        'V2_ILR_LP': ('/mnt/shared-workspace/models/species_v2_full_best.pt', species_ilr),
    }
    
    species_embeddings = {}
    for name, (path, data) in species_models.items():
        if os.path.exists(path):
            print(f"  Species {name}: extracting...")
            species_embeddings[name] = extract_embeddings(path, data)
            print(f"    Shape: {species_embeddings[name].shape}")
    
    # Species V1 CLR
    species_v1_path = '/mnt/shared-workspace/models/species_v1_clr_best.pt'
    if os.path.exists(species_v1_path):
        print(f"  Species V1_CLR_LP: extracting...")
        species_embeddings['V1_CLR_LP'] = extract_embeddings_v1(species_v1_path, species_clr_vals)
        print(f"    Shape: {species_embeddings['V1_CLR_LP'].shape}")
    
    # --------------------------------------------------------
    # Run evaluations with prediction saving
    # --------------------------------------------------------
    all_predictions = {}  # {level: {task: {method: fold_predictions}}}
    all_auc_results = {}  # {level: {task: {method: auc_stats}}}
    
    # --- GENUS LEVEL ---
    print("\n" + "=" * 70)
    print("GENUS-LEVEL EVALUATION WITH PREDICTION SAVING")
    print("=" * 70)
    
    # T2D labels
    t2d_mask_g = genus_meta['t2d_binary'].notna()
    t2d_labels_g = genus_meta.loc[t2d_mask_g, 't2d_binary'].values.astype(int)
    print(f"\nGenus T2D: {len(t2d_labels_g)} samples (T2D={t2d_labels_g.sum()}, ctrl={len(t2d_labels_g)-t2d_labels_g.sum()})")
    
    # T1D labels
    t1d_mask_g = genus_meta['t1d_binary'].notna()
    t1d_labels_g = genus_meta.loc[t1d_mask_g, 't1d_binary'].values.astype(int)
    print(f"Genus T1D: {len(t1d_labels_g)} samples (T1D={t1d_labels_g.sum()}, ctrl={len(t1d_labels_g)-t1d_labels_g.sum()})")
    
    genus_preds = {'t2d': {}, 't1d': {}}
    genus_aucs = {'t2d': {}, 't1d': {}}
    
    # Genus T2D - embedding-based methods
    for name, emb in genus_embeddings.items():
        print(f"\n  Genus T2D - {name}...")
        result = linear_probe_with_preds(emb[t2d_mask_g.values], t2d_labels_g, n_splits=5)
        genus_preds['t2d'][name] = result['fold_predictions']
        genus_aucs['t2d'][name] = {k: v for k, v in result.items() if k != 'fold_predictions'}
        print(f"    AUC = {result['auc_mean']:.4f} +/- {result['auc_std']:.4f}")
    
    # Genus T2D - RF baselines
    print(f"\n  Genus T2D - RF(ILR)...")
    rf_ilr_result = rf_with_preds(genus_ilr[t2d_mask_g.values], t2d_labels_g, n_splits=5)
    genus_preds['t2d']['RF_ILR'] = rf_ilr_result['fold_predictions']
    genus_aucs['t2d']['RF_ILR'] = {k: v for k, v in rf_ilr_result.items() if k != 'fold_predictions'}
    print(f"    AUC = {rf_ilr_result['auc_mean']:.4f} +/- {rf_ilr_result['auc_std']:.4f}")
    
    print(f"\n  Genus T2D - RF(CLR)...")
    rf_clr_result = rf_with_preds(genus_clr_vals[t2d_mask_g.values], t2d_labels_g, n_splits=5)
    genus_preds['t2d']['RF_CLR'] = rf_clr_result['fold_predictions']
    genus_aucs['t2d']['RF_CLR'] = {k: v for k, v in rf_clr_result.items() if k != 'fold_predictions'}
    print(f"    AUC = {rf_clr_result['auc_mean']:.4f} +/- {rf_clr_result['auc_std']:.4f}")
    
    # Genus T1D - embedding-based methods
    for name, emb in genus_embeddings.items():
        print(f"\n  Genus T1D - {name}...")
        result = linear_probe_with_preds(emb[t1d_mask_g.values], t1d_labels_g, n_splits=3)
        genus_preds['t1d'][name] = result['fold_predictions']
        genus_aucs['t1d'][name] = {k: v for k, v in result.items() if k != 'fold_predictions'}
        print(f"    AUC = {result['auc_mean']:.4f} +/- {result['auc_std']:.4f}")
    
    # Genus T1D - RF baseline
    print(f"\n  Genus T1D - RF(ILR)...")
    rf_ilr_t1d = rf_with_preds(genus_ilr[t1d_mask_g.values], t1d_labels_g, n_splits=3)
    genus_preds['t1d']['RF_ILR'] = rf_ilr_t1d['fold_predictions']
    genus_aucs['t1d']['RF_ILR'] = {k: v for k, v in rf_ilr_t1d.items() if k != 'fold_predictions'}
    print(f"    AUC = {rf_ilr_t1d['auc_mean']:.4f} +/- {rf_ilr_t1d['auc_std']:.4f}")
    
    all_predictions['genus'] = genus_preds
    all_auc_results['genus'] = genus_aucs
    
    # --- SPECIES LEVEL ---
    print("\n" + "=" * 70)
    print("SPECIES-LEVEL EVALUATION WITH PREDICTION SAVING")
    print("=" * 70)
    
    # T2D labels
    t2d_mask_s = species_meta['t2d_binary'].notna()
    t2d_labels_s = species_meta.loc[t2d_mask_s, 't2d_binary'].values.astype(int)
    print(f"\nSpecies T2D: {len(t2d_labels_s)} samples (T2D={t2d_labels_s.sum()}, ctrl={len(t2d_labels_s)-t2d_labels_s.sum()})")
    
    # T1D labels
    t1d_mask_s = species_meta['t1d_binary'].notna()
    t1d_labels_s = species_meta.loc[t1d_mask_s, 't1d_binary'].values.astype(int)
    print(f"Species T1D: {len(t1d_labels_s)} samples (T1D={t1d_labels_s.sum()}, ctrl={len(t1d_labels_s)-t1d_labels_s.sum()})")
    
    species_preds = {'t2d': {}, 't1d': {}}
    species_aucs = {'t2d': {}, 't1d': {}}
    
    # Species T2D - embedding-based methods
    for name, emb in species_embeddings.items():
        print(f"\n  Species T2D - {name}...")
        result = linear_probe_with_preds(emb[t2d_mask_s.values], t2d_labels_s, n_splits=5)
        species_preds['t2d'][name] = result['fold_predictions']
        species_aucs['t2d'][name] = {k: v for k, v in result.items() if k != 'fold_predictions'}
        print(f"    AUC = {result['auc_mean']:.4f} +/- {result['auc_std']:.4f}")
    
    # Species T2D - RF baselines
    print(f"\n  Species T2D - RF(ILR)...")
    rf_ilr_s = rf_with_preds(species_ilr[t2d_mask_s.values], t2d_labels_s, n_splits=5)
    species_preds['t2d']['RF_ILR'] = rf_ilr_s['fold_predictions']
    species_aucs['t2d']['RF_ILR'] = {k: v for k, v in rf_ilr_s.items() if k != 'fold_predictions'}
    print(f"    AUC = {rf_ilr_s['auc_mean']:.4f} +/- {rf_ilr_s['auc_std']:.4f}")
    
    print(f"\n  Species T2D - RF(CLR)...")
    rf_clr_s = rf_with_preds(species_clr_vals[t2d_mask_s.values], t2d_labels_s, n_splits=5)
    species_preds['t2d']['RF_CLR'] = rf_clr_s['fold_predictions']
    species_aucs['t2d']['RF_CLR'] = {k: v for k, v in rf_clr_s.items() if k != 'fold_predictions'}
    print(f"    AUC = {rf_clr_s['auc_mean']:.4f} +/- {rf_clr_s['auc_std']:.4f}")
    
    # Species T1D - embedding-based methods
    for name, emb in species_embeddings.items():
        print(f"\n  Species T1D - {name}...")
        result = linear_probe_with_preds(emb[t1d_mask_s.values], t1d_labels_s, n_splits=3)
        species_preds['t1d'][name] = result['fold_predictions']
        species_aucs['t1d'][name] = {k: v for k, v in result.items() if k != 'fold_predictions'}
        print(f"    AUC = {result['auc_mean']:.4f} +/- {result['auc_std']:.4f}")
    
    # Species T1D - RF baseline
    print(f"\n  Species T1D - RF(ILR)...")
    rf_ilr_t1d_s = rf_with_preds(species_ilr[t1d_mask_s.values], t1d_labels_s, n_splits=3)
    species_preds['t1d']['RF_ILR'] = rf_ilr_t1d_s['fold_predictions']
    species_aucs['t1d']['RF_ILR'] = {k: v for k, v in rf_ilr_t1d_s.items() if k != 'fold_predictions'}
    print(f"    AUC = {rf_ilr_t1d_s['auc_mean']:.4f} +/- {rf_ilr_t1d_s['auc_std']:.4f}")
    
    all_predictions['species'] = species_preds
    all_auc_results['species'] = species_aucs
    
    # --------------------------------------------------------
    # Run DeLong tests
    # --------------------------------------------------------
    print("\n" + "=" * 70)
    print("DELONG PAIRED AUC COMPARISONS")
    print("=" * 70)
    
    delong_results = {}
    
    for level in ['genus', 'species']:
        for task in ['t2d', 't1d']:
            key = f"{level}_{task}"
            methods = list(all_predictions[level][task].keys())
            if len(methods) < 2:
                print(f"\n{key}: Only {len(methods)} method(s), skipping DeLong tests")
                continue
            
            n_comparisons = len(list(combinations(methods, 2)))
            print(f"\n--- {key.upper()}: {len(methods)} methods, {n_comparisons} pairwise comparisons ---")
            
            comparisons = []
            for method_A, method_B in combinations(methods, 2):
                preds_A = all_predictions[level][task][method_A]
                preds_B = all_predictions[level][task][method_B]
                
                if len(preds_A) != len(preds_B):
                    print(f"  WARNING: {method_A} has {len(preds_A)} folds, {method_B} has {len(preds_B)} folds - skipping")
                    continue
                
                result = delong_roc_test_paired(preds_A, preds_B)
                comparisons.append({
                    'method_A': method_A,
                    'method_B': method_B,
                    'auc_A': result['auc_A'],
                    'auc_B': result['auc_B'],
                    'delta_auc': result['delta_auc'],
                    'z_stat': result['z_stat'],
                    'p_value_raw': result['p_value'],
                })
                sig = "***" if result['p_value'] < 0.001 else "**" if result['p_value'] < 0.01 else "*" if result['p_value'] < 0.05 else ""
                print(f"  {method_A} vs {method_B}: dAUC={result['delta_auc']:+.4f}, z={result['z_stat']:.3f}, p={result['p_value']:.4f} {sig}")
            
            # BH correction
            if comparisons:
                raw_p = np.array([c['p_value_raw'] for c in comparisons])
                corrected_p, significant = benjamini_hochberg(raw_p, alpha=0.05)
                
                for i, comp in enumerate(comparisons):
                    comp['p_value_bh'] = float(corrected_p[i])
                    comp['significant_bh_005'] = bool(significant[i])
                
                delong_results[key] = comparisons
                
                n_sig = sum(significant)
                print(f"\n  BH-corrected: {n_sig}/{len(comparisons)} significant at FDR<0.05")
            
            # Print summary table
            print(f"\n  {'Method A':<18} {'Method B':<18} {'dAUC':>8} {'z':>8} {'p_raw':>10} {'p_BH':>10} {'Sig':>4}")
            print(f"  {'-'*18} {'-'*18} {'-'*8} {'-'*8} {'-'*10} {'-'*10} {'-'*4}")
            for comp in comparisons:
                sig = "***" if comp['p_value_bh'] < 0.001 else "**" if comp['p_value_bh'] < 0.01 else "*" if comp['p_value_bh'] < 0.05 else ""
                print(f"  {comp['method_A']:<18} {comp['method_B']:<18} {comp['delta_auc']:+8.4f} {comp['z_stat']:8.3f} {comp['p_value_raw']:10.4f} {comp['p_value_bh']:10.4f} {sig:>4}")
    
    # --------------------------------------------------------
    # Save results
    # --------------------------------------------------------
    print("\n" + "=" * 70)
    print("SAVING RESULTS")
    print("=" * 70)
    
    # Save DeLong results
    with open("/mnt/results/delong_test_results.json", "w") as f:
        json.dump(delong_results, f, indent=2, default=float)
    print("Saved: /mnt/results/delong_test_results.json")
    
    # Save AUC summary
    def convert_for_json(obj):
        if isinstance(obj, np.integer): return int(obj)
        elif isinstance(obj, np.floating): return float(obj)
        elif isinstance(obj, np.ndarray): return obj.tolist()
        elif isinstance(obj, dict): return {k: convert_for_json(v) for k, v in obj.items()}
        elif isinstance(obj, list): return [convert_for_json(v) for v in obj]
        return obj
    
    with open("/mnt/results/delong_auc_summary.json", "w") as f:
        json.dump(convert_for_json(all_auc_results), f, indent=2)
    print("Saved: /mnt/results/delong_auc_summary.json")
    
    # Create formatted CSV tables
    for key, comparisons in delong_results.items():
        rows = []
        for comp in comparisons:
            rows.append({
                'method_A': comp['method_A'],
                'method_B': comp['method_B'],
                'auc_A': comp['auc_A'],
                'auc_B': comp['auc_B'],
                'delta_auc': comp['delta_auc'],
                'z_stat': comp['z_stat'],
                'p_value_raw': comp['p_value_raw'],
                'p_value_bh': comp['p_value_bh'],
                'significant_fdr_005': comp['significant_bh_005'],
            })
        df = pd.DataFrame(rows)
        csv_path = f"/mnt/results/delong_{key}.csv"
        df.to_csv(csv_path, index=False)
        print(f"Saved: {csv_path}")
    
    # --------------------------------------------------------
    # Print final summary
    # --------------------------------------------------------
    print("\n" + "=" * 70)
    print("FINAL SUMMARY")
    print("=" * 70)
    
    for key, comparisons in delong_results.items():
        n_total = len(comparisons)
        n_sig = sum(1 for c in comparisons if c['significant_bh_005'])
        print(f"\n{key}: {n_sig}/{n_total} significant pairwise differences (BH FDR < 0.05)")
        
        # Highlight key comparisons
        key_comparisons = [
            ('V2_ILR_LP', 'V1_CLR_LP'),
            ('V2_ILR_LP', 'RF_ILR'),
            ('V2_ILR_LP', 'V2_no_aug'),
            ('V2_ILR_LP', 'V2_pert_only'),
        ]
        for mA, mB in key_comparisons:
            match = [c for c in comparisons if (c['method_A'] == mA and c['method_B'] == mB) or 
                     (c['method_A'] == mB and c['method_B'] == mA)]
            if match:
                c = match[0]
                sig = "YES" if c['significant_bh_005'] else "no"
                print(f"  {mA} vs {mB}: dAUC={c['delta_auc']:+.4f}, p_BH={c['p_value_bh']:.4f} [{sig}]")
    
    return delong_results, all_auc_results


if __name__ == "__main__":
    delong_results, auc_results = run_delong_analysis()
