#!/usr/bin/env python3
"""
Re-run evaluations for T1D/T2D to get per-fold predictions,
then compute global DeLong tests and clinical metrics for all 12 tasks.
"""
import sys, os, json, time
import numpy as np, pandas as pd
import torch, torch.nn as nn, torch.optim as optim
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score, roc_curve
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier
from scipy import stats

sys.path.insert(0, "/mnt/shared-workspace")
from phylocompoclr_v2_train import PhyloCompoCLREncoder

DATA_DIR = "/mnt/shared-workspace/cmd3_data"
MODEL_DIR = "/mnt/shared-workspace/models"
RS = 42

XGB_PARAMS = dict(n_estimators=300, max_depth=6, learning_rate=0.1,
                  use_label_encoder=False, eval_metric='logloss', verbosity=0,
                  random_state=RS)
RF_PARAMS = dict(n_estimators=500, random_state=RS, n_jobs=-1)
LASSO_PARAMS = dict(penalty='l1', C=1.0, solver='saga', max_iter=2000)
FT_PARAMS = dict(lr=1e-4, weight_decay=1e-4, epochs=50)
MLP_PARAMS = dict(lr=1e-3, weight_decay=1e-4, epochs=100)

def load_model(level, variant):
    fname = f"{MODEL_DIR}/{level}_v2_{variant}_best.pt"
    ckpt = torch.load(fname, map_location='cpu', weights_only=False)
    cfg = ckpt['config']
    return ckpt, cfg

def extract_all_features(ilr_t, ckpt, cfg):
    enc = PhyloCompoCLREncoder(cfg['input_dim'], cfg['hidden_dims'], cfg['embed_dim'])
    enc.load_state_dict(ckpt['encoder_state_dict'])
    enc.eval()
    X_t = torch.tensor(ilr_t, dtype=torch.float32)
    extractor = {}
    hooks = []
    for name, module in enc.named_modules():
        if isinstance(module, nn.Linear):
            def make_hook(n):
                def hook(mod, inp, out):
                    extractor[n] = out.detach().numpy()
                return hook
            h = module.register_forward_hook(make_hook(name))
            hooks.append(h)
    with torch.no_grad():
        _ = enc(X_t)
    for h in hooks:
        h.remove()
    layer_keys = sorted(extractor.keys())
    emb = extractor[layer_keys[-1]]
    all_layers = np.hstack([extractor[k] for k in layer_keys])
    return emb, all_layers, layer_keys

class FineTuneModel(nn.Module):
    def __init__(self, encoder, embed_dim, n_classes=2):
        super().__init__()
        self.encoder = encoder
        self.classifier = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(embed_dim // 2, n_classes)
        )
    def forward(self, x):
        return self.classifier(self.encoder(x))

class MLPFromScratch(nn.Module):
    def __init__(self, input_dim, hidden_dims, embed_dim, n_classes=2):
        super().__init__()
        layers = []
        prev_dim = input_dim
        for h_dim in hidden_dims:
            layers.extend([nn.Linear(prev_dim, h_dim), nn.BatchNorm1d(h_dim), nn.ReLU()])
            prev_dim = h_dim
        layers.append(nn.Linear(prev_dim, embed_dim))
        self.encoder = nn.Sequential(*layers)
        self.classifier = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(embed_dim // 2, n_classes)
        )
    def forward(self, x):
        return self.classifier(self.encoder(x))

def run_ft(ilr_t, labels, ckpt, cfg, nfolds):
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tri, tei in skf.split(ilr_t, labels):
        enc = PhyloCompoCLREncoder(cfg['input_dim'], cfg['hidden_dims'], cfg['embed_dim'])
        enc.load_state_dict(ckpt['encoder_state_dict'])
        model = FineTuneModel(enc, cfg['embed_dim'])
        opt = optim.Adam(model.parameters(), lr=FT_PARAMS['lr'], weight_decay=FT_PARAMS['weight_decay'])
        X_tr = torch.tensor(ilr_t[tri], dtype=torch.float32)
        y_tr = torch.tensor(labels[tri], dtype=torch.long)
        X_te = torch.tensor(ilr_t[tei], dtype=torch.float32)
        model.train()
        for ep in range(FT_PARAMS['epochs']):
            opt.zero_grad()
            nn.CrossEntropyLoss()(model(X_tr), y_tr).backward()
            opt.step()
        model.eval()
        with torch.no_grad():
            prob = torch.softmax(model(X_te), dim=1)[:, 1].numpy()
        preds.append(prob)
        aucs.append(roc_auc_score(labels[tei], prob))
    return preds, aucs

def run_mlp(ilr_t, labels, cfg, nfolds):
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tri, tei in skf.split(ilr_t, labels):
        model = MLPFromScratch(cfg['input_dim'], cfg['hidden_dims'], cfg['embed_dim'])
        opt = optim.Adam(model.parameters(), lr=MLP_PARAMS['lr'], weight_decay=MLP_PARAMS['weight_decay'])
        X_tr = torch.tensor(ilr_t[tri], dtype=torch.float32)
        y_tr = torch.tensor(labels[tri], dtype=torch.long)
        X_te = torch.tensor(ilr_t[tei], dtype=torch.float32)
        model.train()
        for ep in range(MLP_PARAMS['epochs']):
            opt.zero_grad()
            nn.CrossEntropyLoss()(model(X_tr), y_tr).backward()
            opt.step()
        model.eval()
        with torch.no_grad():
            prob = torch.softmax(model(X_te), dim=1)[:, 1].numpy()
        preds.append(prob)
        aucs.append(roc_auc_score(labels[tei], prob))
    return preds, aucs

def run_xgb(X, labels, nfolds):
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tri, tei in skf.split(X, labels):
        clf = XGBClassifier(**XGB_PARAMS)
        clf.fit(X[tri], labels[tri])
        prob = clf.predict_proba(X[tei])[:, 1]
        preds.append(prob)
        aucs.append(roc_auc_score(labels[tei], prob))
    return preds, aucs

def run_rf(X, labels, nfolds):
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tri, tei in skf.split(X, labels):
        clf = RandomForestClassifier(**RF_PARAMS)
        clf.fit(X[tri], labels[tri])
        prob = clf.predict_proba(X[tei])[:, 1]
        preds.append(prob)
        aucs.append(roc_auc_score(labels[tei], prob))
    return preds, aucs

def run_lasso(X, labels, nfolds):
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tri, tei in skf.split(X, labels):
        scaler = StandardScaler()
        clf = LogisticRegression(**LASSO_PARAMS)
        clf.fit(scaler.fit_transform(X[tri]), labels[tri])
        prob = clf.predict_proba(scaler.transform(X[tei]))[:, 1]
        preds.append(prob)
        aucs.append(roc_auc_score(labels[tei], prob))
    return preds, aucs

def run_lp(emb, labels, nfolds):
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tri, tei in skf.split(emb, labels):
        clf = LogisticRegression(max_iter=2000, C=1.0)
        clf.fit(emb[tri], labels[tri])
        prob = clf.predict_proba(emb[tei])[:, 1]
        preds.append(prob)
        aucs.append(roc_auc_score(labels[tei], prob))
    return preds, aucs

def run_stacking(all_preds, y_trues, nfolds, combo_methods):
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    preds, aucs = [], []
    for tf in range(nfolds):
        tm = np.column_stack([np.concatenate([all_preds[m][i] for i in range(nfolds) if i != tf]) for m in combo_methods])
        ty = np.concatenate([y_trues[i] for i in range(nfolds) if i != tf])
        tem = np.column_stack([all_preds[m][tf] for m in combo_methods])
        mc = LogisticRegression(max_iter=1000)
        mc.fit(tm, ty)
        mp = mc.predict_proba(tem)[:, 1]
        preds.append(mp)
        aucs.append(roc_auc_score(y_trues[tf], mp))
    return preds, aucs

def delong_roc_test(y_true, y_pred1, y_pred2):
    n = len(y_true)
    n1 = np.sum(y_true == 1)
    n2 = np.sum(y_true == 0)
    auc1 = roc_auc_score(y_true, y_pred1)
    auc2 = roc_auc_score(y_true, y_pred2)
    
    def compute_placement(pred, labels):
        pos_pred = pred[labels == 1]
        neg_pred = pred[labels == 0]
        placements_pos = np.array([np.sum(neg_pred < p) + 0.5 * np.sum(neg_pred == p) for p in pos_pred]) / n2
        placements_neg = np.array([np.sum(pos_pred > p) + 0.5 * np.sum(pos_pred == p) for p in neg_pred]) / n1
        return placements_pos, placements_neg
    
    p1_pos, p1_neg = compute_placement(y_pred1, y_true)
    p2_pos, p2_neg = compute_placement(y_pred2, y_true)
    
    S1_pos, S1_neg = np.var(p1_pos, ddof=1), np.var(p1_neg, ddof=1)
    S2_pos, S2_neg = np.var(p2_pos, ddof=1), np.var(p2_neg, ddof=1)
    cov_pos = np.cov(p1_pos, p2_pos)[0, 1]
    cov_neg = np.cov(p1_neg, p2_neg)[0, 1]
    
    var_diff = (1/n1) * (S1_pos + S2_pos - 2*cov_pos) + (1/n2) * (S1_neg + S2_neg - 2*cov_neg)
    if var_diff <= 0:
        return 1.0, auc1, auc2
    z = (auc1 - auc2) / np.sqrt(var_diff)
    p_value = 2 * (1 - stats.norm.cdf(abs(z)))
    return p_value, auc1, auc2

def evaluate_level_task(level, task, ilr_all, meta):
    col = f'{task}_binary'
    mask = meta[col].notna()
    labels = meta.loc[mask, col].values.astype(int)
    ilr_t = ilr_all[mask.values]
    nfolds = 5 if task in ['t2d', 'ibd', 'cd', 'uc', 'crc'] else 3
    
    key = f"{level}_{task}"
    print(f"\n{'='*70}")
    print(f"EVALUATION: {key} (n={len(labels)}, pos={labels.sum()}, {nfolds}-fold)")
    print(f"{'='*70}")
    
    ckpt_128, cfg_128 = load_model(level, 'full')
    ckpt_256, cfg_256 = load_model(level, 'wide256')
    
    print("Extracting features...")
    emb_128, all_layers_128, _ = extract_all_features(ilr_t, ckpt_128, cfg_128)
    emb_256, all_layers_256, _ = extract_all_features(ilr_t, ckpt_256, cfg_256)
    
    X_v2enh_128 = np.hstack([emb_128, ilr_t])
    X_v2enh_256 = np.hstack([emb_256, ilr_t])
    X_allv2_128 = np.hstack([all_layers_128, ilr_t])
    X_allv2_256 = np.hstack([all_layers_256, ilr_t])
    
    all_preds = {}
    y_trues = []
    skf = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=RS)
    for tri, tei in skf.split(ilr_t, labels):
        y_trues.append(labels[tei])
    
    # Run all methods
    for name, emb in [('V2_LP_128', emb_128), ('V2_LP_256', emb_256)]:
        p, a = run_lp(emb, labels, nfolds)
        all_preds[name] = p
        print(f"  {name}: {np.mean(a):.4f}")
    
    for name, ckpt, cfg in [('V2_FT_128', ckpt_128, cfg_128), ('V2_FT_256', ckpt_256, cfg_256)]:
        p, a = run_ft(ilr_t, labels, ckpt, cfg, nfolds)
        all_preds[name] = p
        print(f"  {name}: {np.mean(a):.4f}")
    
    p, a = run_mlp(ilr_t, labels, cfg_256, nfolds)
    all_preds['MLP_scratch'] = p
    print(f"  MLP_scratch: {np.mean(a):.4f}")
    
    p, a = run_lasso(ilr_t, labels, nfolds)
    all_preds['LASSO_ILR'] = p
    print(f"  LASSO_ILR: {np.mean(a):.4f}")
    
    p, a = run_rf(ilr_t, labels, nfolds)
    all_preds['RF_raw'] = p
    print(f"  RF_raw: {np.mean(a):.4f}")
    
    for name, X in [('XGB_raw', ilr_t), ('XGB_V2enh_128', X_v2enh_128),
                     ('XGB_V2enh_256', X_v2enh_256), ('XGB_allV2_128', X_allv2_128),
                     ('XGB_allV2_256', X_allv2_256)]:
        p, a = run_xgb(X, labels, nfolds)
        all_preds[name] = p
        print(f"  {name}: {np.mean(a):.4f}")
    
    stack_combos = {
        'Stack_XGB_RF': ['XGB_raw', 'RF_raw'],
        'Stack_XGB_V2enh_RF': ['XGB_raw', 'XGB_allV2_256', 'RF_raw'],
        'Stack_FT_XGB_RF': ['V2_FT_256', 'XGB_raw', 'RF_raw'],
        'Stack_all5': ['V2_FT_256', 'XGB_raw', 'XGB_allV2_256', 'RF_raw', 'LASSO_ILR'],
    }
    for sname, combo in stack_combos.items():
        p, a = run_stacking(all_preds, y_trues, nfolds, combo)
        all_preds[sname] = p
        print(f"  {sname}: {np.mean(a):.4f}")
    
    # Save predictions
    pred_data = {m: [{'y_true': y_trues[i].tolist(), 'y_prob': all_preds[m][i].tolist()} for i in range(nfolds)] for m in all_preds}
    pred_path = f"/mnt/shared-workspace/predictions_{key}.json"
    with open(pred_path, 'w') as f:
        json.dump(pred_data, f)
    print(f"Saved predictions to {pred_path}")
    
    return all_preds, y_trues, nfolds

# ============ CLINICAL METRICS ============
def compute_clinical_metrics(y_true, y_prob, prevalence=None):
    fpr, tpr, thresholds = roc_curve(y_true, y_prob)
    roc_auc = roc_auc_score(y_true, y_prob) if len(set(y_true)) > 1 else 0.5
    
    def sens_at_spec(target_spec):
        target_fpr = 1 - target_spec
        idx = np.searchsorted(fpr, target_fpr, side='right')
        if idx >= len(tpr): idx = len(tpr) - 1
        return float(tpr[idx])
    
    youden_j_vals = tpr + (1 - fpr) - 1
    best_idx = np.argmax(youden_j_vals)
    youden_sens = float(tpr[best_idx])
    youden_spec = float(1 - fpr[best_idx])
    
    if prevalence is None:
        prevalence = np.mean(y_true)
    tp = youden_sens * prevalence
    fp = (1 - youden_spec) * (1 - prevalence)
    fn = (1 - youden_sens) * prevalence
    tn = youden_spec * (1 - prevalence)
    ppv = tp / (tp + fp) if (tp + fp) > 0 else 0
    npv = tn / (tn + fn) if (tn + fn) > 0 else 0
    
    return {
        'auc': float(roc_auc),
        'sensitivity_at_spec_80': sens_at_spec(0.80),
        'sensitivity_at_spec_90': sens_at_spec(0.90),
        'youden_j': float(youden_j_vals[best_idx]),
        'youden_threshold': float(thresholds[best_idx]),
        'youden_sensitivity': youden_sens,
        'youden_specificity': youden_spec,
        'ppv_at_youden': float(ppv),
        'npv_at_youden': float(npv),
        'prevalence_used': float(prevalence),
    }

CLINICAL_REFERENCES = {
    't2d': {'hba1c_sensitivity_at_spec_90': 0.70, 'prevalence_screening': 0.10,
            'source': 'HbA1c sensitivity for T2D screening (ADA guidelines)'},
    't1d': {'prevalence_population': 0.005,
            'source': 'T1D is rare; autoantibody screening is standard'},
}

# ============ MAIN ============
if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--task', choices=['t2d', 't1d', 'both'], default='both')
    parser.add_argument('--level', choices=['genus', 'species', 'both'], default='both')
    args = parser.parse_args()
    
    tasks = ['t2d', 't1d'] if args.task == 'both' else [args.task]
    levels = ['genus', 'species'] if args.level == 'both' else [args.level]
    
    all_predictions = {}  # key -> {method: [fold_preds]}
    all_y_trues = {}      # key -> [fold_y_trues]
    all_nfolds = {}
    
    for level in levels:
        print(f"\nLoading {level} PhILR data...")
        ilr = pd.read_csv(f"{DATA_DIR}/{level}_philr_transform.csv", index_col=0)
        meta = pd.read_csv(f"{DATA_DIR}/sample_metadata.csv", index_col=0, low_memory=False)
        common = ilr.index.intersection(meta.index)
        ilr_v = ilr.loc[common].values
        meta_l = meta.loc[common]
        del ilr; import gc; gc.collect()
        
        for task in tasks:
            key = f"{level}_{task}"
            # Check if predictions already exist
            pred_path = f"/mnt/shared-workspace/predictions_{key}.json"
            if os.path.exists(pred_path):
                print(f"\n  Loading existing predictions for {key}...")
                with open(pred_path, 'r') as f:
                    pred_data = json.load(f)
                all_predictions[key] = {m: [fold['y_prob'] for fold in folds] for m, folds in pred_data.items()}
                all_y_trues[key] = [pred_data[list(pred_data.keys())[0]][i]['y_true'] for i in range(len(pred_data[list(pred_data.keys())[0]]))]
                all_nfolds[key] = len(all_y_trues[key])
            else:
                preds, y_trues, nfolds = evaluate_level_task(level, task, ilr_v, meta_l)
                all_predictions[key] = preds
                all_y_trues[key] = y_trues
                all_nfolds[key] = nfolds
    
    # ============ GLOBAL DELONG TESTS ============
    print(f"\n{'='*70}")
    print("GLOBAL DELONG TESTS (BH-corrected across all comparisons)")
    print(f"{'='*70}")
    
    delong_comparisons = [
        ('XGB_allV2_256 vs XGB_raw', 'XGB_allV2_256', 'XGB_raw'),
        ('Stack_XGB_V2enh_RF vs XGB_raw', 'Stack_XGB_V2enh_RF', 'XGB_raw'),
        ('Stack_all5 vs XGB_raw', 'Stack_all5', 'XGB_raw'),
        ('XGB_allV2_256 vs RF_raw', 'XGB_allV2_256', 'RF_raw'),
        ('V2_FT_256 vs V2_FT_128', 'V2_FT_256', 'V2_FT_128'),
        ('V2_FT_128 vs XGB_raw', 'V2_FT_128', 'XGB_raw'),
    ]
    
    all_delong = []
    for key in sorted(all_predictions.keys()):
        preds = all_predictions[key]
        y_trues = all_y_trues[key]
        y_all = np.concatenate(y_trues)
        
        for comp_name, m1, m2 in delong_comparisons:
            if m1 in preds and m2 in preds:
                pred1 = np.concatenate(preds[m1])
                pred2 = np.concatenate(preds[m2])
                p, auc1, auc2 = delong_roc_test(y_all, pred1, pred2)
                all_delong.append({
                    'task': key, 'comparison': comp_name,
                    'method1': m1, 'method2': m2,
                    'auc1': auc1, 'auc2': auc2,
                    'delta_auc': auc1 - auc2, 'p_value': p
                })
    
    # Global BH correction
    from statsmodels.stats.multitest import multipletests
    pvals = [d['p_value'] for d in all_delong]
    reject, pvals_corr, _, _ = multipletests(pvals, method='fdr_bh')
    for i, d in enumerate(all_delong):
        d['p_BH_global'] = pvals_corr[i]
        d['sig_BH_global'] = '***' if pvals_corr[i] < 0.001 else '**' if pvals_corr[i] < 0.01 else '*' if pvals_corr[i] < 0.05 else 'ns'
    
    # Print results
    print(f"\n{'Task':20s} {'Comparison':35s} {'dAUC':>8s} {'p_raw':>10s} {'p_BH_global':>12s} {'Sig':>4s}")
    print("-" * 95)
    for d in all_delong:
        print(f"{d['task']:20s} {d['comparison']:35s} {d['delta_auc']:+8.4f} {d['p_value']:10.4f} {d['p_BH_global']:12.4f} {d['sig_BH_global']:>4s}")
    
    # Count significant
    n_sig = sum(1 for d in all_delong if d['sig_BH_global'] != 'ns')
    print(f"\n{n_sig}/{len(all_delong)} comparisons significant after global BH correction")
    
    # Save
    delong_path = "/mnt/results/global_delong_all_tasks.json"
    with open(delong_path, 'w') as f:
        json.dump(all_delong, f, indent=2, default=str)
    print(f"Saved {delong_path}")
    
    # ============ CLINICAL METRICS FOR T2D/T1D ============
    print(f"\n{'='*70}")
    print("CLINICAL METRICS (T2D/T1D)")
    print(f"{'='*70}")
    
    for key in sorted(all_predictions.keys()):
        task = key.split('_')[1]
        if task not in ['t2d', 't1d']:
            continue
        
        preds = all_predictions[key]
        y_trues = all_y_trues[key]
        ref = CLINICAL_REFERENCES.get(task, {})
        prevalence = ref.get('prevalence_screening', ref.get('prevalence_population', np.nan))
        
        clin_results = {}
        for method, fold_preds in preds.items():
            y_true_all = np.concatenate(y_trues)
            y_prob_all = np.concatenate(fold_preds)
            metrics = compute_clinical_metrics(y_true_all, y_prob_all, prevalence=prevalence)
            clin_results[method] = metrics
        
        # Print
        print(f"\n  {key} (prevalence={prevalence}):")
        print(f"  {'Method':25s} {'AUC':>6s} {'Sens@80':>8s} {'Sens@90':>8s} {'YoudenJ':>7s} {'PPV':>6s} {'NPV':>6s}")
        for m, v in sorted(clin_results.items(), key=lambda x: -x[1]['auc']):
            print(f"  {m:25s} {v['auc']:.4f} {v['sensitivity_at_spec_80']:.4f} {v['sensitivity_at_spec_90']:.4f} {v['youden_j']:.4f} {v['ppv_at_youden']:.4f} {v['npv_at_youden']:.4f}")
        
        # Save
        save_data = {
            'key': key, 'disease': task, 'level': key.split('_')[0],
            'clinical_reference': ref,
            'method_metrics': clin_results,
        }
        clin_path = f"/mnt/results/clinical_{key}_metrics.json"
        with open(clin_path, 'w') as f:
            json.dump(save_data, f, indent=2, default=str)
        print(f"  Saved {clin_path}")
    
    print("\nDone!")
