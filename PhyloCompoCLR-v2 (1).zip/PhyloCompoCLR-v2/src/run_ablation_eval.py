
#!/usr/bin/env python3
"""Evaluate all genus ablation models on T2D."""

import sys
sys.path.insert(0, "/mnt/shared-workspace")
import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
import json

# Load data
genus_philr = pd.read_csv("/mnt/shared-workspace/cmd3_data/genus_philr_transform.csv", index_col=0)
genus_ilr = genus_philr.values.astype(np.float32)
sample_ids = genus_philr.index.tolist()
del genus_philr
import gc; gc.collect()

metadata = pd.read_csv("/mnt/shared-workspace/cmd3_data/sample_metadata.csv", index_col=0, low_memory=False)
metadata_aligned = metadata.loc[sample_ids]

t2d_mask = metadata_aligned['t2d_binary'].notna()
t2d_labels = metadata_aligned.loc[t2d_mask, 't2d_binary'].values.astype(int)

from phylocompoclr_v2_train import PhyloCompoCLREncoder

ablation_names = ['full', 'pert_only', 'power_only', 'mixup_only', 'phylo_only', 'no_aug']
results = {}

for ablation in ablation_names:
    model_path = f"/mnt/shared-workspace/models/genus_v2_{ablation}_best.pt"
    try:
        checkpoint = torch.load(model_path, map_location='cpu', weights_only=False)
    except Exception as e:
        print(f"  {ablation}: model not found ({e})")
        continue

    config = checkpoint['config']
    encoder = PhyloCompoCLREncoder(config['input_dim'], config['hidden_dims'], config['embed_dim'])
    encoder.load_state_dict(checkpoint['encoder_state_dict'])
    encoder.eval()

    # Extract embeddings
    X = torch.tensor(genus_ilr, dtype=torch.float32)
    embeddings = []
    with torch.no_grad():
        for i in range(0, len(X), 512):
            batch = X[i:i+512]
            emb = encoder(batch)
            embeddings.append(emb.numpy())
    embeddings = np.vstack(embeddings)

    # T2D LP
    t2d_emb = embeddings[t2d_mask.values]
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    aucs = []
    for train_idx, test_idx in skf.split(t2d_emb, t2d_labels):
        clf = LogisticRegression(max_iter=1000, C=1.0, random_state=42)
        clf.fit(t2d_emb[train_idx], t2d_labels[train_idx])
        y_prob = clf.predict_proba(t2d_emb[test_idx])[:, 1]
        auc = roc_auc_score(t2d_labels[test_idx], y_prob)
        aucs.append(auc)

    results[ablation] = {
        'auc_mean': float(np.mean(aucs)),
        'auc_std': float(np.std(aucs)),
        'per_fold': [float(a) for a in aucs],
    }
    print(f"  {ablation}: AUC={np.mean(aucs):.3f} +/- {np.std(aucs):.3f}")

with open('/mnt/results/evaluation_genus_ablations.json', 'w') as f:
    json.dump(results, f, indent=2)
print(f"\nAblation results saved to /mnt/results/evaluation_genus_ablations.json")
